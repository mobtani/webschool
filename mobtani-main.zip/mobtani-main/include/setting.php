<?php
if( ! defined('DBHOST') )
	define( 'DBHOST', 'sql201.b6b.ir' );
if( ! defined('DBUSER') )
	define( 'DBUSER', 'b6bi_27916015' );
if( ! defined('DBPASS') )
	define( 'DBPASS', 'Qwertyui0913' );
if( ! defined('DBNAME') )
	define( 'DBNAME', 'b6bi_27916015_product' );
	
if( ! defined('CHARSET') )
	define( 'CHARSET', 'utf8mb4' );

$dbHost =	DBHOST;
$dbUser =	DBUSER;
$dbPass =	DBPASS;
$dbname =	DBNAME;
$charset =	CHARSET;
$softSetup = false;
?>