<?php
// this page is intentionally left blank

include 'includes/functions.php';
redirect('../');