<?php
include ('../include/setting.php');
include ('../include/functions.php');
$db=new DB();
$table=messages::find();
unset($db);
$alerts=alerts();

include ('../include/views/message.php');
?>