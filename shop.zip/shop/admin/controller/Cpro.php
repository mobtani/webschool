<?php
require_once 'model/Mpro.php';

    $class = new pro();
    switch($action){
        case 'list':
         $pro=$class->pro_list();
        break;
        case 'add':
            $res=$class->procat_list();
            if($_POST){
                $data=$_POST['frm'];
                $exts=array('image/jpeg','image/png');
                $to=$class->uploaderImage('image1','public/uploader',$exts);
                $to1=$class->uploaderImage('image2','public/uploader',$exts);
                $to2=$class->uploaderImage('image3','public/uploader',$exts);
                $class->pro_add($data,$to,$to1,$to2);
            }
        break;
        case 'delete':
            $id=$_GET['id'];
            $class->pro_delete($id);
            header("location:index.php?c=pro&a=list");
        break;
        case 'edit':
            $id=$_GET['id'];
            $results=$class->pro_showEdit($id);
            $res=$class->promaincat_list();
            if($_POST){
                $data=$_POST['frm'];
                $class->pro_edit($data,$id);
                header("location:index.php?c=pro&a=list");
            }
        break;
    }
   require_once 'view/'.$controller."/".$action.'.php';