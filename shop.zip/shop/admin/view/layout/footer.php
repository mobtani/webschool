
<!-- js placed at the end of the document so the pages load faster -->
<script src="../public/admin/js/jquery.js"></script>
<script src="../public/admin/js/bootstrap.min.js"></script>
<script src="../public/admin/js/jquery.scrollTo.min.js"></script>
<script src="../public/admin/js/jquery.nicescroll.js" type="text/javascript"></script>

<!-- BEGIN:File Upload Plugin JS files-->
<script src="../public/admin/assets/jquery-file-upload/js/vendor/jquery.ui.widget.js"></script>
<!-- The Templates plugin is included to render the upload/download listings -->
<script src="../public/admin/assets/jquery-file-upload/js/vendor/tmpl.min.js"></script>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="../public/admin/assets/jquery-file-upload/js/vendor/load-image.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="../public/admin/assets/jquery-file-upload/js/vendor/canvas-to-blob.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="../public/admin/assets/jquery-file-upload/js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="../public/admin/assets/jquery-file-upload/js/jquery.fileupload.js"></script>
<!-- The File Upload file processing plugin -->
<script src="../public/admin/assets/jquery-file-upload/js/jquery.fileupload-fp.js"></script>
<!-- The File Upload user interface plugin -->
<script src="../public/admin/assets/jquery-file-upload/js/jquery.fileupload-ui.js"></script>


<!--common script for all pages-->
<script src="../public/admin/js/common-scripts.js"></script>


</body>
</html>
