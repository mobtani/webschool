<?php
    require_once 'admin/model/Mprocat.php';
    $class=new procat();
    $list_procat=$class->procat_list_default();