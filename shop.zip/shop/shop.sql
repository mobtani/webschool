-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2018 at 09:12 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`id`, `name`, `username`, `password`) VALUES
(1, 'alibarzegar', 'ali', '123');

-- --------------------------------------------------------

--
-- Table structure for table `basket_tbl`
--

CREATE TABLE `basket_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `tedad` int(11) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `basket_tbl`
--

INSERT INTO `basket_tbl` (`id`, `user_id`, `pro_id`, `tedad`, `status`) VALUES
(9, 1, 13, 1, 0),
(10, 1, 12, 1, 0),
(14, 3, 61, 4, 1),
(16, 3, 59, 2, 1),
(17, 3, 60, 16, 1);

-- --------------------------------------------------------

--
-- Table structure for table `procat_tbl`
--

CREATE TABLE `procat_tbl` (
  `id` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `chid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `procat_tbl`
--

INSERT INTO `procat_tbl` (`id`, `title`, `chid`) VALUES
(34, 'mobile', 0),
(35, 'laptop', 0),
(36, 'LG', 34);

-- --------------------------------------------------------

--
-- Table structure for table `pro_tbl`
--

CREATE TABLE `pro_tbl` (
  `id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `text` text COLLATE utf8_persian_ci NOT NULL,
  `image1` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `image2` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `image3` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `cat_id` text COLLATE utf8_persian_ci NOT NULL,
  `count` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `price` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `date` date NOT NULL,
  `foroosh` varchar(100) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `pro_tbl`
--

INSERT INTO `pro_tbl` (`id`, `title`, `text`, `image1`, `image2`, `image3`, `cat_id`, `count`, `price`, `date`, `foroosh`) VALUES
(59, 'محصول شماره 3', 'توضیحات محصول شماره 3توضیحات محصول شماره 3توضیحات محصول شماره 3توضیحات محصول شماره 3توضیحات محصول شماره 3', 'public/uploader/655441438.jpg', '', '', '35', '47', '60000', '0000-00-00', ''),
(60, 'محصول شماره 2', 'توضیحات محصول شماره 2توضیحات محصول شماره 2توضیحات محصول شماره 2توضیحات محصول شماره 2توضیحات محصول شماره 2', 'public/uploader/655441437.jpg', '', '', '34', '10', '80000', '0000-00-00', ''),
(61, 'محصول شماره 1', 'توضیحات محصول شماره 1 توضیحات محصول شماره 1 توضیحات محصول شماره 1 توضیحات محصول شماره 1', 'public/uploader/1301327818.jpg', '', '', '34', '10', '75000', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `status` int(11) NOT NULL,
  `vc` varchar(150) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`id`, `name`, `email`, `password`, `status`, `vc`) VALUES
(3, 'Ali', 'a@a.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `wish_tbl`
--

CREATE TABLE `wish_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pro_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `wish_tbl`
--

INSERT INTO `wish_tbl` (`id`, `user_id`, `pro_id`) VALUES
(7, 3, 59),
(8, 3, 59);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `basket_tbl`
--
ALTER TABLE `basket_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `procat_tbl`
--
ALTER TABLE `procat_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_tbl`
--
ALTER TABLE `pro_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wish_tbl`
--
ALTER TABLE `wish_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `basket_tbl`
--
ALTER TABLE `basket_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `procat_tbl`
--
ALTER TABLE `procat_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `pro_tbl`
--
ALTER TABLE `pro_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wish_tbl`
--
ALTER TABLE `wish_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
