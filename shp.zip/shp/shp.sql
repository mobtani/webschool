-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 01, 2021 at 01:36 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shp`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `submittime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_anbar`
--

DROP TABLE IF EXISTS `db_anbar`;
CREATE TABLE IF NOT EXISTS `db_anbar` (
  `db_anbar_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_anbar_product_code` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_anbar_product_count` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`db_anbar_id`),
  UNIQUE KEY `db_anbar_product_code` (`db_anbar_product_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_anbar`
--

INSERT INTO `db_anbar` (`db_anbar_id`, `db_anbar_product_code`, `db_anbar_product_count`) VALUES
(2, '8457801', '5'),
(3, '854579518', '4');

-- --------------------------------------------------------

--
-- Table structure for table `db_contactus`
--

DROP TABLE IF EXISTS `db_contactus`;
CREATE TABLE IF NOT EXISTS `db_contactus` (
  `db_contactus_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_contactus_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_contactus_email` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_contactus_subject` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_contactus_comment` text COLLATE utf8_persian_ci NOT NULL,
  `db_contactus_date` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_contactus_state` int(1) NOT NULL,
  PRIMARY KEY (`db_contactus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_contactus`
--

INSERT INTO `db_contactus` (`db_contactus_id`, `db_contactus_name`, `db_contactus_email`, `db_contactus_subject`, `db_contactus_comment`, `db_contactus_date`, `db_contactus_state`) VALUES
(2, 'الناز صیدی', 'elnaz@gmail.com', 'پیشنهاد', 'سلام سایت خوبی دارید امیدوارم موفق شوید ', '5 خرداد1400', 1),
(7, 'منا احمدی', 'mona@gmail.com', 'پیشنهاد', 'سلام من سفارشی به ۸۰۰۳۳۰ داشتم پس چی شد ؟', '8 خرداد1400', 0),
(8, 'ث', 'Kkkk@ff.com', 'پیشنهاد', 'cc', '3 اردیبهشت1400', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_final_factor`
--

DROP TABLE IF EXISTS `db_final_factor`;
CREATE TABLE IF NOT EXISTS `db_final_factor` (
  `db_final_factor_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_final_factor_code` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_final_factor_user_code` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_final_factor_date` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_final_factor_price` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_final_factor_state` int(2) NOT NULL DEFAULT '0',
  `db_final_factor_transid` varchar(255) COLLATE utf8_persian_ci NOT NULL DEFAULT 'پرداخت ناموفق',
  `db_final_factor_pay_state` varchar(255) COLLATE utf8_persian_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`db_final_factor_id`),
  UNIQUE KEY `db_final_factor_code` (`db_final_factor_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_final_factor`
--

INSERT INTO `db_final_factor` (`db_final_factor_id`, `db_final_factor_code`, `db_final_factor_user_code`, `db_final_factor_date`, `db_final_factor_price`, `db_final_factor_state`, `db_final_factor_transid`, `db_final_factor_pay_state`) VALUES
(1, '278523568888097', '62yuwjk1m', '۲۴خرداد۱۴۰۰', '111150000', 0, 'پرداخت ناموفق', '0'),
(2, '342312138287271', 'wyjlb4hcr', '۲۴خرداد۱۴۰۰', '111150000', 0, 'پرداخت ناموفق', '0'),
(3, '487820238623732', 'ya1xn5196', '۲۵خرداد۱۴۰۰', '111150000', 0, 'پرداخت ناموفق', '0');

-- --------------------------------------------------------

--
-- Table structure for table `db_menu`
--

DROP TABLE IF EXISTS `db_menu`;
CREATE TABLE IF NOT EXISTS `db_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `menu_parent_id` bigint(20) NOT NULL,
  PRIMARY KEY (`menu_id`),
  KEY `menu_name` (`menu_name`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_menu`
--

INSERT INTO `db_menu` (`menu_id`, `menu_name`, `menu_parent_id`) VALUES
(70, 'لپ تاپ و لوازم جانبی', 0),
(71, 'کامپیوتر و لوازم جانبی', 0),
(72, 'گوشی موبایل و لوازم جانبی', 0),
(74, 'تبلت و لوازم جانبی', 0),
(75, 'جارو برقی', 69),
(76, 'ماشین های اداری', 0),
(77, 'پرینتر', 76),
(78, 'کاغذ خورد کن', 77);

-- --------------------------------------------------------

--
-- Table structure for table `db_post`
--

DROP TABLE IF EXISTS `db_post`;
CREATE TABLE IF NOT EXISTS `db_post` (
  `db_post_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `db_post_name_fa` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_name_en` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_comment` text COLLATE utf8_persian_ci,
  `db_post_vezheki` text COLLATE utf8_persian_ci,
  `db_post_category` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_brand` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_garanti` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_color` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_gheymat` bigint(20) DEFAULT NULL,
  `db_post_takhfif` int(10) DEFAULT NULL,
  `db_post_image` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_code` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `db_post_creator` varchar(400) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_date` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_post_view` varchar(1000) COLLATE utf8_persian_ci DEFAULT '0',
  PRIMARY KEY (`db_post_id`),
  UNIQUE KEY `db_post_code` (`db_post_code`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_post`
--

INSERT INTO `db_post` (`db_post_id`, `db_post_name_fa`, `db_post_name_en`, `db_post_comment`, `db_post_vezheki`, `db_post_category`, `db_post_brand`, `db_post_garanti`, `db_post_color`, `db_post_gheymat`, `db_post_takhfif`, `db_post_image`, `db_post_code`, `db_post_creator`, `db_post_date`, `db_post_view`) VALUES
(33, 'لپ تاپ ایسر', 'ACER Aspire 3 ', '<p>لپ تاپ ایسر مدل ACER Aspire 3 A315 i3 4GB 1TB 2GB</p>\n', '<table>\n	<tbody>\n		<tr>\n			<td colspan=\"2\">\n			<h4>مشخصات فیزیکی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>ابعاد</td>\n			<td>19.90 &times; 247.5 &times; 363.4 میلی&zwnj; متر</td>\n		</tr>\n		<tr>\n			<td>وزن</td>\n			<td>2.0 کیلوگرم</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>پردازنده</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>سازنده</td>\n			<td>Intel</td>\n		</tr>\n		<tr>\n			<td>سری پردازنده</td>\n			<td>Core i3</td>\n		</tr>\n		<tr>\n			<td>مدل</td>\n			<td>1005G1</td>\n		</tr>\n		<tr>\n			<td>سری</td>\n			<td>Ice Lake</td>\n		</tr>\n		<tr>\n			<td>تعداد هسته (Core)</td>\n			<td>2 هسته</td>\n		</tr>\n		<tr>\n			<td>تعداد رشته (Thread)</td>\n			<td>4 رشته</td>\n		</tr>\n		<tr>\n			<td>فرکانس پایه</td>\n			<td>1.20 گیگاهرتز</td>\n		</tr>\n		<tr>\n			<td>فرکانس توربو</td>\n			<td>3.40 گیگاهرتز</td>\n		</tr>\n		<tr>\n			<td>حافظه Cache</td>\n			<td>4 مگابایت</td>\n		</tr>\n		<tr>\n			<td>گرافیک پردازنده</td>\n			<td>Intel UHD Graphics</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>حافظه رم(RAM)</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>ظرفیت حافظه رم</td>\n			<td>4 گیگابایت</td>\n		</tr>\n		<tr>\n			<td>نوع حافظه رم</td>\n			<td>DDR4</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>حافظه داخلی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>نوع حافظه داخلی</td>\n			<td>هارددیسک</td>\n		</tr>\n		<tr>\n			<td>ظرفیت حافظه هارددیسک</td>\n			<td>1 ترابایت</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>پردازنده گرافیکی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>سازنده کارت گرافیک</td>\n			<td>Nvidia</td>\n		</tr>\n		<tr>\n			<td>مدل کارت گرافیک</td>\n			<td>GeForce MX330</td>\n		</tr>\n		<tr>\n			<td>ظرفیت حافظه گرافیکی</td>\n			<td>2 گیگابایت</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>صفحه نمایش</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>اندازه صفحه نمایش</td>\n			<td>15.6 اینچ</td>\n		</tr>\n		<tr>\n			<td>نوع صفحه نمایش</td>\n			<td>LED-backlit</td>\n		</tr>\n		<tr>\n			<td>رزولوشن صفحه نمایش</td>\n			<td>768 &times; 1366 پیکسل - HD</td>\n		</tr>\n		<tr>\n			<td>صفحه نمایش مات</td>\n			<td><img src=\"https://www.markazi.co/images/checkmark.png\" /></td>\n		</tr>\n		<tr>\n			<td>صفحه نمایش لمسی</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>اتصالات</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>پورت USB 3.1</td>\n			<td>1 عدد</td>\n		</tr>\n		<tr>\n			<td>پورت 2.0 USB</td>\n			<td>2 عدد</td>\n		</tr>\n		<tr>\n			<td>پورت Thunderbolt</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>پورت HDMI</td>\n			<td>1 عدد</td>\n		</tr>\n		<tr>\n			<td>پورت DVI</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>پورت VGA</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>پورت DisplayPort</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>پورت LAN</td>\n			<td><img src=\"https://www.markazi.co/images/checkmark.png\" /></td>\n		</tr>\n		<tr>\n			<td>نوع شبکه بی سیم</td>\n			<td>Wifi 802.11 ac</td>\n		</tr>\n		<tr>\n			<td>بلوتوث</td>\n			<td><img src=\"https://www.markazi.co/images/checkmark.png\" /></td>\n		</tr>\n		<tr>\n			<td>کارت خوان</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>جک 3.5 میلیمتری</td>\n			<td>COMBO audio jack</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>امکانات</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>درایو نوری</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>وب کم</td>\n			<td><img src=\"https://www.markazi.co/images/checkmark.png\" /></td>\n		</tr>\n		<tr>\n			<td>اسپیکر</td>\n			<td>2 عدد اسپیکر استریو</td>\n		</tr>\n		<tr>\n			<td>حسگر اثر انگشت</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>نور پس زمینه کیبورد</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>کیبورد</td>\n			<td>انگلیسی</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>باتری</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>نوع باتری</td>\n			<td>لیتیوم-یون</td>\n		</tr>\n		<tr>\n			<td>مشخصات باتری</td>\n			<td>36 وات ساعت</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>سایر مشخصات</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>سیستم عامل</td>\n			<td>فاقد سیستم عامل</td>\n		</tr>\n		<tr>\n			<td>لوازم همراه دستگاه</td>\n			<td>فاقد کیف و ماوس</td>\n		</tr>\n	</tbody>\n</table>\n', '70', '', 'یکساله', 'نقره ای,مشکی', 130000000, 5, 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', '450120342', 'امیر', '12 اردیبهشت 1400', '85'),
(34, 'کارت گرافیک گیمینگ', 'MSI Radeon RX 6700 XT GAMING X 12G', '<h1>کارت گرافیک ام اس آی مدل MSI Radeon RX 6700 XT GAMING X 12G</h1>\n', '<table>\n	<tbody>\n		<tr>\n			<td colspan=\"2\">\n			<h4>مشخصات فیزیکی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>ابعاد</td>\n			<td>57 &times; 139 &times; 340 میلی&zwnj; متر</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>پردازنده</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>تراشه</td>\n			<td>Radeon RX 6900 XT</td>\n		</tr>\n		<tr>\n			<td>سازنده تراشه</td>\n			<td>AMD</td>\n		</tr>\n		<tr>\n			<td>فرکانس</td>\n			<td>در حالت پایه : 1950 مگاهرتز<br />\n			در حالت گیمینگ : 2135 مگاهرتز<br />\n			در حالت تقویتی : 2365 مگاهرتز</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>حافظه گرافیکی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>مقدار حافظه</td>\n			<td>16 گیگابایت</td>\n		</tr>\n		<tr>\n			<td>نوع حافظه</td>\n			<td>GDDR6</td>\n		</tr>\n		<tr>\n			<td>فرکانس موثر</td>\n			<td>16 گیگابیت بر ثانیه</td>\n		</tr>\n		<tr>\n			<td>باس رابط</td>\n			<td>256 بیت</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>خروجی تصویر</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>HDMI</td>\n			<td>یک عدد</td>\n		</tr>\n		<tr>\n			<td>DisplayPort</td>\n			<td>دو عدد</td>\n		</tr>\n		<tr>\n			<td>رزولوشن تصویر</td>\n			<td>VSR</td>\n		</tr>\n		<tr>\n			<td>تعداد مانیتور قابل اتصال</td>\n			<td>4 عدد</td>\n		</tr>\n		<tr>\n			<td>پورت USB Type-C</td>\n			<td>1 عدد</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>مصرف انرژی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>سوکت برق 8 پین PCI-E</td>\n			<td>دو عدد</td>\n		</tr>\n		<tr>\n			<td>حداقل منبع تغذیه مورد نیاز</td>\n			<td>850 وات</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>مشخصات فنی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>رابط اتصال</td>\n			<td>PCI Express 4.0</td>\n		</tr>\n		<tr>\n			<td>نسخه DirectX</td>\n			<td>12</td>\n		</tr>\n		<tr>\n			<td>نسخه OpenGL</td>\n			<td>4.5</td>\n		</tr>\n		<tr>\n			<td>خنک&zwnj; کننده</td>\n			<td>3 فن</td>\n		</tr>\n	</tbody>\n</table>\n', '70', '', 'یکساله طلایی', '', 380000000, 4, 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', '484142965', 'امیر', '4خرداد 1400', '31'),
(35, 'هارد دیسک اکسترنال توشیبا ', 'Toshiba Canvio Flex 1TB', '<h1>هارد دیسک اکسترنال توشیبا مدل Toshiba Canvio Flex 1TB</h1>\n', '<h4>مشخصات فیزیکی</h4>\n\n<p>ابعاد13.5 &times; 80 &times; 111 میلی&zwnj; متروزن149 گرم</p>\n\n<h4>مشخصات فنی</h4>\n\n<p>ظرفیت۱ ترابایت</p>\n\n<p>نوع حافظه قابل حمل</p>\n\n<p>نوع اتصال باسیم</p>\n\n<p>نوع رابط&nbsp; USB 3.2،&nbsp;Type-C</p>\n\n<p>سایر قابلیت&zwnj;هاسازگار با :<br />\nWindows 8.1/10<br />\nmacOS v10.15/10.14<br />\niPad<br />\nAndroid Tablet</p>\n', '', 'نم.', 'دوساله ماتریس', 'نقره ای,مشکی', 14150000, 0, 'Toshiba Canvio Flex 1TB (1)-lgr.jpg', '4841429651', 'امیر', '1خرداد 1400', '41'),
(36, 'حافظه رم دسکتاپ توین موس مدل ', 'Twinmos 8GB DDR4 2666Mhz', '<h1>حافظه رم دسکتاپ توین موس مدل Twinmos 8GB DDR4 2666Mhz(هیت سینک)</h1>\n', '<h4>مشخصات فنی</h4>\n\n<p>نوع حافظه&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;DDR4</p>\n\n<p>سوکت حافظه&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;DIMM</p>\n\n<p>ظرفیت کلی&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;8 گیگابایت</p>\n\n<p>تعداد ماژول&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;1 عدد</p>\n\n<p>ظرفیت هر ماژول&nbsp; &nbsp;8 گیگابایت</p>\n\n<p>فرکانس&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 2666</p>\n\n<p>میزان تاخیر&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;CL-19</p>\n\n<p>سرعت حافظه&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;PC4-21300</p>\n\n<p>تعداد پین&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 288</p>\n\n<p>پین ولتاژ&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;1.2 ولت</p>\n\n<p>هیت سینک&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<img src=\"https://www.markazi.co/images/checkmark.png\" /></p>\n', '70', NULL, 'یکساله شرکتی,یکساله شرکتی', '', 10600000, 11, 'Twinmos 8GB DDR4 2666Mhz hs (1)-lgr.jpg', '414945160', 'امیر', '28 اردیبهشت 1400', '19'),
(38, 'لپ تاپ ایسر جدید', 'ACER Aspire 3 ', '<p>لپ تاپ ایسر مدل ACER Aspire 3 A315 i3 4GB 1TB 2GB</p>\n', '<table>\n	<tbody>\n		<tr>\n			<td colspan=\"2\">\n			<h4>مشخصات فیزیکی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>ابعاد</td>\n			<td>19.90 &times; 247.5 &times; 363.4 میلی&zwnj; متر</td>\n		</tr>\n		<tr>\n			<td>وزن</td>\n			<td>2.0 کیلوگرم</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>پردازنده</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>سازنده</td>\n			<td>Intel</td>\n		</tr>\n		<tr>\n			<td>سری پردازنده</td>\n			<td>Core i3</td>\n		</tr>\n		<tr>\n			<td>مدل</td>\n			<td>1005G1</td>\n		</tr>\n		<tr>\n			<td>سری</td>\n			<td>Ice Lake</td>\n		</tr>\n		<tr>\n			<td>تعداد هسته (Core)</td>\n			<td>2 هسته</td>\n		</tr>\n		<tr>\n			<td>تعداد رشته (Thread)</td>\n			<td>4 رشته</td>\n		</tr>\n		<tr>\n			<td>فرکانس پایه</td>\n			<td>1.20 گیگاهرتز</td>\n		</tr>\n		<tr>\n			<td>فرکانس توربو</td>\n			<td>3.40 گیگاهرتز</td>\n		</tr>\n		<tr>\n			<td>حافظه Cache</td>\n			<td>4 مگابایت</td>\n		</tr>\n		<tr>\n			<td>گرافیک پردازنده</td>\n			<td>Intel UHD Graphics</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>حافظه رم(RAM)</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>ظرفیت حافظه رم</td>\n			<td>4 گیگابایت</td>\n		</tr>\n		<tr>\n			<td>نوع حافظه رم</td>\n			<td>DDR4</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>حافظه داخلی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>نوع حافظه داخلی</td>\n			<td>هارددیسک</td>\n		</tr>\n		<tr>\n			<td>ظرفیت حافظه هارددیسک</td>\n			<td>1 ترابایت</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>پردازنده گرافیکی</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>سازنده کارت گرافیک</td>\n			<td>Nvidia</td>\n		</tr>\n		<tr>\n			<td>مدل کارت گرافیک</td>\n			<td>GeForce MX330</td>\n		</tr>\n		<tr>\n			<td>ظرفیت حافظه گرافیکی</td>\n			<td>2 گیگابایت</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>صفحه نمایش</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>اندازه صفحه نمایش</td>\n			<td>15.6 اینچ</td>\n		</tr>\n		<tr>\n			<td>نوع صفحه نمایش</td>\n			<td>LED-backlit</td>\n		</tr>\n		<tr>\n			<td>رزولوشن صفحه نمایش</td>\n			<td>768 &times; 1366 پیکسل - HD</td>\n		</tr>\n		<tr>\n			<td>صفحه نمایش مات</td>\n			<td><img src=\"https://www.markazi.co/images/checkmark.png\" /></td>\n		</tr>\n		<tr>\n			<td>صفحه نمایش لمسی</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>اتصالات</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>پورت USB 3.1</td>\n			<td>1 عدد</td>\n		</tr>\n		<tr>\n			<td>پورت 2.0 USB</td>\n			<td>2 عدد</td>\n		</tr>\n		<tr>\n			<td>پورت Thunderbolt</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>پورت HDMI</td>\n			<td>1 عدد</td>\n		</tr>\n		<tr>\n			<td>پورت DVI</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>پورت VGA</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>پورت DisplayPort</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>پورت LAN</td>\n			<td><img src=\"https://www.markazi.co/images/checkmark.png\" /></td>\n		</tr>\n		<tr>\n			<td>نوع شبکه بی سیم</td>\n			<td>Wifi 802.11 ac</td>\n		</tr>\n		<tr>\n			<td>بلوتوث</td>\n			<td><img src=\"https://www.markazi.co/images/checkmark.png\" /></td>\n		</tr>\n		<tr>\n			<td>کارت خوان</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>جک 3.5 میلیمتری</td>\n			<td>COMBO audio jack</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>امکانات</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>درایو نوری</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>وب کم</td>\n			<td><img src=\"https://www.markazi.co/images/checkmark.png\" /></td>\n		</tr>\n		<tr>\n			<td>اسپیکر</td>\n			<td>2 عدد اسپیکر استریو</td>\n		</tr>\n		<tr>\n			<td>حسگر اثر انگشت</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>نور پس زمینه کیبورد</td>\n			<td><img src=\"https://www.markazi.co/images/x.png\" /></td>\n		</tr>\n		<tr>\n			<td>کیبورد</td>\n			<td>انگلیسی</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>باتری</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>نوع باتری</td>\n			<td>لیتیوم-یون</td>\n		</tr>\n		<tr>\n			<td>مشخصات باتری</td>\n			<td>36 وات ساعت</td>\n		</tr>\n		<tr>\n			<td colspan=\"2\">\n			<h4>سایر مشخصات</h4>\n			</td>\n		</tr>\n		<tr>\n			<td>سیستم عامل</td>\n			<td>فاقد سیستم عامل</td>\n		</tr>\n		<tr>\n			<td>لوازم همراه دستگاه</td>\n			<td>فاقد کیف و ماوس</td>\n		</tr>\n	</tbody>\n</table>\n', '70', '', 'یکساله', 'نقره ای,مشکی', 130000000, 5, 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', '45012034211', 'امیر', '12 اردیبهشت 1400', '48'),
(39, 'تست', 'test', '<p>sfaf</p>\n', '<p>sfsaf</p>\n', '70', NULL, 'دوساله', 'سفید,سبز', 1000000, 4, 'Twinmos 8GB DDR4 2666Mhz hs (1)-lgr.jpg', '6414373203174', 'امیر', '۲۴خرداد۱۴۰۰', '10'),
(40, 'تست محصول', 'testttt', '<p>متن پاین محصول</p>\n', '<p>متن کنار محصول</p>\n', '77', NULL, 'سه ساله,طلایی', 'سفید,سبز,ابی', 100000000000, 11, 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', '45869903277979', 'امیر', '۲۴خرداد۱۴۰۰', '7'),
(41, 'محصول برتر', 'test111', '<p>متن پایین محصول</p>\n', '<p>متن کنار محصول</p>\n', '78', NULL, 'دو ساله,طلایی', 'سفید,سبز,ابی', 150000000, 3, 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', '17614101033820', 'امیر', '۲۴خرداد۱۴۰۰', '6');

-- --------------------------------------------------------

--
-- Table structure for table `db_post_slider`
--

DROP TABLE IF EXISTS `db_post_slider`;
CREATE TABLE IF NOT EXISTS `db_post_slider` (
  `db_post_slider_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_post_slider_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_post_slider_creater` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_post_slider_date` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_post_slider_for_post` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`db_post_slider_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_post_slider`
--

INSERT INTO `db_post_slider` (`db_post_slider_id`, `db_post_slider_name`, `db_post_slider_creater`, `db_post_slider_date`, `db_post_slider_for_post`) VALUES
(94, 'HD (2).jpg', 'مجید1', '۲مرداد۱۳۹۵', '854579518'),
(95, 'HD (157).jpg', 'مجید1', '۲مرداد۱۳۹۵', '854579518'),
(96, 'HD (220).jpg', 'مجید1', '۲مرداد۱۳۹۵', '854579518'),
(97, 'HD (200).jpg', 'مجید1', '۲مرداد۱۳۹۵', '854579518'),
(98, 'HD (236).jpg', 'مجید1', '۲مرداد۱۳۹۵', '854579518'),
(99, '6895374-black-abstract.jpg', 'مجید', '۷مرداد۱۳۹۵', '499835485'),
(100, 'Ice-Lamp-Art-Wallpaper-HD.jpg', 'مجید', '۷مرداد۱۳۹۵', '499835485'),
(101, 'new-wallpaper-3_8U2b2Px.jpg', 'مجید', '۷مرداد۱۳۹۵', '499835485'),
(102, '1952774_gP0ftIm.jpg', 'مجید', '۷مرداد۱۳۹۵', '499835485'),
(103, 'Ice-Lamp-Art-Wallpaper-HD.jpg', 'مجید', '۱۰مرداد۱۳۹۵', '505487452'),
(104, '1952774_gP0ftIm.jpg', 'مجید', '۱۰مرداد۱۳۹۵', '505487452'),
(105, 'new-wallpaper-3_8U2b2Px.jpg', 'مجید', '۱۰مرداد۱۳۹۵', '505487452'),
(106, 'new-wallpaper-3_8U2b2Px.jpg', 'مجید', '۱۰مرداد۱۳۹۵', '505487452'),
(107, '1952774_gP0ftIm.jpg', 'مجید', '۱۱مرداد۱۳۹۵', '1011327397'),
(108, '140716662504551.jpg', 'مجید', '۱۳مرداد۱۳۹۶', '1011327397'),
(109, '0_7b7d4_5bc7db6e_XXXL.jpg', 'مجید', '۱۳مرداد۱۳۹۶', '1011327397'),
(110, '0_7b7d4_5bc7db6e_XXXL.jpg', 'مجید', '۲۹آبان۱۳۹۶', '666712575'),
(111, '0_7b7d4_5bc7db6e_XXXL.jpg', 'مجید', '۲۹آبان۱۳۹۶', '306915019'),
(112, 'kids_shampoo_grande.png', 'مجید', '۲۹آبان۱۳۹۶', '306915019'),
(113, '140716662504551.jpg', 'مجید', '۲۹آبان۱۳۹۶', '306915019'),
(114, '[HDAKS.COM]14059_5.jpg', 'مجید', '۶آذر۱۳۹۶', '705921709'),
(115, '[HDAKS.COM]16194_b.jpg', 'مجید', '۶آذر۱۳۹۶', '705921709'),
(116, '[HDAKS.COM]17303_5.jpg', 'مجید', '۶آذر۱۳۹۶', '705921709'),
(117, '[HDAKS.COM]17419_w.jpg', 'مجید', '۶آذر۱۳۹۶', '705921709'),
(122, 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', 'مجید', '۱۶خرداد۱۴۰۰', '450120342'),
(123, 'Twinmos 8GB DDR4 2666Mhz hs (1)-lgr.jpg', 'الناز', '۱۷خرداد۱۴۰۰', '414945160'),
(124, 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', 'الناز', '۱۷خرداد۱۴۰۰', '414945160'),
(125, 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', 'الناز', '۱۷خرداد۱۴۰۰', '414945160'),
(126, 'Toshiba Canvio Flex 1TB (1)-lgr.jpg', 'الناز', '۱۷خرداد۱۴۰۰', '414945160'),
(127, 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '45012034211'),
(128, 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '484142965'),
(129, 'Toshiba Canvio Flex 1TB (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '4841429651'),
(130, 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '6414373203174'),
(131, 'Twinmos 8GB DDR4 2666Mhz hs (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '6414373203174'),
(132, 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '6414373203174'),
(133, 'Toshiba Canvio Flex 1TB (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '6414373203174'),
(134, 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '45869903277979'),
(135, 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '45869903277979'),
(136, 'Twinmos 8GB DDR4 2666Mhz hs (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '45869903277979'),
(137, 'Toshiba Canvio Flex 1TB (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '45869903277979'),
(138, 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '17614101033820'),
(139, 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '17614101033820'),
(140, 'Twinmos 8GB DDR4 2666Mhz hs (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '17614101033820'),
(141, 'Toshiba Canvio Flex 1TB (1)-lgr.jpg', 'زهرا', '۲۴خرداد۱۴۰۰', '17614101033820');

-- --------------------------------------------------------

--
-- Table structure for table `db_roles`
--

DROP TABLE IF EXISTS `db_roles`;
CREATE TABLE IF NOT EXISTS `db_roles` (
  `db_roles_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_roles_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_roles_code` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`db_roles_id`),
  UNIQUE KEY `db_roles_code` (`db_roles_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_roles`
--

INSERT INTO `db_roles` (`db_roles_id`, `db_roles_name`, `db_roles_code`) VALUES
(1, 'مدیر کل ', '1'),
(2, 'نویسنده ', '2'),
(3, 'ویرایشگر ', '3');

-- --------------------------------------------------------

--
-- Table structure for table `db_setting_admin`
--

DROP TABLE IF EXISTS `db_setting_admin`;
CREATE TABLE IF NOT EXISTS `db_setting_admin` (
  `db_setting_admin_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `db_setting_admin_name` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  `db_setting_admin_value` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`db_setting_admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_setting_admin`
--

INSERT INTO `db_setting_admin` (`db_setting_admin_id`, `db_setting_admin_name`, `db_setting_admin_value`) VALUES
(1, 'count_image_slider_sitr', '6'),
(2, 'logo', 'headphones_minimal-1920x1080.jpg'),
(3, 'copyright_fa', 'برنامه نویس و طراحی حمید رضا سامانی'),
(4, 'copyright_en', 'تمامی حقوق سایت متعلق به حمیدرضا سامانی است .'),
(5, 'facebook', 'facebook'),
(7, 'twitter', 'twitter'),
(8, 'skype', 'skype'),
(9, 'takhfif', '10');

-- --------------------------------------------------------

--
-- Table structure for table `db_slider`
--

DROP TABLE IF EXISTS `db_slider`;
CREATE TABLE IF NOT EXISTS `db_slider` (
  `db_slider_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_slider_image` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `db_slider_title` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`db_slider_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_slider`
--

INSERT INTO `db_slider` (`db_slider_id`, `db_slider_image`, `db_slider_title`) VALUES
(4, 'HD (6).jpg', ''),
(5, '[HDAKS.COM]14616_2.jpg', ''),
(7, 'HD (75).jpg', ''),
(8, 'HD (3).jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `db_temprory_factor`
--

DROP TABLE IF EXISTS `db_temprory_factor`;
CREATE TABLE IF NOT EXISTS `db_temprory_factor` (
  `db_temprory_factor_id` int(11) NOT NULL AUTO_INCREMENT,
  `db_temprory_factor_product_code` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_temprory_factor_code` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_temprory_factor_product_count` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_temprory_factor_product_color` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_temprory_factor_product_garanti` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `db_temprory_factor_user_code` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`db_temprory_factor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_temprory_factor`
--

INSERT INTO `db_temprory_factor` (`db_temprory_factor_id`, `db_temprory_factor_product_code`, `db_temprory_factor_code`, `db_temprory_factor_product_count`, `db_temprory_factor_product_color`, `db_temprory_factor_product_garanti`, `db_temprory_factor_user_code`) VALUES
(11, '772149461', '437459444', '1', 'ddddfd', 'ede', '62yuwjk1m'),
(12, '2147483647', '1485114917', '2', 'سیاه', 'گارانتی طلایی ۳ سال', '62yuwjk1m'),
(14, '1011327397', '504352255', '5', '', '', '62yuwjk1m'),
(15, '505487452', '1128745503', '1', 'سیاه ', 'گارانتی یکساله', '62yuwjk1m'),
(16, '306915019', '448321606', '3', 'dsed', 'desed', '62yuwjk1m'),
(17, '450120342', '-182407903', '3', 'صورتی ', 'محصول 991', '62yuwjk1m'),
(18, '484142965', '-182407903', '2', 'ابی ', 'تست 1', '62yuwjk1m'),
(19, 'گمکنتناتل', '-534014190', '1', '.ئمدنذتندمئ.', 'نتذانم', '62yuwjk1m'),
(21, '484142965', '198491892', '2', 'ابی ', 'تست 1', 'ya1xn5196'),
(22, '414945160', '78294187934993', '1', '', 'یکساله شرکتی', '62yuwjk1m'),
(23, '450120342', '278523568888097', '1', 'نقره ای', 'یکساله', '62yuwjk1m'),
(24, '450120342', '342312138287271', '1', 'نقره ای', 'یکساله', 'wyjlb4hcr'),
(25, '450120342', '487820238623732', '1', 'نقره ای', 'یکساله', 'ya1xn5196'),
(26, '450120342', '48130648877146', '1', 'نقره ای', 'یکساله', '');

-- --------------------------------------------------------

--
-- Table structure for table `db_uploaded_file`
--

DROP TABLE IF EXISTS `db_uploaded_file`;
CREATE TABLE IF NOT EXISTS `db_uploaded_file` (
  `uploaded_file_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uploaded_file_src` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `uploaded_file_name` varchar(150) COLLATE utf8_persian_ci NOT NULL,
  `uploaded_file_type` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `uploaded_file_capacity` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `uploaded_file_size` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `uploaded_creater` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `uploaded_file_date` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `uploaded_file_for_post` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`uploaded_file_id`),
  UNIQUE KEY `uploaded_file_name` (`uploaded_file_name`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_uploaded_file`
--

INSERT INTO `db_uploaded_file` (`uploaded_file_id`, `uploaded_file_src`, `uploaded_file_name`, `uploaded_file_type`, `uploaded_file_capacity`, `uploaded_file_size`, `uploaded_creater`, `uploaded_file_date`, `uploaded_file_for_post`) VALUES
(65, '', '[HDAKS.COM]14059_5.jpg', 'image/jpeg', '1183KB', '', 'الناز', '۶آذر۱۳۹۶', ''),
(66, '', '[HDAKS.COM]17303_5.jpg', 'image/jpeg', '603KB', '', 'مجید', '۶آذر۱۳۹۶', ''),
(67, '', '[HDAKS.COM]16194_b.jpg', 'image/jpeg', '621KB', '', 'مجید', '۶آذر۱۳۹۶', ''),
(69, '', '[HDAKS.COM]17419_w.jpg', 'image/jpeg', '423KB', '', 'مجید', '۶آذر۱۳۹۶', ''),
(70, '', 'ACER Aspire 3 A315 i3 4GB 1TB 2GB (1)-lgr.jpg', 'image/jpeg', '61KB', '', 'مجید', '۱۶خرداد۱۴۰۰', ''),
(71, '', 'MSI Radeon RX 6700 XT GAMING X 12G 4-lgr.jpg', 'image/jpeg', '70KB', '', 'مجید', '۱۶خرداد۱۴۰۰', ''),
(73, '', 'Toshiba Canvio Flex 1TB (1)-lgr.jpg', 'image/jpeg', '45KB', '', 'مجید', '۱۶خرداد۱۴۰۰', ''),
(74, '', 'Twinmos 8GB DDR4 2666Mhz hs (1)-lgr.jpg', 'image/jpeg', '33KB', '', 'مجید', '۱۶خرداد۱۴۰۰', '');

-- --------------------------------------------------------

--
-- Table structure for table `db_user`
--

DROP TABLE IF EXISTS `db_user`;
CREATE TABLE IF NOT EXISTS `db_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `user_family` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `user_email` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `user_username` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `user_password` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `user_access` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `user_avatar` text COLLATE utf8_persian_ci NOT NULL,
  `user_lastlogin` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_user`
--

INSERT INTO `db_user` (`user_id`, `user_name`, `user_family`, `user_email`, `user_username`, `user_password`, `user_access`, `user_avatar`, `user_lastlogin`) VALUES
(1, 'حمید رضا', 'سامانی', ' h.r.samani.1379@gmail.com', 'hamid', '101011', '1', '', ''),
(3, '', '', 'admin@gaaamail.com', 'admin', '101010', '1', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `db_user_site`
--

DROP TABLE IF EXISTS `db_user_site`;
CREATE TABLE IF NOT EXISTS `db_user_site` (
  `db_user_site_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `db_user_site_name` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_user_site_family` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_user_site_password` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  `db_user_site_username` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `db_user_site_address` text COLLATE utf8_persian_ci,
  `db_user_site_codeposti` varchar(20) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_user_site_tell` varchar(20) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_user_site_mobile` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_user_site_email` varchar(1000) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_user_site_lastlogin` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `db_user_site_customer_code` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `register_state` int(1) NOT NULL,
  PRIMARY KEY (`db_user_site_id`),
  UNIQUE KEY `db_user_site_username` (`db_user_site_username`),
  UNIQUE KEY `db_user_site_customer_code` (`db_user_site_customer_code`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `db_user_site`
--

INSERT INTO `db_user_site` (`db_user_site_id`, `db_user_site_name`, `db_user_site_family`, `db_user_site_password`, `db_user_site_username`, `db_user_site_address`, `db_user_site_codeposti`, `db_user_site_tell`, `db_user_site_mobile`, `db_user_site_email`, `db_user_site_lastlogin`, `db_user_site_customer_code`, `register_state`) VALUES
(18, 'رضا ', 'حیدری', '۱۱۱۱۱۱', 'reza', 'تبریز', '1023823773', '0413260۴98', '09331190001', 'vahid@gdmail.com', '', '55rpt5lm5', 1),
(19, 'مهدی ', 'وفاداری', '1010', 'mahdi', 'تهران ', '1245664533', '041387893', '09331190093', 'mahdi@ff.com', '', '62yuwjk1m', 1),
(20, 'حسن', 'یاری', '101010', 'hasan', 'تبریز', '1048777332', '041388888', '09331180003', 'mrtarm@gmail.vom', '', 'btb4frwin', 1),
(21, 'زبب', '', 'dddd', 'ddddd', '', '', '', '', '', '', 'fn6yk3juk', 0),
(22, 'سارا', NULL, '123', 'sar', NULL, NULL, NULL, NULL, NULL, NULL, '1703207871', 0),
(23, 'منا', 'محمدی ', '1234', 'mona', 'تهران ', '7657356762', '02176683', '09120986526', 'mona@gmail.com', NULL, 'ya1xn5196', 1),
(24, 'ali', 'aaaa', '1010', 'amidi', 'faseeeeeeeed', '1234567890', '00000000', '09030605208', 'aamidaly@gmail.com', NULL, 'wyjlb4hcr', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
