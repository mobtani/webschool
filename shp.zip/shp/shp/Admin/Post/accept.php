<?php
session_start();
include('../../INCLUDE/functions.php');
define('contact_us_table','db_contactus');

include('../../Classes/Site/contact_us/contact_us.php');
$contact_us=new contact_us();


if(!(isset($_SESSION['user_logged'])))
    header("location:../login_logout/login.php");
if(!empty($_SESSION['name_fa_val']) && !empty($_SESSION['name_en_val']) && !empty($_SESSION['image_selected_name']) && !empty($_SESSION['gheymat_val']) && $_SESSION['name_fa']!="failed"
&& $_SESSION['name_en']!="failed" && !empty($_SESSION['comment']) && $_SESSION['gheymat']!="failed" && $_SESSION['takhfif']!="failed" && !empty($_SESSION['vezheki']))
{
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <title>صفحه اصلی</title>
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
    <link rel="stylesheet" type="text/css"
          href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
</head>
<body>

<div class="container">
    <div class="row">
        <?php
        include('../../Function/Admin/top-menu.php');
        ?>
        <div class="row">
            <div class="col-lg-12 col-xs-12 t_body">
                <?php
                include('../../Function/Admin/right-menu.php');
                ?>
                <div class="col-lg-10 t_left">
                    <div class="col-lg-12 top_n1">
                        <ul>
                            <li><i class="fa fa-home"></i> داشبورد</li>
                            <li class="end" id="clock1"> داشبورد</li>
                            <li class="end"> <?php echo get_date('امروز', ' '); ?> </li>
                        </ul>
                    </div>
                    <div class="bar_top_state">
                        <input type="button" value="ثبت نهایی محصول" id="post_save_final">
                        <input type="button" value="برگشت به عقب" id="goto_index">

                    </div>
                    <div class="col-lg-12 content">
                        <div class="result" style="display: none;"><p></p></div>
                        <div class="col-lg-12 box" style="margin-top: 20px;">
                            <div class="box_content for_table">
                                <table class="table table-striped table-responsive table-bordered wrap">
                                    <thead>
                                    <tr>
                                        <td> تصویر</td>
                                        <td> عنوان</td>
                                        <td> قیمت</td>
                                        <td> تخفیف</td>
                                        <td> کد محصول</td>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    echo '
                                        <tr class="item"">
                                            <td><a href="../../Ajax/Save/images/" target="_blank"><img src="../../Ajax/Save/images/' . $_SESSION['image_selected_name'] . '"></a> </td>
                                            <td>' . $_SESSION['name_fa_val'] . '/' . $_SESSION['name_en_val'] . '</td>
                                            <td>' . $_SESSION['gheymat_val'] . '</td>
                                            <td>' . $_SESSION['takhfif_val'] . '%</td>
                                            <td>' . $_SESSION['post_code'] . '</td>
                                        </tr>
                                        ';
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-12 content">
                        <div class="result" style="display: none;"><p></p></div>
                        <div class="col-lg-12 box upload_form">
                            <div class="box_content">
                                <div class="form_row form_upload">
                                    <form id="uploadForm_slider" action="upload.php" method="post">
                                        <div id="uploadFormLayer">
                                            <input name="userImage" type="file" class="inputFile"/>
                                            <input type="submit" value="آپلود کن ..." class="btnSubmit"/>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-12 box" style="margin-top: 20px;">
                            <div class="box_content uploaded_list" id="uploaded_file">

                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Ajax/Send/Admin/upload/upload.js"></script>


<script type="">
    $(document).ready(
        function () {
            $('.level_2').each(
                function () {
                    $(this).text('-' + $(this).text());
                }
            );
            $('.level_3').each(
                function () {
                    $(this).text('--' + $(this).text());
                }
            );
            $('.level_4').each(
                function () {
                    $(this).text('---' + $(this).text());
                }
            );
            $('.level_5').each(
                function () {
                    $(this).text('----' + $(this).text());
                }
            );
            $('.level_6').each(
                function () {
                    $(this).text('-----' + $(this).text());
                }
            );
        }
    );
</script>
<script type="text/javascript">
    jQuery(document).ready(function () {
        // Infinite Ajax Scroll configuration
        jQuery.ias({
                container: '.wrap', // main container where data goes to append
                item: '.item', // single items
                pagination: '.nav', // page navigation
                next: '.nav a' // next page selector
            })
            .extension(new IASSpinnerExtension())
            .extension(new IASTriggerExtension({offset: 5}));
    });
</script>
<?php
}else{
    header("location:general.php");
    exit();
}
?>
</body>
</html>