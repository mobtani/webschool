<?php
session_start();
include('../../INCLUDE/functions.php');
include_once("../../Classes/connect.php");
include('../../Classes/Post/post.php');
define('contact_us_table','db_contactus');

$post=new post();
$connect=new Connection();

include('../../Classes/Site/contact_us/contact_us.php');
$contact_us=new contact_us();


if(!(isset($_SESSION['user_logged'])))
    header("location:../login_logout/login.php");
if(!empty($_SESSION['name_fa_edit']) && !empty($_SESSION['name_en_edit']) && !empty($_SESSION['e_image_selected_name']) && !empty($_SESSION['gheymat_edit']) && @$_SESSION['e_name_fa']!="failed"
&& @$_SESSION['e_name_en']!="failed" && !empty($_SESSION['comment_edit']) && @$_SESSION['e_gheymat']!="failed" && @$_SESSION['e_takhfif']!="failed" && !empty($_SESSION['vezheki_edit']))
{
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <title>صفحه اصلی</title>
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
    <link rel="stylesheet" type="text/css"
          href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
</head>
<body>

<div class="container">
    <div class="row">
        <?php
        include('../../Function/Admin/top-menu.php');
        ?>
        <div class="row">
            <div class="col-lg-12 col-xs-12 t_body">
                <?php
                include('../../Function/Admin/right-menu.php');
                ?>
                <div class="col-lg-10 t_left">
                    <div class="col-lg-12 top_n1">
                        <ul>
                            <li><i class="fa fa-home"></i> داشبورد</li>
                            <li class="end" id="clock1"> داشبورد</li>
                            <li class="end"> <?php echo get_date('امروز', ' '); ?> </li>
                        </ul>
                    </div>
                    <div class="bar_top_state">
                        <input type="button" value="ویرایش نهایی محصول" id="post_edit_final">
                        <input type="button" value="برگشت به عقب" id="goto_edit">
                    </div>
                    <div class="col-lg-12 content">
                        <div class="result" style="display: none;"><p></p></div>
                        <div class="col-lg-12 box" style="margin-top: 20px;">
                            <div class="box_content for_table">
                                <table class="table table-striped table-responsive table-bordered wrap">
                                    <thead>
                                    <tr>
                                        <td> تصویر</td>
                                        <td> عنوان</td>
                                        <td> قیمت</td>
                                        <td> تخفیف</td>
                                        <td> کد محصول</td>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    echo '
                                        <tr class="item"">
                                            <td><a href="../../Ajax/Save/images/' . $_SESSION['e_image_selected_name'] . '" target="_blank"><img src="../../Ajax/Save/images/' . $_SESSION['e_image_selected_name'] . '"></a> </td>
                                            <td>' . $_SESSION['name_fa_edit'] . '/' . $_SESSION['name_en_edit'] . '</td>
                                            <td>' . $_SESSION['gheymat_edit'] . '</td>
                                            <td>' . $_SESSION['takhfif_edit'] . '%</td>
                                            <td id="code_edit_post">' . $_SESSION['code_edit'] . '</td>
                                        </tr>
                                        ';
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <div class="bar_top_state">
                        <input type="button" value="خالی کردن اسلایدر" id="empty_slider">
                    </div>

                    <div class="col-lg-12 content">
                        <div class="col-lg-12 box upload_form">
                            <div class="box_content">
                                <div class="form_row form_upload">
                                        <div id="uploadFormLayer">
                                            <input type="submit" value="ثبت تصویر" data-toggle="modal" data-target="#myModal">
                                        </div>
                                </div>
                                <div class="the_image_thumbnail" >
                                    <!-- Modal -->
                                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                    <i class="fa fa-sign-in"></i><h4 class="modal-title" id="myModalLabel"> ورود به سایت </h4>
                                                </div>
                                                <div class="modal-body" id="testDivNested">
                                                    <?php
                                                    $items_post_image=$post->showData_image('db_uploaded_file');
                                                    foreach ($items_post_image as $i_p_i){
                                                        echo '
                                                                <img src="../../Ajax/Save/images/'.$i_p_i['uploaded_file_name'].'" alt="" data-id='.$i_p_i['uploaded_file_id'].'>
                                                            ';
                                                    }
                                                    ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <p>نام : </p><p id="pic_name" > </p>
                                                    <p>نوع : </p><p id="pic_type"> </p>
                                                    <p>حجم : </p><p id="pic_size"> </p>

                                                    <button type="button" class="btn btn-primary" id="save_image_post"> انتخاب کن ! </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>


                        <div class="col-lg-12 box" style="margin-top: 20px;">
                            <div class="title"><p><i class="fa fa-bars"></i> تصاویر اپلود شده جدید  </p> </div>
                            <div class="box_content uploaded_list" id="uploaded_file">

                            </div>


                        </div>
                        <div class="col-lg-12 box" style="margin-top: 20px;">
                            <div class="title"><p><i class="fa fa-bars"></i> تصاویر اپلود شده قدیمی  </p> </div>

                            <div class="box_content uploaded_list1">
                                <?php
                                //$array_t=explode("^",$_SESSION['result_g']);
                                    foreach ($_SESSION['result_g'] as $r){
                                        echo '
                                          <div class="uploaded_file">
                                    <div class="title_file" id="delete_img_slide">
                                        <a href="#" data-name="'.$r.'"> <i class="fa fa-trash"></i></a>
                                    </div>
                                    <div class="state_file">
                                        <img src="../../Ajax/Save/images/'.$r.'">
                                    </div> 
                                </div>
                                        ';
                                    }
                                ?>
                            </div>

                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Ajax/Send/Admin/post/accept_edit.js"></script>

<?php
}else{
    header("location:show.php");
    exit();
}
?>

</body>
</html>