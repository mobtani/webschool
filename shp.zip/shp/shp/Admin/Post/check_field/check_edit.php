<?php
//name_farsi
session_start();
if(isset($_POST['name_fa'])){
    $test=preg_match('/^[پچجحخهعغفقثصضشسیبلاتنمکگوئدذرزطظژؤإأءًٌٍَُِّ\s\n\r\t\d\(\)\[\]\{\}-]+$/',$_POST['name_fa']);
    if($test==false){
        $_SESSION['e_name_fa']="failed";
        echo "1";
    }
    else{
        $_SESSION['e_name_fa']="";
        echo "2";
    }}
//name_english
if(isset($_POST['name_en'])){
    $test=preg_match('/[A-Za-z0-9]/',$_POST['name_en']);
    if($test==false){
        $_SESSION['e_name_en']="failed";
        echo "1";
    }
    else{
        $_SESSION['e_name_en']="";
        echo "2";
    }}
//gheymat
if(isset($_POST['gheymat'])){
    $test=preg_match('/[^0-9]/',$_POST['gheymat']);
    if($test==true){
        $_SESSION['e_gheymat']="failed";
        echo "1";
    }
    else{
        $_SESSION['e_gheymat']="";
        echo "2";
    }}
//takhfif
if(isset($_POST['takhfif'])){
    $test=preg_match('/[^0-9]/',$_POST['takhfif']);
    if($test==true){
        $_SESSION['e_takhfif']="failed";
        echo "1";
    }
    else{
        $_SESSION['e_takhfif']="";
        echo "2";
    }}

