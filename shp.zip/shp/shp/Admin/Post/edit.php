<?php
include_once("../../Classes/connect.php");
include_once("../../Classes/Cat/cat.php");
include('../../Classes/User/user.php');
include('../../Classes/Post/post.php');
include('../../INCLUDE/functions.php');
define('contact_us_table','db_contactus');

$user=new user();
$category=new category();
$post=new post();
$connect=new Connection();

include('../../Classes/Site/contact_us/contact_us.php');
$contact_us=new contact_us();

if(!(isset($_SESSION['user_logged'])))
    header("location:../login_logout/login.php");
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no"><title>صفحه اصلی</title>
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
    <link rel="stylesheet" type="text/css" href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
    <script src="../../Script/ckeditor/ckeditor.js"></script>


</head>
<body>
<div class="container">
    <div class="row">
        <?php
        include('../../Function/Admin/top-menu.php');
        ?>
        <div class="row">
            <div class="col-lg-12 col-xs-12 t_body">
                <?php
                include('../../Function/Admin/right-menu.php');
                ?>
                <div class="col-lg-10 t_left">
                    <div class="col-lg-12 top_n1">
                        <ul>
                            <li><i class="fa fa-home"></i> داشبورد </li>
                            <li class="end" id="clock1"> داشبورد </li>
                            <li class="end"> <?php echo get_date('امروز',' '); ?> </li>
                        </ul>
                    </div>
                    <div class="col-lg-12 content">
                        <div class="result" style="background-color: transparent">

                        </div>
                        <div class="col-lg-8 box">
                            <div class="title"><p><i class="fa fa-bars"></i> ویرایش / <?= @$_SESSION['name_fa_edit'] ?> </p> </div>
                            <div class="box_content">
                                <div class="form_row">
                                    <label> عنوان فارسی : <p class="name_fa" style="display: none; color: #d10d40"> </p> </label>
                                    <input type="text" value="<?= @$_SESSION['name_fa_edit']; ?>" data-toggle="tooltip" data-placement="top" title=" لطفا نام محصول را به صورت فارسی وارد کنید ..." id="name_fa">
                                </div>
                                <div class="form_row">
                                    <label>  عنوان انگلیسی : <p class="name_en" style="display: none; color: #d10d40"> </p></label>
                                    <input type="text" value="<?= @$_SESSION['name_en_edit']; ?>" data-toggle="tooltip" data-placement="top" title=" لطفا نام محصول را به صورت انگلیسی وارد کنید ..." id="name_en">
                                </div>
                                <div class="form_row">
                                    <label >توضیحات محصول :</label>
                                    <textarea name="editor1" class="post_comment" id="editor1"><?= @$_SESSION['comment_edit']; ?></textarea>
                                </div>
                                <div class="form_row">
                                    <label>ویژگیهای محصول : (لطفا با ! از هم جدا کنید )</label>
                                    <textarea name="editor2" class="post_vezheki" id="editor2"><?= @$_SESSION['vezheki_edit']; ?></textarea>
                                </div>

                            </div>
                        </div>
                        <div class="col-lg-3 left_box">
                            <div class="col-lg-12 box ">
                                <div class="title"><p><i class="fa fa-bars"></i> ذخیره در </p> </div>
                                <div class="box_content">
                                        <input type="submit" value="ویرایش" id="post_edit">
                                </div>
                            </div>
                            <div class="col-lg-12 box pull-left">
                                <div class="title"><p><i class="fa fa-bars"></i> نمایش دسته ها </p> </div>
                                <div class="box_content">
                                    <div class="form_row">
                                        <select name="cat_parent" id="cat_parent">
                                            <option selected value="null"> هیچ کدام </option>
                                            <?php
                                            $rows = $category->showData("db_menu");
                                            $items = $rows;
                                            $id = '';
                                            $i=1;
                                            foreach($items as $item){
                                                if($item['menu_parent_id'] == 0){
                                                    echo "<option name='cat' value='".$item['menu_id']."' class='level_1'>".$item['menu_name']."</option>";
                                                    $id = $item['menu_id'];
                                                    sub($items, $id,($i+1));
                                                }
                                            }
                                            ?>
                                            <?php
                                            function sub($items, $id,$j){
                                                foreach($items as $item){
                                                    if($item['menu_parent_id'] == $id){
                                                        echo"<option name='cat' value='".$item['menu_id']."' class='level_".$j." '>".$item['menu_name']."</option>";
                                                        sub($items, $item['menu_id'],$j+1);
                                                    }
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 box pull-left">
                                <div class="title"><p><i class="fa fa-bars"></i> گارانتی </p> </div>
                                <div class="box_content">
                                    <div class="form_row">
                                        <input type="text" data-toggle="tooltip" data-placement="top" title=" لطفا گارانتی محصول را نوشته و دکمه ثبت را بزنید تعداد نامحدود" id="garanti">
                                        <p class="garanti" style="display: none; color: #d10d40"> لطفا نام گارانتی را بنویسید </p>
                                    </div>
                                    <input type="submit" value="ثبت گارانتی" id="save_garanti">
                                    <input type="submit" value="خالی کردن گارانتی" id="empty_garanti">
                                    <div class="form_row">
                                        <select id="select_garanti">
                                            <option>گارانتی های ثبت شده برای این محصول</option>
                                            <?php
                                            $array_garanti=explode(",",$_SESSION['garanti_edit']);
                                            foreach ($array_garanti as $array) {
                                                echo '
                                            <option>'.$array.'</option>
                                            ';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 box pull-left">
                                <div class="title"><p><i class="fa fa-bars"></i> رنگ بندی </p> </div>
                                <div class="box_content">
                                    <div class="form_row">
                                        <input type="text" data-toggle="tooltip" data-placement="top" title=" لطفا رنگ محصول را نوشته و دکمه ثبت را بزنید تعداد نامحدود" id="color">
                                        <p class="color" style="display: none; color: #d10d40"> لطفا نام رنگ را بنویسید </p>
                                    </div>
                                    <input type="submit" value="ثبت رنگ" id="save_color">
                                    <input type="submit" value="خالی کردن گارانتی" id="empty_color">
                                    <div class="form_row">
                                        <select id="select_color">
                                            <option>رنگ های ثبت شده برای این محصول</option>
                                            <?php
                                                $array_color=explode(",",$_SESSION['color_edit']);
                                                foreach ($array_color as $array){
                                                    echo'
                                                    <option>'.$array.'</option>
                                                    ';
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 box pull-left">
                                <div class="title"><p><i class="fa fa-bars"></i> قیمت [ریال] </p> </div>
                                <div class="box_content">
                                    <div class="form_row">
                                        <input type="text" value="<?= @$_SESSION['gheymat_edit']; ?>" data-toggle="tooltip" data-placement="top" title=" لطفا قیمت محصول را به ریال وارد کنید" id="gheymat">
                                        <p class="gheymat" style="display: none; color: #d10d40">  </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 box pull-left">
                                <div class="title"><p><i class="fa fa-bars"></i> تخفیف </p> </div>
                                <div class="box_content">
                                    <div class="form_row">
                                        <input type="text" value="<?= @$_SESSION['takhfif_edit']; ?>" data-toggle="tooltip" data-placement="top" title=" لطفا تخفیف محصول را به صورت عدد وارد کنید مثلا 10 برابر است با 10%" id="takhfif">
                                        <p class="takhfif" style="display: none; color: #d10d40">  </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 box pull-left">
                                <div class="title"><p><i class="fa fa-bars"></i> تصویر شاخص </p> </div>
                                <div class="box_content">
                                    <div class="form_row" id="image_of_post">
                                        <img src="../../Ajax/Save/images/<?= @$_SESSION['e_image_selected_name']; ?>" style="width: 100%; height: 200px;">
                                    </div>
                                    <input type="submit" value="ثبت تصویر" data-toggle="modal" data-target="#myModal">
                                </div>
                                <div class="the_image_thumbnail" >
                                    <!-- Modal -->
                                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                    <i class="fa fa-sign-in"></i><h4 class="modal-title" id="myModalLabel"> ورود به سایت </h4>
                                                </div>
                                                <div class="modal-body" id="testDivNested">
                                                    <?php
                                                        $items_post_image=$post->showData_image('db_uploaded_file');
                                                        foreach ($items_post_image as $i_p_i){
                                                            echo '
                                                                <img src="../../Ajax/Save/images/'.$i_p_i['uploaded_file_name'].'" alt="" data-id='.$i_p_i['uploaded_file_id'].'>
                                                            ';
                                                        }
                                                    ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <p>نام : </p><p id="pic_name"> </p>
                                                    <p>نوع : </p><p id="pic_type"> </p>
                                                    <p>حجم : </p><p id="pic_size"> </p>

                                                    <button type="button" class="btn btn-primary" id="save_image_post"> انتخاب کن ! </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Ajax/Send/Admin/post/edit.js"></script>


<script type="">
    $(document).ready(
        function(){
            $('.level_2').each(
                function(){
                    $(this).text('-'+$(this).text());
                }
            );
            $('.level_3').each(
                function(){
                    $(this).text('--'+$(this).text());
                }
            );
            $('.level_4').each(
                function(){
                    $(this).text('---'+$(this).text());
                }
            );
            $('.level_5').each(
                function(){
                    $(this).text('----'+$(this).text());
                }
            );
            $('.level_6').each(
                function(){
                    $(this).text('-----'+$(this).text());
                }
            );
        }
    );
</script>
<script>
    $(document).ready(function(e) {
        $("#cat_parent").val(<?php echo @$_SESSION['category_edit'];; ?>);
        ////////

    });
</script>

</body>
</html>