<?php
define('post_table','db_post');

include_once("../../Classes/connect.php");
include_once("../../Classes/Cat/cat.php");
include_once("../../Classes/Post/post.php");
include('../../Classes/User/user.php');
include('../../INCLUDE/functions.php');
define('contact_us_table','db_contactus');

include('../../Classes/Site/contact_us/contact_us.php');
$contact_us=new contact_us();

$user=new user();
$category=new category();
$post=new post();
$connect=new Connection();

if(!(isset($_SESSION['user_logged'])))
    header("location:../login_logout/login.php");
if($_SESSION['user_access']=="3")
    header("location:../error/not_acces.php");

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <title>انبارداری</title>
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
    <link rel="stylesheet" type="text/css" href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
</head>
<body>
<div class="container">
    <div class="row">
        <?php
        include('../../Function/Admin/top-menu.php');
        ?>
        <div class="row">
            <div class="col-lg-12 col-xs-12 t_body">
                <?php
                include('../../Function/Admin/right-menu.php');
                ?>
                <div class="col-lg-10 t_left">
                    <div class="col-lg-12 top_n1">
                        <ul>
                            <li><i class="fa fa-home"></i> داشبورد / انبارداری </li>
                            <li class="end" id="clock1"> </li>
                            <li class="end"> <?php echo get_date('امروز',' '); ?> </li>
                        </ul>
                    </div>
                    <div class="col-lg-12 content">
                        <div class="result" style="display: none; width: 100%"><p></p></div>
                        <div class="col-lg-4 box">
                            <div class="title"><p><i class="fa fa-bars"></i>انبارداری </p> </div>
                            <div class="box_content">
                                <div class="form_row">
                                    <label> تعداد : </label>
                                    <input type="text" placeholder="تعداد" name="count" id="count">
                                </div>
                                <div class="form_row">
                                    <label> نام محصول : </label>
                                    <select name="product_name" id="product_name">
                                        <option selected value="null"> انتخاب کنید ... </option>
                                        <?php
                                        $rows = $post->showData_post(post_table);
                                        $items = $rows;
                                        $id = '';
                                        $i=1;
                                        foreach($items as $item){
                                                echo "<option name='cat' value='".$item['db_post_code']."' class='level_1'>".$item['db_post_name_fa']."</option>";
                                            }
                                        ?>
                                    </select>
                                </div>
                                <div class="form_row">
                                    <input type="submit" value="ثبت " name="register_anbar" id="register_anbar">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Ajax/Send/Admin/anbar/index.js"></script>
</body>
</html>