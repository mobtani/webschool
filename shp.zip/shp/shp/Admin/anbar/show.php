<?php
session_start();
define('contact_us_table','db_contactus');
define('db_anbar','db_anbar');
define('post_table','db_post');

include('../../INCLUDE/functions.php');
include_once("../../Classes/connect.php");
include('../../Classes/Site/contact_us/contact_us.php');
require_once ('../../Classes/Cat/cat.php');

$category=new category();
$contact_us=new contact_us();
$connect=new Connection();

if(!(isset($_SESSION['user_logged'])))
    header("location:../../Admin/login_logout/login.php");

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <title> انبارداری</title>
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
    <link rel="stylesheet" type="text/css"
          href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/jquery.dataTables.css">
</head>
<body>

<div class="container">
    <div class="row">
        <?php
        include('../../Function/Admin/top-menu.php');
        ?>
        <div class="row">
            <div class="col-lg-12 col-xs-12 t_body">
                <?php
                include('../../Function/Admin/right-menu.php');
                ?>
                <div class="col-lg-10 t_left">
                    <div class="col-lg-12 top_n1">
                        <ul>
                            <li><i class="fa fa-home"></i> داشبورد / انبارداری</li>
                            <li class="end" id="clock1"> داشبورد</li>
                            <li class="end"> <?php echo get_date('امروز', ' '); ?> </li>
                        </ul>
                    </div>
                    <div class="col-lg-12 content">
                        <div class="alert alert-success alert-dismissible" role="alert" style="display: none">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <p></p>
                        </div>
                        <div class="alert alert-warning alert-dismissible" role="alert" style="display: none">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <p></p>
                        </div>
                        <div class="col-lg-12 box" style="margin-top: 20px;">
                            <div class="box_content">
                                <table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>نام محصول </th>
                                        <th>کد محصول </th>
                                        <th>تعداد </th>
                                        <th> ویرایش </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $array=$category->showData_anbar(db_anbar);
                                    $i=0;
                                    foreach ($array as $result) {
                                        $product_name=$category->fetch_product_name_by_code(post_table,$result['db_anbar_product_code']);
                                        $i++;
                                        echo '
                                          <tr class="odd gradeX">
                                              <td>'.$i.'</td>
                                              <td>'.$product_name.'</td>
                                              <td>'.$result['db_anbar_product_code'].'</td>
                                              <td>'.$result['db_anbar_product_count'].'</td>
                                              <td id="edit_anbar">
                                              <a href="#" data-action="increase" data-id="'.$result['db_anbar_id'].'"> + </a>
                                              <a href="#" data-action="decrease" data-id="'.$result['db_anbar_id'].'"> - </a>
                                              <a href="#" data-action="delete" data-id="'.$result['db_anbar_id'].'"><i class="fa fa-trash-o"></i></a>

                                              </td>
                                              ';
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Script/Admin/jquery.dataTables.js"></script>
<script src="../../Ajax/Send/Admin/anbar/index.js"></script>

<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        $('#example').dataTable();
    } );
</script>

</body>
</html>