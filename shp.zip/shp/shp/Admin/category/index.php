<?php
include_once("../../Classes/connect.php");
include_once("../../Classes/Cat/cat.php");
include('../../Classes/User/user.php');
include('../../INCLUDE/functions.php');
define('contact_us_table','db_contactus');
include('../../Classes/Site/contact_us/contact_us.php');
$contact_us=new contact_us();

$user=new user();
$category=new category();
$connect=new Connection();

if(!(isset($_SESSION['user_logged'])))
    header("location:../login_logout/login.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no"><title>افزودن دسته جدید</title>
<link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
<link rel="stylesheet" type="text/css" href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
</head>
<body>
	<div class="container">
    	<div class="row">
            <?php
            include('../../Function/Admin/top-menu.php');
            ?>
            <div class="row">
                <div class="col-lg-12 col-xs-12 t_body">
                    <?php
                    include('../../Function/Admin/right-menu.php');
                    ?>
                    <div class="col-lg-10 t_left">
                    	<div class="col-lg-12 top_n1">
                        	<ul>
                            	<li><i class="fa fa-home"></i> داشبورد / افزودن دسته جدید </li>
                                <li class="end" id="clock1"> </li>
                                <li class="end"> <?php echo get_date('امروز',' '); ?> </li>
                            </ul>
                        </div>
                        <div class="col-lg-12 content">
                         <div class="result" style="display: none; width: 100%"><p></p></div>
                        	<div class="col-lg-4 box">
                            	<div class="title"><p><i class="fa fa-bars"></i>افزودن دسته جدید </p> </div>
								<div class="box_content">
                                	<div class="form_row">
                                    	<label> نام </label>
                                    	<input type="text" placeholder="نام دسته" name="name" id="cat_name">
                                    </div>
                                    <div class="form_row">
                                    	<label> مادر </label>
                                        	<select name="cat_parent" id="cat_parent">
                                            		<option selected value="null"> هیچ کدام </option>
												    <?php
                                                        $rows = $category->showData("db_menu");
														$items = $rows;
														$id = '';
														$i=1;
														foreach($items as $item){
															if($item['menu_parent_id'] == 0){
	echo "<option name='cat' value='".$item['menu_id']."' class='level_1'>".$item['menu_name']."</option>";
																$id = $item['menu_id'];
																sub($items, $id,($i+1));
															}
														}
													?>
                                                        <?php
															function sub($items, $id,$j){
																foreach($items as $item){
																	if($item['menu_parent_id'] == $id){
																		echo"<option name='cat' value='".$item['menu_id']."' class='level_".$j." '>".$item['menu_name']."</option>";
																		sub($items, $item['menu_id'],$j+1);
																	}
																}
															}
														?>

                                            </select> 
                                    </div>
                                    <div class="form_row">
                                    	<input type="submit" value="ثبت دسته" name="register_cat" id="register_cat">
                                    </div>
                                </div>
                            </div>
                           <div class="col-lg-7 box pull-left">
                            	<div class="title"><p><i class="fa fa-bars"></i> نمایش دسته ها </p> </div>
								<div class="box_content show_category" id="testDivNested">
									<ul id="menu_show">
                                        <?php
                                        $rows = $category->showData("db_menu");
                                        $items = $rows;
                                        $id = '';
                                        $i=1;
                                        foreach($items as $item){
                                            if($item['menu_parent_id'] == 0){                            
											echo "<li><i class='fa fa-angle-double-left'></i>".$item['menu_name'].""?>
                                            <?php echo '
                                            	<ul class="tools">
                                                	<li id="action" data-action="delete" data-id="'.$item['menu_id'].'"> حذف </li>
                                                	<li id="action" data-action="edit" data-id="'.$item['menu_id'].'"> ویرایش </li>
                                                </ul>
												';
												?>
                                            <?php
											echo '
											</li>';
                                                $id = $item['menu_id'];
                                                sub1($items, $id,($i+1));
                                            }
                                        }
                                        ?>
                                        <?php
                                        function sub1($items, $id,$j){
                                            echo'<ul>';
                                            foreach($items as $item){
                                                if($item['menu_parent_id'] == $id){
                                                    echo"<li><i class='fa fa-angle-left'></i>".$item['menu_name'].""?>
                                                    <?php echo '
                                            	<ul class="tools">
                                                	<li id="action" data-action="delete" data-id="'.$item['menu_id'].'"> حذف </li>
                                                	<li id="action" data-action="edit" data-id="'.$item['menu_id'].'"> ویرایش </li>
                                                </ul>
												';
                                                    ?>
                                                    <?php
													echo'
													</li>';
                                                    sub1($items, $item['menu_id'],$j+1);
                                                }
                                            }
                                            echo '</ul>';
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>

                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
    <script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Ajax/Send/Admin/category/index.js"></script>

    <script type="">
        $(document).ready(
            function(){
                $('.level_2').each(
                    function(){
                        $(this).text('-'+$(this).text());
                    }
                );
                $('.level_3').each(
                    function(){
                        $(this).text('--'+$(this).text());
                    }
                );
                $('.level_4').each(
                    function(){
                        $(this).text('---'+$(this).text());
                    }
                );
                $('.level_5').each(
                    function(){
                        $(this).text('----'+$(this).text());
                    }
                );
                $('.level_6').each(
                    function(){
                        $(this).text('-----'+$(this).text());
                    }
                );
            }
        );
    </script>

</body>
</html>