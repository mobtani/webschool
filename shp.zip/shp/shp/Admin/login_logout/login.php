<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ورود به پنل</title>
<link rel="stylesheet" type="text/css" href="../../Style/Admin/login/login-style.css">
    <link rel="stylesheet" type="text/css" href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <script src="../../Script/Main/jquery-1.11.1.min.js"></script>


</head>
<body>
<div class="main" align="center">
<div class="info">
<img src="../../Image/Optimization-icon.png" width="80px" height="80px">
<p> ورود به سیستم مدیریت </p>
</div>
        <div class="main-form">
            <div class="username">
            <label> نام کاربری :</label>
            <input type="text" name="username" placeholder="نام کاربری " id="username" value="<?= @$_COOKIE['username'] ?>"><br>
            </div>
            <div class="password">
            <label>گذرواژه :</label>
            <input type="password" name="password" type="" placeholder="گذرواژه" id="password" value="<?= @$_COOKIE['password'] ?>" >
            </div>
            <div class="button">
            <input type="submit" name="login" value="ورود" id="btn">
            <label id="message"><?php echo @$message;?></label>
            </div>
        </div>
    </div>
<div class="result" style="display: none"><p></p></div>
<script src="../../Ajax/Send/Admin/login/login.js"></script>
</body>
</html>
