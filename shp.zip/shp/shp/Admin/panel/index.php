<?php
	session_start();
	include('../../INCLUDE/functions.php');
	include_once("../../Classes/connect.php");
	define('contact_us_table','db_contactus');
	include('../../Classes/Site/contact_us/contact_us.php');
	$contact_us=new contact_us();
	$connect=new Connection();
	
	
if(!(isset($_SESSION['user_logged'])))
    header("location:../login_logout/login.php");
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no"><title>صفحه اصلی</title>
<link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
<link rel="stylesheet" type="text/css" href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
</head>
<body>
	<div class="container">
    	<div class="row">
        <?php
			include('../../Function/Admin/top-menu.php');
		?>
            <div class="row">
            	<div class="col-lg-12 col-xs-12 t_body">
        <?php
			include('../../Function/Admin/right-menu.php');
		?>

                    <div class="col-lg-10 t_left">
                    	<div class="col-lg-12 top_n1">
                        	<ul>
                            	<li><i class="fa fa-home"></i> داشبورد </li>
                                <li class="end" id="clock1"> داشبورد </li>
                                <li class="end"> <?php echo get_date('امروز',' '); ?> </li>
                            </ul>
                        </div>
                        <div class="col-lg-12 content">
							<div class="dashboard_box">
                            	<ul>
                                	<li class="col-lg-3">
                                        <a href="../category/" target="_blank">
                                     	<div class="box">
                                        	<i class="fa fa-sitemap"></i>
                                            <div class="title">
                                            	<h1> دسته بندی ها</h1>
                                            </div>
                                        </div>
                                        </a>
                                    </li>
                                	<li class="col-lg-3">
                                        <a href="../Post/show.php" target="_blank">
                                     	<div class="box">
                                        	<i class="fa fa-shopping-cart"></i>
                                            <div class="title">
                                            	<h1> محصولات </h1>
                                            </div>
                                        </div>
                                        </a>
                                    </li>
                                	<li class="col-lg-3">
                                        <a href="../upload_center/upload.php" target="_blank">
                                     	<div class="box">
                                        	<i class="fa fa-upload"></i>
                                            <div class="title">
                                            	<h1> آپلود سنتر</h1>
                                            </div>
                                        </div>
                                        </a>
                                    </li>
                                	<li class="col-lg-3">
                                        <a href="../users/show.php" target="_blank">
                                     	<div class="box">
                                            <i class="fa fa-users"></i>
                                            <div class="title">
                                            	<h1> کاربران</h1>
                                            </div>
                                        </div>
                                        </a>
                                    </li>
                                	<li class="col-lg-3">
                                        <a href="../../site/contact_us/show.php" target="_blank">
                                        <div class="box">
                                            <i class="fa fa-envelope"></i>
                                            <div class="title">
                                            	<h1>  تماس با ما ها </h1>
                                            </div>
                                        </div>
                                        </a>
                                    </li>
                                	<li class="col-lg-3">
                                        <a href="../../Admin/factors/show.php" target="_blank">
                                        <div class="box">
                                            <i class="fa fa-cart-plus"></i>
                                            <div class="title">
                                            	<h1> خرید ها</h1>
                                            </div>
                                        </div>
                                            </a>
                                    </li>
                                	<li class="col-lg-3">
                                        <a href="../../Admin/customer/show.php" target="_blank">
                                        <div class="box">
                                            <i class="fa fa-users"></i>
                                            <div class="title">
                                            	<h1> مشتریان</h1>
                                            </div>
                                        </div>
                                            </a>
                                    </li>
                                	<li class="col-lg-3">
                                        <a href="../../Admin/setting/general.php" target="_blank">
                                        <div class="box">
                                            <i class="fa fa-cog"></i>
                                            <div class="title">
                                            	<h1> تنظیمات </h1>
                                            </div>
                                        </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Ajax/Send/Admin/index.js"></script>
</body>
</html>