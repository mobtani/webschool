<?php
define('contact_us_table','db_contactus');

include_once("../../Classes/connect.php");
include_once("../../Classes/Cat/cat.php");
include('../../Classes/User/user.php');
include('../../Classes/Site/contact_us/contact_us.php');
$contact_us=new contact_us();

include('../../INCLUDE/functions.php');

$user=new user();
$category=new category();
$connect=new Connection();

if(!(isset($_SESSION['user_logged'])))
    header("location:../login_logout/login.php");
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <title>ویرایش کاربر </title>
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
    <link rel="stylesheet" type="text/css" href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
</head>
<body>
<div class="container">
    <div class="row">
        <?php
        include('../../Function/Admin/top-menu.php');
        ?>
        <div class="row">
            <div class="col-lg-12 col-xs-12 t_body">
                <?php
                include('../../Function/Admin/right-menu.php');
                ?>
                <div class="col-lg-10 t_left">
                    <div class="col-lg-12 top_n1">
                        <ul>
                            <li><i class="fa fa-home"></i> داشبورد / ویرایش کاربر  </li>
                            <li class="end" id="clock1"> </li>
                            <li class="end"> <?php echo get_date('امروز',' '); ?> </li>
                        </ul>
                    </div>
                    <div class="col-lg-12 content">
                        <div class="result" style="display: none; width: 100%"><p></p></div>
                        <div class="col-lg-5 box">
                            <div class="title"><p><i class="fa fa-bars"></i>ویرایش کاربر </p> </div>
                            <div class="box_content">
                                <div class="form_row">
                                    <label> نام : </label>
                                    <input type="text" value="<?php echo $_SESSION['user_name']; ?>" placeholder="نام دسته" name="name" id="name">
                                </div>
                                <div class="form_row">
                                    <label> نام خانوادگی : </label>
                                    <input type="text" value="<?php echo $_SESSION['user_family']; ?>" placeholder="نام دسته" name="family" id="family">
                                </div>
                                <div class="form_row">
                                    <label> ایمیل : </label>
                                    <input type="email" value="<?php echo $_SESSION['user_email']; ?>" placeholder="ایمیل" name="email" id="email">
                                </div>
                                <div class="form_row">
                                    <label> نام کاربری : </label>
                                    <input type="text" value="<?php echo $_SESSION['user_username']; ?>" placeholder="نام دسته" name="username" id="username">
                                </div>
                                <div class="form_row">
                                    <label> رمز : </label>
                                    <input type="text" value="<?php echo $_SESSION['user_pass']; ?>" placeholder="نام دسته" name="pass" id="pass">
                                </div>

                                <?php
                                if($_SESSION['user_access']=="1") {
                                    echo '
                                <div class="form_row">
                                    <label> نقش </label>
                                    <select name="role1" id="role">
                                        <option selected value="1"> مدیرکل  </option>
                                        <option selected value="2"> نویسنده  </option>
                                        <option selected value="3"> ویرایشگر  </option>
                                    </select>
                                </div>

                                ';
                                }
                                else if($_SESSION['user_access']=="1"){
                                    echo '
                                <div class="form_row">
                                    <label> نقش </label>
                                    <select name="role1" id="role">
                                        <option selected value="2"> نویسنده  </option>
                                    </select>
                                </div>

                                ';

                                }
                                else{
                                    echo '
                                <div class="form_row">
                                    <label> نقش </label>
                                    <select name="role1" id="role">
                                        <option selected value="3"> ویرایشگر  </option>
                                    </select>
                                </div>

                                ';

                                }
                                ?>
                                <div class="form_row">
                                    <input type="submit" value="ویرایش اطلاعات" name="edit_cuser" id="edit_cuser">
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Ajax/Send/Admin/user/index.js"></script>
<script>
    $(document).ready(function(e) {
        $("#role").val(<?php echo @$_SESSION['user_access']; ?>);
        ////////
    });
</script>

</body>
</html>