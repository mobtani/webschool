<?php
define('contact_us_table','db_contactus');
define('setting','db_setting_admin');

include_once("../../Classes/connect.php");
include_once("../../Classes/Cat/cat.php");
include_once("../../Classes/setting/setting.php");
include('../../Classes/User/user.php');
include('../../Classes/Site/contact_us/contact_us.php');
$contact_us=new contact_us();

include('../../INCLUDE/functions.php');

$user=new user();
$category=new category();
$setting=new setting();
$connect=new Connection();




if(!(isset($_SESSION['user_logged'])))
    header("location:../../login_logout/login.php");
if($_SESSION['user_access']=="3")
    header("location:../error/not_acces.php");
if($_SESSION['user_access']=="2")
    header("location:../error/not_acces.php");

$slider_count=$setting->fetch_count_image_site_slider(setting);
if($slider_count)$_SESSION['slider_count']=$slider_count;
$fa_copyright=$setting->fetch_fa_copyright(setting);
if($fa_copyright)$_SESSION['fa_copyright']=$fa_copyright;
$en_copyright=$setting->fetch_en_copyright(setting);
if($en_copyright)$_SESSION['en_copyright']=$en_copyright;
$facebook=$setting->fetch_facebook(setting);
if($facebook)$_SESSION['facebook']=$facebook;
$twitter=$setting->fetch_twitter(setting);
if($twitter)$_SESSION['twitter']=$twitter;
$skype=$setting->fetch_skype(setting);
if($skype)$_SESSION['skype']=$skype;
$takhfif=$setting->fetch_takhfif(setting);
if($takhfif)$_SESSION['takhfif']=$takhfif;
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
<title>تنظیمات عمومی  </title>
<link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
<link rel="stylesheet" type="text/css" href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
</head>
<body>
	<div class="container">
    	<div class="row">
            <?php
            include('../../Function/Admin/top-menu.php');
            ?>
            <div class="row">
            	<div class="col-lg-12 col-xs-12 t_body">
                    <?php
                    include('../../Function/Admin/right-menu.php');
                    ?>
                    <div class="col-lg-10 t_left">
                    	<div class="col-lg-12 top_n1">
                        	<ul>
                            	<li><i class="fa fa-home"></i> داشبورد / تنظیمات عمومی </li>
                                <li class="end" id="clock1"> </li>
                                <li class="end"> <?php echo get_date('امروز',' '); ?> </li>
                            </ul>
                        </div>
                        <div class="col-lg-12 content">
                         <div class="result" style="display: none; width: 100%"><p></p></div>
                        	<div class="col-lg-5 box">
                            	<div class="title"><p><i class="fa fa-bars"></i>تنظیمات عمومی </p> </div>
								<div class="box_content">
                                	<div class="form_row">
                                    	<label> تعداد تصویر برای اسلایدر : </label>
                                    	<input type="text" value="<?php echo $slider_count; ?>" name="count" id="count">
                                    </div>
                                    <div class="form_row">
                                    	<label> متن کپی رایت فارسی  : </label>
                                    	<input type="text" value="<?php echo $fa_copyright; ?>"  name="fa" id="fa">
                                    </div>
                                    <div class="form_row">
                                        <label> متن کپی رایت انگلیسی : </label>
                                        <input type="text" value="<?php echo $en_copyright; ?>" name="en" id="en">
                                    </div>
                                    <div class="form_row">
                                    	<label> آدرس فیسبوک : </label>
                                    	<input type="text" value="<?php echo $facebook; ?>" name="facebook" id="facebook">
                                    </div>
                                    <div class="form_row">
                                        <label> آدرس توییتر : </label>
                                        <input type="text" value="<?php echo $twitter; ?>" name="twitter" id="twitter">
                                    </div>
                                    <div class="form_row">
                                        <label> آدرس اسکایپ : </label>
                                        <input type="text" value="<?php echo $skype; ?>" name="skype" id="skype">
                                    </div>

                                    <div class="form_row">
                                    	<label> تخفیف : </label>
                                    	<input type="text" value="<?php echo $takhfif; ?>" name="takhfif" id="takhfif">
                                    </div>
                                    <div class="form_row">
                                    	<input type="submit" value="ویرایش اطلاعات" name="edit" id="edit">
                                    </div>
                                </div>
                            </div>

                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Ajax/Send/Admin/setting/general.js"></script>
</body>
</html>