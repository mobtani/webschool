<?php
define('db_anbar','db_anbar');
require_once ('../../../../Classes/connect.php');
require_once ('../../../../Classes/Cat/cat.php');

$category=new category();

if(isset($_POST['save_anbar'])) {
    if (!empty($_POST['product_name']) && !empty($_POST['count'])) {
        if($_POST['product_name']=="null"){
            echo "empty_field";
        }
        else {
            $array_args = array(
                'product_name' => $_POST['product_name'],
                'count' => $_POST['count']
            );

            $result1 = $category->insert_anbar(db_anbar, $array_args);
            echo $result1;
        }
    } else {
        echo "empty_field";
    }
}
if(isset($_POST['increase'])){
    $result1 = $category->update_anbar_increase(db_anbar,$_POST['id']);
    echo $result1;
}if(isset($_POST['decrease'])){
    $result1 = $category->update_anbar_decrease(db_anbar,$_POST['id']);
    echo $result1;
}
if(isset($_POST['delete_p'])){
    $result1 = $category->delete_product_anbar(db_anbar,$_POST['id']);
    echo $result1;
}
?>