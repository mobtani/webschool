<?php
    define('menu_table','db_menu');
    require_once ('../../../Classes/connect.php');
    require_once ('../../../Classes/Cat/cat.php');

    $category=new category();


	if(!empty($_POST['c_name']))
	{
        if($_POST['c_parent']=="null") {
            $parent_id=0;
        }else{
            $parent_id=$_POST['c_parent'];
        }

        $array_args=array(
            'parent_id'=>$parent_id,
            'cat_name'=>$_POST['c_name']
        );

        $result1=$category->insert(menu_table,$array_args);
        echo $result1;
	}
	else
	{
        echo "empty_field";
	}
?>