<?php
if(!empty($_POST['username']) && !empty($_POST['password'])){

    define('user_table','db_user');
    require_once('../../../../Classes/connect.php');
    require_once('../../../../Classes/User/user.php');

    $user=new user();

    $array_args=array(
        'username'=>$_POST['username'],
        'password'=>$_POST['password'],
        'remember'=>$_POST['checked']
    );
    $result=$user->check_login(user_table,$array_args);

   if($result > 0){
        echo 1;
   }else{
       session_destroy();
        echo "not_find";
   }
}
else{
    echo "empty_field";
}
