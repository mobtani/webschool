<?php
session_destroy();
header("location:../../../../Admin/login_logout/login.php");
