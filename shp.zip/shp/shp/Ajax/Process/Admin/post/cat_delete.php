<?php
session_start();
    define('menu_table','db_menu');

include_once("../../../../Classes/connect.php");
include('../../../../Classes/Cat/cat.php');
include ('../../../../Function/functions.php');

$cat=new category();
$connect=new Connection();

if(isset($_POST['delete_cat'])){
    $result_delete=$cat->delete_cat(menu_table,$_POST['id']);
    if(intval($result_delete)==1){
        echo "1";
    }else{
        echo "0";
    }
}