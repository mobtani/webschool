<?php
session_start();
define('menu_table','db_menu');
require_once ('../../../../Classes/connect.php');
require_once ('../../../../Classes/Cat/cat.php');
$category=new category();

if(isset($_POST['edit_cat'])) {
    $result=$category->showData_cat_id(menu_table,$_POST['id']);
    if(intval($result)>0){
        $_SESSION['name']=$result['menu_name'];
        $_SESSION['parent']=$result['menu_parent_id'];
        $_SESSION['menu_id']=$result['menu_id'];
        $_SESSION['menu_edit']="edit";
        echo "1";
    } else {
        echo "0";
    }
}
if(isset($_POST['final_edit'])) {
    if (!empty($_POST['c_name'])) {
        $array_args = array(
            'name' => $_POST['c_name'],
            'parent' => $_POST['c_parent']
        );
        $result=$category->update_cat(menu_table,$array_args,$_SESSION['menu_id']);
        if(!$result1){
            $_SESSION['name']=$_POST['c_name'];
            $_SESSION['parent']=$_POST['c_parent'];
            unset($_SESSION['menu_edit']);
        }
        echo $result1;
    } else {
        echo "empty";
    }
}