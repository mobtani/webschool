<?php
session_start();
define('post_table','db_post');

include_once("../../../../Classes/connect.php");
include('../../../../Classes/Post/post.php');
include ('../../../../Function/functions.php');

$post=new post();
$connect=new Connection();

if(isset($_POST['delete_post'])){
    $result_delete=$post->delete_post(post_table,$_POST['id'],$_POST['code']);
    if(intval($result_delete)==1){
        echo "1";
    }else{
        echo "0";
    }
}