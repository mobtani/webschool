<?php
session_start();
define('post_table','db_post');
define('slider_table','db_post_slider');

include_once("../../../../Classes/connect.php");
include('../../../../Classes/Post/post.php');
include ('../../../../Function/functions.php');

$post=new post();
$connect=new Connection();

if(isset($_POST['edit_post'])) {
    $result=$post->showData_post_id(post_table,$_POST['id'],$_POST['code']);
    if(intval($result)>0){
        $_SESSION['name_fa_edit']=$result['db_post_name_fa'];
        $_SESSION['name_en_edit']=$result['db_post_name_en'];
        $_SESSION['comment_edit']=$result['db_post_comment'];
        $_SESSION['vezheki_edit']=$result['db_post_vezheki'];
        $_SESSION['category_edit']=$result['db_post_category'];
        $_SESSION['garanti_edit']=$result['db_post_garanti'];
        $_SESSION['color_edit']=$result['db_post_color'];
        $_SESSION['gheymat_edit']=$result['db_post_gheymat'];
        $_SESSION['takhfif_edit']=$result['db_post_takhfif'];
        $_SESSION['e_image_selected_name']=$result['db_post_image'];
        $_SESSION['code_edit']=$result['db_post_code'];





        $_SESSION['garanti_edit_f']=array();
        $array_garanti=explode(",",$_SESSION['garanti_edit']);
        foreach ($array_garanti as $a){
            array_push($_SESSION['garanti_edit_f'],$a);
        }

        $_SESSION['color_edit_f']=array();
        $array_gcolor=explode(",",$_SESSION['color_edit']);
        foreach ($array_gcolor as $b){
            array_push($_SESSION['color_edit_f'],$b);
        }




        echo "1";
    }
    else
    {
        echo "0";
    }
}
if(isset($_POST['garanti'])){
    if(!empty($_SESSION['garanti_edit_f'])) {
        array_push($_SESSION['garanti_edit_f'],$_POST['garanti']);
    } else{
        $_SESSION['garanti_edit_f']=array($_POST['garanti']) ;
    }
    echo json_encode($_SESSION['garanti_edit_f']);
}

if(isset($_POST['empty_garanti'])){
    $_SESSION['garanti_edit_f']=array();
    $array=array();
    $array['success']="true";
    echo json_encode($array);
}

if(isset($_POST['color'])){
    if(!empty($_SESSION['color_edit_f'])) {
        array_push($_SESSION['color_edit_f'],$_POST['color']);
    } else{
        $_SESSION['color_edit_f']=array($_POST['color']) ;
    }
    echo json_encode($_SESSION['color_edit_f']);
}

if(isset($_POST['empty_color'])){
    $_SESSION['color_edit_f']=array();
    $array=array();
    $array['success']="true";
    echo json_encode($array);
}

if(isset($_POST['image_selected_name'])){
    $_SESSION['e_image_selected_name']=$_POST['image_selected_name'];
}



if(isset($_POST['post_edit'])){
    $array=array();
    if(empty($_POST['comment'])) {
        array_push($array,"لطفا توضیحات محصول را وارد کنید ");
    }
    if(empty($_POST['vezheki'])) {
        array_push($array,"لطفا ویژگی محصول را وارد کنید ");
    }
    if(empty($_SESSION['e_image_selected_name'])){
        array_push($array,"لطفا تصویر شاخصی محصول را انتخاب کنید ");
    }
    if(empty($_POST['name_fa'])){
        array_push($array,"لطفا نام فارسی محصول را وارد کنید ");
    }
    else{
        if(@$_SESSION['e_name_fa']=="failed"){
            array_push($array,"لطفا در فیلد نام فارسی از لغات فارسی استفاده کنید ");
        }
    }
    if(empty($_POST['name_en'])){
        array_push($array,"لطفا نام لاتین محصول را وارد کنید ");
    }
    else{
        if(@$_SESSION['e_name_en']=="failed"){
            array_push($array,"لطفا در فیلد نام انگلیسی از لغات انگلیسی استفاده کنید ");
        }
    }
    if(empty($_POST['gheymat'])){
        array_push($array,"لطفا قیمت محصول را وارد کنید ");
    }
    else{
        if(@$_SESSION['e_gheymat']=="failed"){
            array_push($array,"لطفا در فیلد قیمت از اعداد استفاده کنید ");
        }
    }
    if(!empty($_POST['takhfif'])){
        if(@$_SESSION['e_takhfif']=="failed"){
            array_push($array,"لطفا در فیلد تخفیف از اعداد استفاده کنید ");
        }
    }
    if(!empty($_POST['comment']) && !empty($_POST['vezheki']) && !empty(@$_SESSION['e_image_selected_name']) && !empty($_POST['name_fa']) && @$_SESSION['e_name_fa']!="failed"
        && !empty($_POST['name_en']) && @$_SESSION['e_name_en']!="failed" && !empty($_POST['gheymat']) && @$_SESSION['e_gheymat']!="failed" && @$_SESSION['e_takhfif']!="failed")
    {
        $_SESSION['name_fa_edit']=$_POST['name_fa'];
        $_SESSION['name_en_edit']=$_POST['name_en'];
        $_SESSION['gheymat_edit']=$_POST['gheymat'];
        $_SESSION['takhfif_edit']=$_POST['takhfif'];
        $_SESSION['comment_edit']=$_POST['comment'];
        $_SESSION['vezheki_edit']=$_POST['vezheki'];
        $_SESSION['category_edit']=$_POST['category'];

        array_push($array,"123");

        //fetch the image ghadim for edit post
        $_SESSION['result_g']=array();
        $result=$post->showData_img_slider_code(slider_table,$_SESSION['code_edit']);
        if($result){
            foreach ($result as $rr){
                array_push($_SESSION['result_g'],$rr['db_post_slider_name']);
            }
        }

        //garanti
        if(!empty($_SESSION['garanti_edit_f'])){
            foreach ($_SESSION['garanti_edit_f'] as $garanti){
                if(!empty($_SESSION['garanti_edit_t'])){
                    $_SESSION['garanti_edit_t']=$_SESSION['garanti_edit_t'].",".$garanti;
                }else{
                    $_SESSION['garanti_edit_t']=$garanti;
                }
            }
        }
        //color
        if(!empty($_SESSION['color_edit_f'])){
            foreach ($_SESSION['color_edit_f'] as $color){
                if(!empty($_SESSION['color_edit_t'])){
                    $_SESSION['color_edit_t']=$_SESSION['color_edit_t'].",".$color;
                }else{
                    $_SESSION['color_edit_t']=$color;
                }
            }
        }


    }
    echo json_encode($array);
}
if(isset($_POST['image_id'])){
    $rows = $post->showData_image_id('db_uploaded_file',$_POST['image_id']);
    $result = array();
    $result['id'] = $rows['uploaded_file_id'];
    $result['name'] = $rows['uploaded_file_name'];
    $result['type'] = $rows['uploaded_file_type'];
    $result['size'] = $rows['uploaded_file_capacity'];
    $result['author'] = $rows['uploaded_creater'];

    echo json_encode($result);
}
if(isset($_POST['image_selected_for_slider'])){
    if(!empty($_POST['image_selected_for_slider'])) {
        if (!empty($_SESSION['e_image_selected_for_slider'])) {
            array_push($_SESSION['e_image_selected_for_slider'], $_POST['image_selected_for_slider']);
        } else {
            $_SESSION['e_image_selected_for_slider'] = array($_POST['image_selected_for_slider']);
        }
    }
    echo json_encode($_SESSION['e_image_selected_for_slider']);
}


if(isset($_POST['delete_ghadimi_image_slider'])){
    $result=$post->delete_slider_image(slider_table,$_POST['name'],$_SESSION['code_edit']);
    if(intval($result)){
        //fetch the image ghadim for edit post
        $_SESSION['result_g']=array();
        $result=$post->showData_img_slider_code(slider_table,$_SESSION['code_edit']);
        foreach ($result as $rr){
            array_push($_SESSION['result_g'],$rr['db_post_slider_name']);
        }
        echo "1";
    }else{
        echo "2";
    }
}


if(isset($_POST['image_edit_final'])){

    $array_edit=array(

        'name_fa'=>$_SESSION['name_fa_edit'],
        'name_en'=>$_SESSION['name_en_edit'],
        'comment'=>$_SESSION['comment_edit'],
        'vezheki'=>$_SESSION['vezheki_edit'],
        'category'=>$_SESSION['category_edit'],
        'garanti'=>$_SESSION['garanti_edit_t'],
        'color'=>$_SESSION['color_edit_t'],
        'gheymat'=>$_SESSION['gheymat_edit'],
        'takhfif'=>$_SESSION['takhfif_edit'],
        'image'=>$_SESSION['e_image_selected_name']
    );

    $result=$post->update_post(post_table,$array_edit,$_SESSION['code_edit']);
    if(intval($result)){
        if(!empty($_SESSION['e_image_selected_for_slider'])){
            $array_args = array(
                'created_by' => $_SESSION['user_name'],
                'date' => get_date('', ''),
                'for_post' => $_SESSION['code_edit']
            );
            $result_s=$post->insert_post_slider(slider_table,$_SESSION['e_image_selected_for_slider'],$array_args);
            if (intval($result_s)){

                unset($_SESSION['name_fa_edit']);
                unset($_SESSION['name_en_edit']);
                unset($_SESSION['comment_edit']);
                unset($_SESSION['vezheki_edit']);
                unset($_SESSION['category_edit']);
                unset($_SESSION['garanti_edit_t']);
                unset($_SESSION['color_edit_t']);
                unset($_SESSION['gheymat_edit']);
                unset($_SESSION['takhfif_edit']);
                unset($_SESSION['e_image_selected_name']);
                unset($_SESSION['e_image_selected_for_slider']);


                $array_response=array();
                $array_response['res']="1";
            }else{
                $array_response=array();
                $array_response['res']="2";
            }
        }else{
            $array_response=array();
            $array_response['res']="1";
        }
    }else{
        $array_response=array();
        $array_response['res']="3";
    }
    echo json_encode($array_response);

}
