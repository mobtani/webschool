<?php
session_start();
define('post_table','db_post');
define('slider_table','db_post_slider');

include_once("../../../../Classes/connect.php");
include('../../../../Classes/Post/post.php');
include ('../../../../Function/functions.php');

$post=new post();
$connect=new Connection();

if(isset($_POST['garanti'])){
    if(!empty($_SESSION['garanti'])) {
        array_push($_SESSION['garanti'],$_POST['garanti']);
    } else{
        $_SESSION['garanti']=array($_POST['garanti']) ;
    }
    echo json_encode($_SESSION['garanti']);
}

if(isset($_POST['empty_garanti'])){
    $_SESSION['garanti']=array();
    $array=array();
    $array['success']="true";
    echo json_encode($array);
}


if(isset($_POST['color'])){
    if(!empty($_SESSION['color'])) {
        array_push($_SESSION['color'],$_POST['color']);
    } else{
        $_SESSION['color']=array($_POST['color']);
    }
    echo json_encode($_SESSION['color']);
}

if(isset($_POST['empty_color'])){
    $_SESSION['color']=array();
    $array=array();
    $array['success']="true";
    echo json_encode($array);
}


if(isset($_POST['image_id'])){
    $rows = $post->showData_image_id('db_uploaded_file',$_POST['image_id']);
    $result = array();
    $result['id'] = $rows['uploaded_file_id'];
    $result['name'] = $rows['uploaded_file_name'];
    $result['type'] = $rows['uploaded_file_type'];
    $result['size'] = $rows['uploaded_file_capacity'];
    $result['author'] = $rows['uploaded_creater'];

    echo json_encode($result);
}


if(isset($_POST['image_selected_name'])){
    $_SESSION['image_selected_name']=$_POST['image_selected_name'];
}

if(isset($_POST['post_save'])){
$array=array();
    if(empty($_POST['comment'])) {
        array_push($array,"لطفا توضیحات محصول را وارد کنید ");
    }
    if(empty($_POST['vezheki'])) {
        array_push($array,"لطفا ویژگی محصول را وارد کنید ");
    }
    if(empty($_SESSION['image_selected_name'])){
        array_push($array,"لطفا تصویر شاخصی محصول را انتخاب کنید ");
    }
    if(empty($_POST['name_fa'])){
        array_push($array,"لطفا نام فارسی محصول را وارد کنید ");
    }
    else{
        if($_SESSION['name_fa']=="failed"){
            array_push($array,"لطفا در فیلد نام فارسی از لغات فارسی استفاده کنید ");
        }
    }
    if(empty($_POST['name_en'])){
        array_push($array,"لطفا نام لاتین محصول را وارد کنید ");
    }
    else{
        if($_SESSION['name_en']=="failed"){
            array_push($array,"لطفا در فیلد نام انگلیسی از لغات انگلیسی استفاده کنید ");
        }
    }
    if(empty($_POST['gheymat'])){
        array_push($array,"لطفا قیمت محصول را وارد کنید ");
    }
    else{
        if($_SESSION['gheymat']=="failed"){
            array_push($array,"لطفا در فیلد قیمت از اعداد استفاده کنید ");
        }
    }

    if(!empty($_POST['takhfif'])){
        if($_SESSION['takhfif']=="failed"){
            array_push($array,"لطفا در فیلد تخفیف از اعداد استفاده کنید ");
        }
    }
    if(! isset($_SESSION['takhfif'])){
        $_SESSION['takhfif'] = 0;
    }

    if(!empty($_POST['comment']) && !empty($_POST['vezheki']) && !empty($_SESSION['image_selected_name']) && !empty($_POST['name_fa']) && $_SESSION['name_fa']!="failed"
        && !empty($_POST['name_en']) && $_SESSION['name_en']!="failed" && !empty($_POST['gheymat']) && $_SESSION['gheymat']!="failed" && $_SESSION['takhfif']!="failed")
    {
        $_SESSION['name_fa_val']=$_POST['name_fa'];

        $_SESSION['name_en_val']=$_POST['name_en'];
        $_SESSION['gheymat_val']=$_POST['gheymat'];
        $_SESSION['takhfif_val']=$_POST['takhfif'];
        $_SESSION['comment']=$_POST['comment'];
        $_SESSION['vezheki']=$_POST['vezheki'];
        $_SESSION['category']=$_POST['category'];
        if(!isset($_SESSION['post_code'])){
            $_SESSION['post_code']=rand(1020304050,50406030201090);
        }

        //garanti
        if(isset($_SESSION['garanti'])){
            foreach ($_SESSION['garanti'] as $garanti){
                if(!empty($_SESSION['garanti_t'])){
                    $_SESSION['garanti_t']=$_SESSION['garanti_t'].",".$garanti;
                }else{
                    $_SESSION['garanti_t']=$garanti;
                }
            }
        }
        //color
        if(isset($_SESSION['color'])){
            foreach ($_SESSION['color'] as $color){
                if(!empty($_SESSION['color_t'])){
                    $_SESSION['color_t']=$_SESSION['color_t'].",".$color;
                }else{
                    $_SESSION['color_t']=$color;
                }
            }
        }



        array_push($array,"123");
    }
    echo json_encode($array);
}
if(isset($_POST['final_save'])){

    $array_args=array(
        'name_fa'=> $_SESSION['name_fa_val'],
        'name_en'=> $_SESSION['name_en_val'],
        'comment'=> $_SESSION['comment'],
        'vezheki'=> $_SESSION['vezheki'],
        'category'=>isset( $_SESSION['category'])? $_SESSION['category']:0,
        'garanti'=> isset($_SESSION['garanti_t'])?$_SESSION['garanti_t']:0,
        'color'=> isset($_SESSION['color_t'])?$_SESSION['color_t']:0,
        'gheymat'=> $_SESSION['gheymat_val'],
        'takhfif'=> isset($_SESSION['takhfif_val'])?$_SESSION['takhfif_val']:0,
        'image'=>$_SESSION['image_selected_name'],
        'code'=>$_SESSION['post_code'],
        'created_by' => $_SESSION['user_name'],
        'date' => get_date('', '')
    );

//    print_r($array_args);
//    die();
    $result1=$post->insert(post_table,$array_args);



    if(intval($result1)==1){

        if(!empty($_SESSION['e_image_selected_for_slider'])) {
            $echo = true;
            $array_args = array(
                'created_by' => $_SESSION['user_name'],
                'date' => get_date('', ''),
                'for_post' => $_SESSION['post_code']
            );
            $result_s = $post->insert_post_slider(slider_table, $_SESSION['e_image_selected_for_slider'], $array_args);
            if (intval($result_s)) {
                unset($_SESSION['name_fa_val']);
                unset($_SESSION['name_en_val']);
                unset($_SESSION['comment']);
                unset($_SESSION['vezheki']);
                unset($_SESSION['category']);
                unset($_SESSION['garanti_t']);
                unset($_SESSION['garanti']);
                unset($_SESSION['color_t']);
                unset($_SESSION['color']);
                unset($_SESSION['gheymat_val']);
                unset($_SESSION['takhfif_val']);
                unset($_SESSION['image_selected_name']);
                unset($_SESSION['post_code']);
                unset($_SESSION['e_image_selected_for_slider']);
                echo "1";
            }else{
                unset($_SESSION['name_fa_val']);
                unset($_SESSION['name_en_val']);
                unset($_SESSION['comment']);
                unset($_SESSION['vezheki']);
                unset($_SESSION['category']);
                unset($_SESSION['garanti_t']);
                unset($_SESSION['garanti']);
                unset($_SESSION['color_t']);
                unset($_SESSION['color']);
                unset($_SESSION['gheymat_val']);
                unset($_SESSION['takhfif_val']);
                unset($_SESSION['image_selected_name']);
                unset($_SESSION['post_code']);
                echo "2";
            }

        }
        unset($_SESSION['name_fa_val']);
        unset($_SESSION['name_en_val']);
        unset($_SESSION['comment']);
        unset($_SESSION['vezheki']);
        unset($_SESSION['category']);
        unset($_SESSION['garanti_t']);
        unset($_SESSION['garanti']);
        unset($_SESSION['color_t']);
        unset($_SESSION['color']);
        unset($_SESSION['gheymat_val']);
        unset($_SESSION['takhfif_val']);
        unset($_SESSION['image_selected_name']);
        unset($_SESSION['post_code']);
        if(empty($echo)){
            echo "2";
        }
    }else{
        echo "0";
    }
}