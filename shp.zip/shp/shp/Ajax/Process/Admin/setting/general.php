<?php
session_start();
define('db_user','db_user');
require_once ('../../../../Classes/connect.php');
require_once ('../../../../Classes/Cat/cat.php');
include_once("../../../../Classes/setting/setting.php");
define('setting','db_setting_admin');

$setting=new setting();

if(isset($_POST['edit_general'])) {
    if (!empty($_POST['count']) && !empty($_POST['fa']) && !empty($_POST['en']) && !empty($_POST['facebook']) && !empty($_POST['twitter']) && !empty($_POST['skype'])) {
        if(!empty($_POST['takhfif'])){
            $takhfif=$_POST['takhfif'];
        }else{
            $takhfif=0;
        }
        $array_args = array(
            'count' => $_POST['count'],
            'fa' => $_POST['fa'],
            'en' => $_POST['en'],
            'facebook' => $_POST['facebook'],
            'twitter' => $_POST['twitter'],
            'skype' => $_POST['skype'],
            'takhfif' => $takhfif
        );
        $result1 = $setting->general_edit(setting,$array_args);
        if($result1){
        }
        echo $result1;
    } else {
        echo "empty";
    }
}