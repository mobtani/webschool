<?php

define('db_setting_admin','db_setting_admin');

include ('../../../../Classes/connect.php');

session_start();
include('../../../../Classes/setting/setting.php');

include ('../../../../Classes/Upload/upload.php');
include ('../../../../Function/functions.php');
$upload=new upload();
$setting=new setting();

if(is_array($_FILES)) {
    if(is_uploaded_file($_FILES['userImage']['tmp_name'])) {

                $sourcePath = $_FILES['userImage']['tmp_name'];
                $targetPath = "../../../Save/logo/" . $_FILES['userImage']['name'];

                $file_name = $_FILES['userImage']['name'];
                $file_size = $_FILES['userImage']['size'];
                $file_type = $_FILES['userImage']['type'];
                $file_size = ceil($file_size / 1000);

                $_SESSION['label'] = @$_SESSION['label'] . '*****' . $targetPath;
                $labels = @$_SESSION['label'];


                $array_args = array(
                    'name' => $file_name
                );
        $value=$setting->fetch_logo_name(db_setting_admin);

                if (move_uploaded_file($sourcePath, $targetPath)) {
                    $result = $upload->update_logo(db_setting_admin, $array_args);
                    if ($result) {
                        unlink('../../../Save/logo/'.$value);

                        sleep(5);
                        echo '
                        <div class="uploaded_file">
                            <div class="title_file">' . $file_name . '</div>
                            <div class="state_file"><img src="../../Ajax/Save/logo/' . $file_name . '"></div>
                        </div>
                    ';
                    }
                }
    }
}