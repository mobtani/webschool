<?php
define('upload_table','db_uploaded_file');
include ('../../../../Classes/connect.php');

session_start();

include ('../../../../Classes/Upload/upload.php');
include ('../../../../Function/functions.php');
$upload=new upload();

if(isset($_POST['delete_media'])) {
    $result = $upload->delete_media(upload_table,$_POST['id']);
    if ($result) {
        unlink('../../../Save/images/'.$_POST['name']);
        echo true;
    }else{
        echo "1";
    }
}