<?php
define('db_user','db_user');
require_once ('../../../../Classes/connect.php');
require_once ('../../../../Classes/Cat/cat.php');
$category=new category();


if(isset($_POST['delete_user'])){
    $result_delete=$category->delete_user(db_user,$_POST['id']);
    if(intval($result_delete)==1){
        echo "1";
    }else{
        echo "0";
    }
}