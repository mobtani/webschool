<?php
session_start();
    define('db_user','db_user');
    require_once ('../../../../Classes/connect.php');
    require_once ('../../../../Classes/Cat/cat.php');
    $category=new category();

if(isset($_POST['edit_user'])) {
    $result=$category->showData_user_id(db_user,$_POST['id']);
    if(intval($result)>0){
        $_SESSION['name']=$result['user_name'];
        $_SESSION['family']=$result['user_family'];
        $_SESSION['email']=$result['user_email'];
        $_SESSION['username']=$result['user_username'];
        $_SESSION['pass']=$result['user_password'];
        $_SESSION['role']=$result['user_access'];
        $_SESSION['user_edit_admin']="edit";
        $_SESSION['user_id']=$result['user_id'];

        echo "1";
    } else {
    echo "0";
    }
}
if(isset($_POST['final_edit'])) {
    if (!empty($_POST['name']) && !empty($_POST['family']) && !empty($_POST['username']) && !empty($_POST['pass']) && !empty($_POST['email']) && !empty($_POST['role'])) {
        $array_args = array(
            'name' => $_POST['name'],
            'username' => $_POST['username'],
            'pass' => $_POST['pass'],
            'email' => $_POST['email'],
            'role' => $_POST['role'],
            'family' => $_POST['family']
        );
        $result1 = $category->update_user(db_user, $array_args, $_SESSION['user_id']);
        if($result1){
            $_SESSION['name']=$_POST['name'];
            $_SESSION['family']=$_POST['family'];
            $_SESSION['email']=$_POST['email'];
            $_SESSION['username']=$_POST['username'];
            $_SESSION['pass']=$_POST['pass'];
            $_SESSION['role']=$_POST['role'];
           unset($_SESSION['user_edit_admin']);
            
        }
        echo $result1;
    } else {
        echo "empty";
    }
}
if(isset($_POST['final_cedit'])) {
    if (!empty($_POST['name']) && !empty($_POST['family']) && !empty($_POST['username']) && !empty($_POST['pass']) && !empty($_POST['email'])) {
        $array_args = array(
            'name' => $_POST['name'],
            'username' => $_POST['username'],
            'pass' => $_POST['pass'],
            'email' => $_POST['email'],
            'role' => $_POST['role'],
            'family' => $_POST['family']
        );
        $result1 = $category->update_user(db_user, $array_args, $_SESSION['user_id_1']);
        if($result1){
            $_SESSION['user_name']=$_POST['name'];
            $_SESSION['user_family']=$_POST['family'];

            unset($_SESSION['user_edit_admin']);

        }
        echo $result1;
    } else {
        echo "empty";
    }
}