<?php
define('db_user','db_user');
require_once ('../../../../Classes/connect.php');
require_once ('../../../../Classes/Cat/cat.php');
$category=new category();
    if(!empty($_POST['name']) && !empty($_POST['family']) && !empty($_POST['username']) && !empty($_POST['pass']) && !empty($_POST['email']) && !empty($_POST['role'])) {
        $array_args=array(
            'name'=>$_POST['name'],
            'username'=>$_POST['username'],
            'pass'=>$_POST['pass'],
            'email'=>$_POST['email'],
            'role'=>$_POST['role'],
            'family'=>$_POST['family'],
            'last_login'=>"0"
        );
        $result1=$category->insert_user(db_user,$array_args);
        echo $result1;
    }else{
        echo "empty";
    }