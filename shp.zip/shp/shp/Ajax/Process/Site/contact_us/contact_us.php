<?php
session_start();
define('contact_us_table','db_contactus');

include_once("../../../../Classes/connect.php");
include('../../../../Classes/Site/contact_us/contact_us.php');
include ('../../../../Function/functions.php');
include ("../../../../Function/secure.php");


$contact_us=new contact_us();
$connect=new Connection();

if(isset($_POST['email_check'])) {
    if (preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/", $_POST['email'])) {
        $_SESSION['email_check_contact_us']="success";
        echo "1";
    }
    else{
        $_SESSION['email_check_contact_us']="failed";
        echo "2";
    }
}
if(isset($_POST['form_save'])){
    $array_warning=array();

    if(empty($_POST['name'])){
        array_push($array_warning,"لطفا نام خودتان را وارد کنید ");
    }

    if(empty($_POST['email'])){
        array_push($array_warning,"لطفا ایمیل خودتان را وارد کنید ");
    }else{
        if(@$_SESSION['email_check_contact_us']!="success"){
            array_push($array_warning,"لطفا ایمیل خودتان را درست وارد کنید ");
        }
    }

    if(empty($_POST['comment'])){
        array_push($array_warning,"لطفا متن پیغام را وارد کنید ");
    }

    if(empty($_POST['captcha_user'])) {
        array_push($array_warning,"لطفا کد امنیتی را وارد کنید ");
    }
    else{
        if ($_POST['captcha_user'] != $_SESSION['Captcha_string']) {
            array_push($array_warning, "لطفا کد امنیتی را درست وارد کنید ");
        }
    }

    if(!empty($_POST['name']) && !empty($_POST['email']) && @$_SESSION['email_check_contact_us']=="success" && !empty($_POST['comment'])
    && !empty($_POST['captcha_user']) && $_POST['captcha_user'] == $_SESSION['Captcha_string'])
    {
        $array = array(
            'name'=>    check_input($_POST['name']),
            'email'=>   check_input($_POST['email']),
            'subject'=> check_input($_POST['subject']),
            'comment'=> check_input($_POST['comment']),
            'date'=>    get_date('', ''),
            'state'=>   "0"
        );

        $result=$contact_us->insert(contact_us_table,$array);
        if(intval($result)){
            array_push($array_warning,"123");
        }else{
            array_push($array_warning,"321");
        }
    }
    echo json_encode($array_warning);
}
if(isset($_POST['update_state'])){
    $result=$contact_us->change_state(contact_us_table,$_POST['state'],$_POST['id']);
    if(intval($result)){
        echo "1";
    }else{
        echo "2";
    }

}