<?php
session_start();
define('contact_us_table','db_contactus');

include_once("../../../../Classes/connect.php");
include('../../../../Classes/Site/contact_us/contact_us.php');


$contact_us=new contact_us();
$connect=new Connection();

if(isset($_POST['delete_contact_us'])){
    $result_delete=$contact_us->delete(contact_us_table,$_POST['id']);
    if(intval($result_delete)==1){
        echo "1";
    }else{
        echo "0";
    }
}