<?php
define('temprory_factor','db_temprory_factor');
define('final_factor','db_final_factor');
session_start();
require_once ('../../../../Classes/connect.php');
require_once ('../../../../Classes/Factor/factor.php');
require_once ('../../../../Function/functions.php');

$factor=new factor();
$connect=new Connection();


if(isset($_POST['delete_factor'])){
    $result_delete=$factor->delete_factor(temprory_factor,$_POST['id']);
    if(intval($result_delete)==1){
        echo "1";
    }else{
        echo "0";
    }
}
if(isset($_POST['increase_factor'])){
    $result_delete=$factor->increase_factor(temprory_factor,$_POST['id']);
    if(intval($result_delete)==1){
        echo "1";
    }else{
        echo "0";
    }
}
if(isset($_POST['decrease_factor'])){
    $result_delete=$factor->decrease_factor(temprory_factor,$_POST['id']);
    if(intval($result_delete)==1){
        echo "1";
    }else{
        echo "0";
    }
}
if(isset($_POST['user_register_check'])) {
    if ($_SESSION['user_site_register_state'] == 0)
        echo "1";
    else
        echo "0";
}

if(isset($_POST['final_register_factor'])) {
    $array = array(
        'fcode'=>    $_SESSION['temprory_factor_code'],
        'ucode'=>   $_SESSION['user_site_customer_code'],
        'price'=> $_SESSION['$gheymat_kol_final'],
        'date'=>    get_date('', '')
    );
    $result_insert=$factor->insert_final(final_factor,$array);
    if(intval($result_insert)==1)
    {
        $_SESSION['final_factor_code']=$_SESSION['temprory_factor_code'];
        unset($_SESSION['temprory_factor_code']);
        setcookie("factor","",time()-3600);
        echo "1";
    }else{
        echo "0";
    }
}
if(isset($_POST['alternative'])){
    $result_update=$factor->change_factor_state(final_factor,$_POST['code'],$_POST['alternative']);
    if(intval($result_update)==1){
        echo "1";
    }else{
        echo "0";
    }

}