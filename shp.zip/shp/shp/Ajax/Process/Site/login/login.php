<?php
session_start();
if(!empty($_POST['username']) && !empty($_POST['password'])){

    define('user_site','db_user_site');
    require_once('../../../../Classes/connect.php');
    require_once('../../../../Classes/Site/user/user_site.php');

    $user=new user_site();
    $connect=new Connection();

    $array_args=array(
        'username'=>$_POST['username'],
        'password'=>$_POST['password'],
        'remember'=>$_POST['checked']
    );
    $result=$user->check_login(user_site,$array_args);

   if($result > 0){
        echo 1;
   }else{
       session_destroy();
        echo "not_find";
   }
}
else{
    echo "empty_field";
}
