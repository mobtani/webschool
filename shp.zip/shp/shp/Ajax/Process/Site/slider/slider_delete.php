<?php
session_start();
define('site_slider','db_slider');

include_once("../../../../Classes/connect.php");
include('../../../../Classes/upload/upload.php');


$upload=new upload();
$connect=new Connection();

if(isset($_POST['delete_slider_image'])){
    $result_delete=$upload->delete_slider(site_slider,$_POST['id']);
    if(intval($result_delete)==1){
        echo "1";
    }else{
        echo "0";
    }
}