<?php
session_start();
define('user_site','db_user_site');

include_once("../../../../Classes/connect.php");
include('../../../../Classes/Site/user/user_site.php');
include ('../../../../Function/functions.php');
include ("../../../../Function/secure.php");


$user=new user_site();
$connect=new Connection();

if(isset($_POST['username_check'])) {
    $username=$_POST['username'];
    $result_check_username=$user->check_username(user_site,$username);
    if($result_check_username >=1){
        $_SESSION['check_username']="exist";
        echo "1";
    }else{
        $_SESSION['check_username']="not_exist";
        echo "0";
    }
}
if(isset($_POST['form_save'])) {
    $array_warning=array();

    if(empty($_POST['name'])){
        array_push($array_warning,"لطفا نام خودتان را وارد کنید ");
    }
    if(empty($_POST['username'])){
        array_push($array_warning,"لطفا نام کاربری خودتان را وارد کنید ");
    }
    if(isset($_SESSION['check_username'])){
        if($_SESSION['check_username']=="exist"){
            array_push($array_warning,"نام کاربری انتخاب شده وجود دارد");
        }
    }
    else{
        $result_check_username=$user->check_username(user_site,$_POST['username']);
        if($result_check_username >=1){
            $_SESSION['check_username']="exist";
            array_push($array_warning,"نام کاربری انتخاب شده وجود دارد");
        }else{
            $_SESSION['check_username']="not_exist";
        }
    }
    if(empty($_POST['password'])){
        array_push($array_warning,"لطفا گذرواژه خود را وارد کنید ");
    }
    if(empty($_POST['re_password'])){
        array_push($array_warning,"لطفا گذرواژه خود را دوباره در فیلد تکرار گذرواژه وارد کنید ");
    }
    if($_POST['password'] != $_POST['re_password']){
        array_push($array_warning,"گذرواژه های شما با هم تطابقت ندارند ");
    }
    if(!empty($_POST['name']) && !empty($_POST['username']) && $_SESSION['check_username']!="exist" && !empty($_POST['password']) && $_POST['password'] == $_POST['re_password']){
        if($_POST['checked']=="not_legs"){
            array_push($array_warning,"شما قوانین سایت را هنوز نپذیرفته اید  ");
        }
        else{
            $word='';
            $letters='abcdefghijklmnopqrstuwxyz1234567890';
            $len=strlen($letters);
            for($i=0;$i<9;$i++)
            {
                $letter=$letters[rand(0,$len-1)];
                $word.=$letter;
            }

            $array = array(
                'name'=>    check_input($_POST['name']),
                'username'=>   check_input($_POST['username']),
                'password'=> check_input($_POST['password']),
                'user_code'=>$word,
                'register_state'=> "0"
            );
            $result=$user->insert(user_site,$array);
            if(intval($result)){
                array_push($array_warning,"123");
            }else{
                array_push($array_warning,"321");
            }
            unset($_SESSION['check_username']);

        }
    }
    echo json_encode($array_warning);
}
if(!isset($_SESSION['email_check'])){
    $_SESSION['email_check']="yes";
}
if(!isset($_SESSION['mobile_check'])){
    $_SESSION['mobile_check']="yes";
}
if(!isset($_SESSION['code_posti_check'])){
    $_SESSION['code_posti_check']="yes";
}

if(isset($_POST['email_check']))
{
    if (preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$_POST['email']))
    {
        $_SESSION['email_check']="yes";
        echo "1";
    }
    else
    {
        $_SESSION['email_check']="no";
        echo "3";
    }
}
if(isset($_POST['mobile_check']))
{
    if (preg_match('/^(((\+|00)98)|0)?9[0123]\d{8}$/',$_POST['mobile']))
    {
        $_SESSION['mobile_check']="yes";
        echo "1";
    }
    else
    {
        $_SESSION['mobile_check']="no";
        echo "3";
    }
}
if(isset($_POST['code_posti_check']))
{
    if (preg_match('/^\d{10}$/',$_POST['code_posti']))
    {
        $_SESSION['code_posti_check']="yes";
        echo "1";
    }
    else
    {
        $_SESSION['code_posti_check']="no";
        echo "3";
    }
}
if(isset($_POST['form_edit_user_info'])) {
    $array_warning=array();

    if(empty($_POST['name'])){
        array_push($array_warning,"لطفا نام خودتان را وارد کنید ");
    }
    if(empty($_POST['family'])){
        array_push($array_warning,"لطفا نام خانوادگی خودتان را وارد کنید ");
    }
    if(empty($_POST['email'])){
        array_push($array_warning,"لطفا ایمیل خودتان را وارد کنید ");
    }
    else{
        if($_SESSION['email_check']=="no")
            array_push($array_warning,"ادرس پست الکترونیکی وارد شده معتبر نیست");
        }
    if(empty($_POST['mobile'])){
        array_push($array_warning,"لطفا موبایل خودتان را وارد کنید ");
    }
    else{
        if($_SESSION['mobile_check']=="no")
            array_push($array_warning,"شماره موبایل وارد شده معتبر نیست");
    }

    if(empty($_POST['tell'])){
        array_push($array_warning,"لطفا تلفن ثابت خودتان را وارد کنید ");
    }

    if(empty($_POST['code_posti'])){
        array_push($array_warning,"لطفا کد پستی خودتان را وارد کنید ");
    }
    if(empty($_POST['address'])){
        array_push($array_warning,"لطفا آدرس خودتان را وارد کنید ");
    }

    if(!empty($_POST['name']) && !empty($_POST['family']) && !empty($_POST['email']) &&  $_SESSION['email_check']=="yes" && !empty($_POST['mobile']) && !empty($_POST['tell']) && !empty($_POST['code_posti']) && !empty($_POST['address'])){
            $array = array(
                'name'=>    check_input($_POST['name']),
                'family'=>   check_input($_POST['family']),
                'email'=> check_input($_POST['email']),
                'mobile'=> check_input($_POST['mobile']),
                'tell'=> check_input($_POST['tell']),
                'codeposti'=> check_input($_POST['code_posti']),
                'address'=> check_input($_POST['address']),
                'customer_code'=> $_SESSION['user_site_customer_code'],
                'register_state'=> "1"
            );
            $result=$user->update_user_info(user_site,$array);
            if(intval($result)){
                $_SESSION['user_site_name']=check_input($_POST['name']);
                $_SESSION['user_site_family']=check_input($_POST['family']);
                $_SESSION['user_site_address']=check_input($_POST['address']);
                $_SESSION['user_site_codeposti']=check_input($_POST['code_posti']);
                $_SESSION['user_site_tell']=check_input($_POST['tell']);
                $_SESSION['user_site_mobile']=check_input($_POST['mobile']);
                $_SESSION['user_site_email']=check_input($_POST['email']);
                $_SESSION['user_site_register_state']="1";
                unset($_SESSION['email_check']);
                unset($_SESSION['code_posti_check']);
                unset($_SESSION['mobile_check']);
                array_push($array_warning,"123");
            }else{
                array_push($array_warning,"321");
            }
    }
    echo json_encode($array_warning);
}
if(isset($_POST['form_edit_user_pass'])) {
    $array_warning=array();

    if(empty($_POST['pass1'])){
        array_push($array_warning,"لطفا گذرواژه فعلی خودتان را وارد کنید ");
    }
    if(empty($_POST['pass2'])){
        array_push($array_warning,"لطفا گذرواژه جدید خودتان را وارد کنید ");
    }
    if(empty($_POST['pass3'])){
        array_push($array_warning,"لطفا تکرار گذرواژه جدید خودتان را وارد کنید ");
    }
    if($_POST['pass2'] != $_POST['pass3']){
        array_push($array_warning,"گذرواژه های شما با هم تطابقت ندارند ");
    }

    if(!empty($_POST['pass1']) && !empty($_POST['pass2']) && !empty($_POST['pass3']) && $_POST['pass2']==$_POST['pass3']){
        $array1 = array(
            'pass1'=> check_input($_POST['pass1']),
            'customer_code'=> $_SESSION['user_site_customer_code'],
        );
        $result_check_user_pass=$user->check_user_password_for_edit(user_site,$array1);
        if($result_check_user_pass >=1){
            $array = array(
                'pass1'=> check_input($_POST['pass1']),
                'pass2'=> check_input($_POST['pass2']),
                'customer_code'=> $_SESSION['user_site_customer_code'],
            );
            $result=$user->update_user_pass(user_site,$array);
            if(intval($result)){
                array_push($array_warning,"123");
            }else{
                array_push($array_warning,"321");
            }
        }else{
            array_push($array_warning,"213");
        }
    }
    echo json_encode($array_warning);
}











if(isset($_POST['form_recovery_user_pass'])) {
    $array_warning=array();

    if(empty($_POST['username'])){
        array_push($array_warning,"لطفا نام کاربری خودتان را وارد کنید ");
    }
    if(empty($_POST['mobile'])){
        array_push($array_warning,"لطفا شماره موبایل خودتان را وارد کنید ");
    }
    if(!empty($_POST['username']) && !empty($_POST['mobile'])){
        $array1 = array(
            'username'=> check_input($_POST['username']),
            'mobile'=> check_input($_POST['mobile']),
        );
        $result_check_user_pass=$user->recover_user_password(user_site,$array1);
        if($result_check_user_pass > 0){
            array_push($array_warning,"گذرواژه شما ".$_SESSION['user_pass_recovered']. "میباشد  ");
        }
        else{
            array_push($array_warning,"123");
        }
    }
    echo json_encode($array_warning);
}

