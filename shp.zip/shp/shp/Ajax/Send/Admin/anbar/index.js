$(document).ready(function(e) {
    $("#register_anbar").click(function(e) {
        var count=$("#count").val();
        var product_name=$("#product_name").val();
        var save_anbar="save_anbar";
        $.ajax({
            url:"../../Ajax/Process/Admin/anbar/index.php",
            type:"POST",
            data:{count:count,product_name:product_name,save_anbar:save_anbar},
            success: function(data){
                if(data==true){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> محصول با موفقیت به انبار اضافه شد !");
                }
                else if(data=="empty_field"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> لطفا تعداد و نوع محصول را وارد کنید  !");
                }
                else if(data==-1){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> این محصول به انبار اضافه شده است !");
                }
                else
                {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> محصول اضافه نشد !");
                }
            }
        });
    });
    $("#edit_anbar a").click(function(e) {
        $this=$(this);
        var action=$this.data('action');
        var id=$this.data('id');
        if(action=="increase"){
            var increase="increase";
            var x=confirm("آیا می خواهید محصول زیر را افزایش دهید ؟");
            if(x==true)
            {
                $.ajax({
                    url:"../../Ajax/Process/Admin/anbar/index.php",
                    type: "POST",
                    data: {id:id,increase:increase},
                    success: function (data) {
                        if (data) {
                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> دسته مورد نظر با موفقیت حذف شد !");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> دسته مورد نظر حذف نشد !");

                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
        else if(action=="decrease"){
            var decrease="decrease";
            var x=confirm("آیا می خواهید محصول زیر را کاهش دهید ؟");
            if(x==true)
            {
                $.ajax({
                    url:"../../Ajax/Process/Admin/anbar/index.php",
                    type: "POST",
                    data: {id:id,decrease:decrease},
                    success: function (data) {
                        if (data) {
                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> دسته مورد نظر با موفقیت حذف شد !");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> دسته مورد نظر حذف نشد !");

                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
        else{
            var delete_p="delete_p";
            var x=confirm("از حذف محصول مورد نظر از انبار مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url:"../../Ajax/Process/Admin/anbar/index.php",
                    type: "POST",
                    data: {id:id,delete_p:delete_p},
                    success: function (data) {
                        if (data == 1) {
                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> محصول نظر با موفقیت از انبار حذف شد !");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> محصول  مورد نظر از انبار حذف نشد !");

                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }

    });
});