$(document).ready(function(e) {
    $("#edit_cat").click(function(e) {
        var cat_parent=$("#cat_parent").val();
        var cat_name=$("#cat_name").val();
        var final_edit="final_edit";
        $.ajax({
            url:"../../Ajax/Process/Admin/post/cat_edit.php",
            type:"POST",
            data:{c_name:cat_name,c_parent:cat_parent,final_edit:final_edit},
            success: function(data){
                if(data){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> دسته ویرایش شد !");

                }

                else if(data=="empty"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> لطفا نام دسته را وارد کنید  !");
                }
                else
                {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> دسته با موفقیت ویرایش نشد !");

                }
            }
        });
    });
    $("#register_cat").click(function(e) {
        var cat_parent=$("#cat_parent").val();
        var cat_name=$("#cat_name").val();
        $.ajax({
            url:"../../Ajax/Process/Admin/cat_save.php",
            type:"POST",
            data:{c_name:cat_name,c_parent:cat_parent},
            success: function(data){
                if(data==true){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> دسته جدید با موفقیت ایجاد شد !");
                }
                    else if(data=="empty_field"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> لطفا نام دسته را وارد کنید  !");
                }
                else
                {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> دسته ایجاد نشد !");
                }
            }
        });
    });
	$("#menu_show #action").click(function(e) {
		        $this=$(this);
		        var action=$this.data('action');
				var id=$this.data('id');
			if(action=="delete"){
            var delete_cat="delete_cat";
            var x=confirm("از حذف دسته مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Admin/post/cat_delete.php",
                    type: "POST",
                    data: {id:id,delete_cat:delete_cat},
                    success: function (data) {
                        if (data == 1) {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> دسته مورد نظر با موفقیت حذف شد !");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> دسته مورد نظر حذف نشد !");

                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
        else{
            var edit_cat="edit_cat";
            var x=confirm("از ویرایش دسته مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Admin/post/cat_edit.php",
                    type: "POST",
                    data: {id:id,edit_cat:edit_cat},
                    success: function (data) {
                        if (data == 1) {
                            window.location.href='edit.php';
                        } else {
                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> دسته مورد نظر شما قابل ویرایش نیست !");

                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }


    });
});