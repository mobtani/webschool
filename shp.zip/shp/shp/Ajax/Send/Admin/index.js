$(document).ready(function(e) {
    
	$("#register_cat").click(function(e) {
		var cat_parent=$("#cat_parent").val();
		var cat_name=$("#cat_name").val();
		$.ajax({
			url:"../Ajax/Process/Admin/cat_save.php",
			type:"POST",
			data:{c_name:cat_name,c_parent:cat_parent},
			success: function(data){
				alert(data);
			}
		});
    });
	
});