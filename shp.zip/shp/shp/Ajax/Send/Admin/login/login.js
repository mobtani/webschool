$(document).ready(function(e) {
    $("#btn").click(function(e) {
        var username=$("#username").val();
        var password=$("#password").val();

        var check;
        check=$("#mycheckbox").is(":checked");
        if(check){
            var checked="remember";
        }else{
            var checked="not_remember";
        }
        $.ajax({
            url:'../../Ajax/Process/Admin/login/login.php',
            type:"POST",
            data:{username:username,password:password,checked:checked},
            success:function(data) {
                if(data==1){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> جهت ورود به پنل مدیریت بر روی <a href='../panel/'>لینک زیر کلیک کنید</a>   !");
                }
                else if(data=="not_find"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> کاربری با مشخصات زیر وجود ندارد  !");

                }else{
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> لطفا نام کاربری و گذرواژه خود را وارد کنید   !");
                }
            }

        })
    });
});