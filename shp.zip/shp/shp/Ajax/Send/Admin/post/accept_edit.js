$(document).ready(function(e) {
    //delete logo ghadimi image for edit post
    $("#delete_img_slide a").click(function () {
        $this=$(this);
        var name=$this.data('name');
        var delete_ghadimi_image_slider = "delete_ghadimi_image_slider";
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_edit.php",
            data: {
                delete_ghadimi_image_slider: delete_ghadimi_image_slider,
                name:name
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                if(result=="1"){
                    function explode(){
                        location.reload();
                    }
                    setTimeout(explode, 2000);
                }else{

                }
                
            }
        });
    })
    //check the fields of post edit page

    //image select info
    $(".modal-body img").click(function () {
        var $this = $(this);
        $(".modal-body img").css("border","0px");
        $this.css("border","3px solid #000000");
        var image_id= $this.data('id');
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_edit.php",
            data: {
                image_id: image_id
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                $(".modal-footer").css("display","block");
                $("#pic_name").html(result.name);
                $("#pic_type").html(result.type);
                $("#pic_size").html(result.size);
            }
        });
    });
    //save image for post
    $("#save_image_post").click(function () {
        var image_selected_for_slider = $("#pic_name").html();
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_edit.php",
            data: {
                image_selected_for_slider: image_selected_for_slider
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                $(".uploaded_list div").remove();
                for(i=0;i<result.length;i++) {
                    $(".uploaded_list").append("<div class='uploaded_file'> <div class='title_file'>"+ result[i] + "</div> <div class='state_file'><img src='../../Ajax/Save/images/"+ result[i] + "'></div> </div>");
                }
            }
        });
    })
    //auto load logo image for edit post
        var image_selected_for_slider ="";
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_edit.php",
            data: {
                image_selected_for_slider: image_selected_for_slider
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                $(".uploaded_list div").remove();
                for(i=0;i<result.length;i++) {
                    $(".uploaded_list").append("<div class='uploaded_file'> <div class='title_file'>"+ result[i] + "</div> <div class='state_file'><img src='../../Ajax/Save/images/"+ result[i] + "'></div> </div>");
                }
            }
        });
//go to edit.php from accept.php
    $("#goto_edit").click(function () {
        window.location.href='edit.php';
    })
    //save edit final
    $("#post_edit_final").click(function () {
        var image_edit_final = "image_edit_final";
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_edit.php",
            data: {
                image_edit_final: image_edit_final
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                if(result.res=="1"){
                    $(".result").css("display","block");
                    $(".result").html(" محصول شما با موفقیت ویرایش شد ")
                    function explode(){
                        window.location.href='show.php';
                    }
                    setTimeout(explode, 3000);
                }else if(result.res=="2"){
                    $(".result").css("display","block");
                    $(".result").html(" محصول شما با موفقیت ویرایش شد ولی تصاویر جدید آپلود نشد ")
                    function explode(){
                        window.location.href='show.php';
                    }
                    setTimeout(explode, 2000);
                }else{
                    $(".result").css("display","block");
                    $(".result").html(" متاسفانه محصول مورد نظر ویرایش نشد ")
                    function explode(){
                        window.location.href='edit.php';
                    }
                    setTimeout(explode, 2000);
                }
            }
        });
    })
});