$(document).ready(function(e) {

    $("#action_post a").click(function () {
        $this=$(this);
        var action=$this.data('action');
        var code=$this.data('code');
        var id=$this.data('id');

        if(action=="delete"){
            var delete_post="delete_post";
            var x=confirm("از حذف محصول مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Admin/post/post_delete.php",
                    type: "POST",
                    data: {code: code,id:id,delete_post:delete_post},
                    success: function (data) {
                        if (data == 1) {
                            $(".alert-warning").css("display","none");
                            $(".alert-success p").html("محصول مورد نظر حذف شد");
                            $(".alert-success").css("display","block");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            $(".alert-success").css("display","none");
                            $(".alert-warning p").html("محصول مورد نظر شما حذف نشد");
                            $(".alert-warning").css("display","block");
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
        if(action=="edit"){
            var edit_post="edit_post";
            var x=confirm("می خواهید محصول را ویرایش کنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Admin/post/post_edit.php",
                    type: "POST",
                    data: {code: code,id:id,edit_post:edit_post},
                    success: function (data) {
                        if (data == 1) {
                            window.location.href='edit.php';
                        } else {
                            $(".alert-success").css("display","none");
                            $(".alert-warning p").html("محصول مورد نظر شما قابل ویرایش نیست !");
                            $(".alert-warning").css("display","block");
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }

        }
        if(action=="view"){
            alert("view")
        }
    })
    CKEDITOR.replace( 'editor1' );
    CKEDITOR.replace( 'editor2' );

    //check the fields of post page
    //name_farsi check
    $("#name_fa").keyup(function () {
        var name_fa = $("#name_fa").val();
        $.ajax({
            url: "check_field/check.php",
            type: "POST",
            data: {name_fa: name_fa},
            success: function (data) {
                if (data == 1) {
                    $(".name_fa").css("display", "block");
                    $(".name_fa").html("لطفا عنوان را به صورت فارسی بنویسید");
                } else {
                    $(".name_fa").css("display", "none");
                }
            }
        });
    });
        //name_english check
        $("#name_en").keyup(function () {
            var name_en=$("#name_en").val();
            $.ajax({
                url:"check_field/check.php",
                type:"POST",
                data:{name_en:name_en},
                success: function(data){
                    if(data==1){
                        $(".name_en").css("display","block");
                        $(".name_en").html("لطفا عنوان را به صورت انگلیسی بنویسید");
                    }else{
                        $(".name_en").css("display","none");
                    }
                }
            });
        })
    //sava garanti save
    $("#save_garanti").click(function () {
        var garanti=$("#garanti").val()
        if(garanti==""){
            $(".garanti").css("display","block");
        }
        else {
            $.ajax({
                type: 'POST',
                url: "../../Ajax/Process/Admin/post/post_save.php",
                data: {
                    garanti: garanti
                },
                dataType: 'json',
                cache: false,
                success: function (result) {
                    var numbers = result; //result is equal to your array from the php. You don't put PHP here.
                    $('#select_garanti option').remove(); //Remove any existing options.
                    for (i = 0; i < numbers.length; i++) {
                        $('#select_garanti').append("<option>" + numbers[i] + "</option>");
                    }
                }
            });
        }
    });
    //empty garanti
    $("#empty_garanti").click(function () {
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_save.php",
            data: {
                empty_garanti: "empty_garanti"
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                if(result.success=="true") {
                    $('#select_garanti option').remove(); //Remove any existing options.
                    $('#select_garanti').append("<option>گارانتی های ثبت شده برای این محصول </option>");
                }
            }
        });
    });

    //sava color save
    $("#save_color").click(function () {
        var color=$("#color").val()
        if(color==""){
            $(".color").css("display","block");
        }
        else {
            $.ajax({
                type: 'POST',
                url: "../../Ajax/Process/Admin/post/post_save.php",
                data: {
                    color: color
                },
                dataType: 'json',
                cache: false,
                success: function (result) {
                    var numbers = result; //result is equal to your array from the php. You don't put PHP here.
                    $('#select_color option').remove(); //Remove any existing options.
                    for (i = 0; i < numbers.length; i++) {
                        $('#select_color').append("<option>" + numbers[i] + "</option>");
                    }
                }
            });
        }
    });
    //empty color
    $("#empty_color").click(function () {
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_save.php",
            data: {
                empty_color: "empty_color"
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                if(result.success=="true") {
                    $('#select_color option').remove(); //Remove any existing options.
                    $('#select_color').append("<option>رنگ های ثبت شده برای این محصول </option>");
                }
            }
        });
    });

    //image select info
    $(".modal-body img").click(function () {
        var $this = $(this);
        $(".modal-body img").css("border","0px");
        $this.css("border","3px solid #000000");
        var image_id= $this.data('id');
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_save.php",
            data: {
                image_id: image_id
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                $(".modal-footer").css("display","block");
                $("#pic_name").html(result.name);
                $("#pic_type").html(result.type);
                $("#pic_size").html(result.size);
            }
        });
    });
    //save image for post
    $("#save_image_post").click(function () {
        var image_selected_name=$("#pic_name").html();
        $.ajax({
            url:"../../Ajax/Process/Admin/post/post_save.php",
            type:"POST",
            data:{image_selected_name:image_selected_name},
            success: function(data){
                $('#image_of_post img').remove(); //Remove any existing options.
                    $('#image_of_post').append("<img src='../../Ajax/Save/images/"+ image_selected_name +"' style='width: 100%; height: 200px'>");
            }
        });
    })
    //gheymat check
    $("#gheymat").keyup(function () {
        var gheymat = $("#gheymat").val();
        $.ajax({
            url: "check_field/check.php",
            type: "POST",
            data: {gheymat: gheymat},
            success: function (data) {
                if (data == 1) {
                    $(".gheymat").css("display", "block");
                    $(".gheymat").html(" قیمت باید به صورت عددی باشد از 0 تا 9");
                } else {
                    $(".gheymat").css("display", "none");
                }
            }
        });
    });
    //takhfif check
    $("#takhfif").keyup(function () {
        var takhfif = $("#takhfif").val();
        $.ajax({
            url: "check_field/check.php",
            type: "POST",
            data: {takhfif: takhfif},
            success: function (data) {
                if (data == 1) {
                    $(".takhfif").css("display", "block");
                    $(".takhfif").html(" تخفیف باید به صورت عددی باشد از 0 تا 9 و بدون عبارت درصد یا % وارد کنید");
                } else {
                    $(".takhfif").css("display", "none");
                }
            }
        });
    });

    // post save
    $("#post_save").click(function () {
        for ( instance in CKEDITOR.instances ) {
            CKEDITOR.instances[instance].updateElement();
        }
        var comment=$(".post_comment").val();
        var vezheki=$(".post_vezheki").val();
        var category=$("#cat_parent").val();
        var name_fa=$("#name_fa").val();
        var name_en=$("#name_en").val();
        var gheymat=$("#gheymat").val();
        var takhfif=$("#takhfif").val();
        $.ajax({
            type: 'POST',
            url: "../../Ajax/Process/Admin/post/post_save.php",
            data: {
                post_save: "clicked",
                comment: comment,
                vezheki: vezheki,
                name_fa: name_fa,
                name_en: name_en,
                gheymat: gheymat,
                takhfif: takhfif,
                category: category
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                    $('.result div').remove();
                    for(i=0;i<result.length;i++){
                        if(result[i]=="123"){
                            window.location.href='accept1.php';
                        }
                        else {
                            $('.result').append("<div class='alert alert-danger' role='alert'><i class='fa fa-warning'></i> " + result[i] + "</div>");
                        }
                    }
            }
        });
    });
    $("#register_cat").click(function(e) {
        var cat_parent=$("#cat_parent").val();
        var cat_name=$("#cat_name").val();
        $.ajax({
            url:"../../Ajax/Process/Admin/cat_save.php",
            type:"POST",
            data:{c_name:cat_name,c_parent:cat_parent},
            success: function(data){
                if(data==true){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> دسته جدید با موفقیت ایجاد شد !");
                }
                else if(data=="empty_field"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> لطفا نام دسته را وارد کنید  !");
                }
                else
                {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> دسته ایجاد نشد !");
                }
            }
        });
    });

});