$(document).ready(function(e) {
    $("#edit").click(function(e) {
        var count=$("#count").val();
        var fa=$("#fa").val();
        var en=$("#en").val();
        var facebook=$("#facebook").val();
        var twitter=$("#twitter").val();
        var skype=$("#skype").val();
        var takhfif=$("#takhfif").val();
        var edit_general="edit_general";
        $.ajax({
            url: "../../../shop/Ajax/Process/Admin/setting/general.php",
            type:"POST",
            data:{count:count,fa:fa,en:en,facebook:facebook,twitter:twitter,skype:skype,takhfif:takhfif,edit_general:edit_general},
            success: function(data){
                if(data==true){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> اطلاعات شما ویرایش شد");
                }
                else if(data=="empty"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i>  لطفا همه فیلد ها رو پر کنید ");
                }
                else
                {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> اطلاعات شما ویرایش نشد !");
                }
            }
        });
    });

});