$(document).ready(function () {
    $("#uploadForm").on('submit',(function(e) {
        e.preventDefault();
        $(".result").css("display","block");
        $(".result p").html("<i class='fa fa-refresh fa-spin'></i> صبور باشید در حال پردازش ...  !");
        $.ajax({
            url: "../../Ajax/Process/Admin/setting/slider.php",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(data)
            {
                if(data=="file_empty"){
                    alert("empty");
                }
                else {
                    var htm = $("#uploaded_file").html();
                    var htm = htm + data;
                    $("#uploaded_file").html(htm);
                    $(".result").css("display", "none");
                }
            },
            error: function()
            {
            }
        });
    }));
	    $("#action_post a").click(function () {
        $this=$(this);
        var action=$this.data('action');
        var id=$this.data('id');

        if(action=="delete"){
            var delete_slider_image="delete_slider_image";
            var x=confirm("از حذف پیغام مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Site/slider/slider_delete.php",
                    type: "POST",
                    data: {id:id,delete_slider_image:delete_slider_image},
                    success: function (data) {
                        if (data == 1) {
                            $(".alert-warning").css("display","none");
                            $(".alert-success p").html("تصویر مورد نظر حذف شد");
                            $(".alert-success").css("display","block");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            $(".alert-success").css("display","none");
                            $(".alert-warning p").html("تص.یر مورد نظر شما حذف نشد");
                            $(".alert-warning").css("display","block");
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
    })

})