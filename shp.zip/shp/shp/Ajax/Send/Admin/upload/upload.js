$(document).ready(function () {
    $("#uploadForm").on('submit',(function(e) {
        e.preventDefault();
        $(".result").css("display","block");
        $(".result p").html("<i class='fa fa-refresh fa-spin'></i> صبور باشید در حال پردازش ...  !");
        $.ajax({
            url: "../../Ajax/Process/Admin/upload/upload.php",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(data)
            {
                if(data=="file_empty"){
                    alert("empty");
                }
                else {
                    var htm = $("#uploaded_file").html();
                    var htm = htm + data;
                    $("#uploaded_file").html(htm);
                    $(".result").css("display", "none");
                }

            },
            error: function()
            {
            }
        });
    }));
    $("#uploadForm_slider").on('submit',(function(e) {
        e.preventDefault();
        $(".result").css("display","block");
        $(".result p").html("<i class='fa fa-refresh fa-spin'></i> صبور باشید در حال پردازش ...  !");
        $.ajax({
            url: "../../Ajax/Process/Admin/upload/upload_post_slider.php",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(data)
            {
                if(data=="file_empty"){
                    alert("empty");
                }
                else {
                    var htm = $("#uploaded_file").html();
                    var htm = htm + data;
                    $("#uploaded_file").html(htm);
                    $(".result").css("display", "none");
                }

            },
            error: function()
            {
            }
        });
    }));
    $(".action_post a").click(function(e) {
        $this=$(this);
        var action=$this.data('action');
        var id=$this.data('id');
        var name=$this.data('name');
        if(action=="delete"){
            var delete_media="delete_media";
            var x=confirm("از حذف رسانه مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Admin/upload/media_delete.php",
                    type: "POST",
                    data: {id:id,name:name,delete_media:delete_media},
                    success: function (data) {
                        if (data) {
                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> رسانه مورد نظر با موفقیت حذف شد !");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            alert(data);

                            $(".result").css("display","block");
                            $(".result p").html("<i class='fa fa-warning'></i> رسانه مورد نظر حذف نشد !");
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
    });
})