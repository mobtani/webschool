$(document).ready(function(e) {
    $("#action_post a").click(function () {
        $this=$(this);
        var action=$this.data('action');
        var id=$this.data('id');

        if(action=="delete"){
            var delete_user="delete_user";
            var x=confirm("از حذف پیغام مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Admin/user/delete.php",
                    type: "POST",
                    data: {id:id,delete_user:delete_user},
                    success: function (data) {
                        if (data == 1) {
                            $(".alert-warning").css("display","none");
                            $(".alert-success p").html("کاربر مورد نظر حذف شد");
                            $(".alert-success").css("display","block");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            $(".alert-success").css("display","none");
                            $(".alert-warning p").html("کاربر مورد نظر شما حذف نشد");
                            $(".alert-warning").css("display","block");
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
        else{
            var edit_user="edit_user";
            var x=confirm("می خواهید کاربر را ویرایش کنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Admin/user/edit.php",
                    type: "POST",
                    data: {id:id,edit_user:edit_user},
                    success: function (data) {
                        if (data == 1) {
                            window.location.href='edit.php';
                        } else {
                            $(".alert-success").css("display","none");
                            $(".alert-warning p").html("کاربر مورد نظر شما قابل ویرایش نیست !");
                            $(".alert-warning").css("display","block");
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
    })

    $("#register_user").click(function(e) {
		var name=$("#name").val();
		var family=$("#family").val();
		var username=$("#username").val();
		var pass=$("#pass").val();
        var role=$("#role").val();
        var email=$("#email").val();
        $.ajax({
            url: "../../Ajax/Process/Admin/user/save.php",
            type:"POST",
            data:{name:name,family:family,username:username,pass:pass,role:role,email:email},
            success: function(data){
                if(data==true){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> کاربر جدید ثبت شد");
                }
                    else if(data=="empty"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i>  لطفا همه فیلد ها رو پر کنید ");
                }
                else
                {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> کاربر جدید ثبت نشد !");
                }
            }
        });
    });
    $("#edit_user").click(function(e) {
        var name=$("#name").val();
        var family=$("#family").val();
        var username=$("#username").val();
        var pass=$("#pass").val();
        var role=$("#role").val();
        var email=$("#email").val();
        var final_edit="final_edit";
        $.ajax({
            url: "../../Ajax/Process/Admin/user/edit.php",
            type:"POST",
            data:{name:name,family:family,username:username,pass:pass,role:role,email:email,final_edit:final_edit},
            success: function(data){
                if(data==true){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> کاربر ویرایش شد");
                }
                else if(data=="empty"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i>  لطفا همه فیلد ها رو پر کنید ");
                }
                else
                {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> کاربر ویرایش نشد !");
                }
            }
        });
    });
    $("#edit_cuser").click(function(e) {
        var name=$("#name").val();
        var family=$("#family").val();
        var username=$("#username").val();
        var pass=$("#pass").val();
        var role=$("#role").val();
        var email=$("#email").val();
        var final_cedit="final_cedit";
        $.ajax({
            url: "../../Ajax/Process/Admin/user/edit.php",
            type:"POST",
            data:{name:name,family:family,username:username,pass:pass,role:role,email:email,final_cedit:final_cedit},
            success: function(data){
                if(data==true){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> کاربر ویرایش شد");
                    function explode(){
                        window.location.href="../panel"
                    }
                    setTimeout(explode, 2000);

                }
                else if(data=="empty"){
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i>  لطفا همه فیلد ها رو پر کنید ");
                }
                else
                {
                    $(".result").css("display","block");
                    $(".result p").html("<i class='fa fa-warning'></i> کاربر ویرایش نشد !");
                }
            }
        });
    });


});