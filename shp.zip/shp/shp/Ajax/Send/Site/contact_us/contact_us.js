$(document).ready(function(e) {
    $("#action_post a").click(function () {
        $this=$(this);
        var action=$this.data('action');
        var id=$this.data('id');

        if(action=="delete"){
            var delete_contact_us="delete_contact_us";
            var x=confirm("از حذف پیغام مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../../Ajax/Process/Site/contact_us/contact_us_delete.php",
                    type: "POST",
                    data: {id:id,delete_contact_us:delete_contact_us},
                    success: function (data) {
                        if (data == 1) {
                            $(".alert-warning").css("display","none");
                            $(".alert-success p").html("پیغام مورد نظر حذف شد");
                            $(".alert-success").css("display","block");
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            $(".alert-success").css("display","none");
                            $(".alert-warning p").html("پیغام مورد نظر شما حذف نشد");
                            $(".alert-warning").css("display","block");
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
    })
    //change conntact_us state
    $("#change_state a").click(function () {
                    $this=$(this);
                    var state=$this.data('state');
                    var id=$this.data('id');
                    var update_state="update_contact_us";

                    $.ajax({
                    url: "../../Ajax/Process/Site/contact_us/contact_us.php",
                    type: "POST",
                    data: {state:state,id:id,update_state:update_state},
                    success: function (data) {
                        if (data == 1) {
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 1000);
                        } else {
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 1000);
                        }
                    }
                });
    })
    //check email
    $("#email").keyup(function () {
        var email=$("#email").val();
        $.ajax({
           //url:"../../Site/contact_us/check_field/check.php",
            url:"../../shop/Ajax/Process/Site/contact_us/contact_us.php",
            type:"POST",
            data:{email:email,email_check:"check"},
            success: function(data){
                if(data=="1"){
                    $("#email").css("border","1px solid #D7D7D7");
                }
                else{
                    $("#email").css("border","2px solid #f04c49");
                }
            }
        });
    })
    //save form
    $("#save_contact_us").click(function () {
        var name = $("#name").val();
        var email = $("#email").val();
        var subject = $("#subject").val();
        var comment = $("#comment").val();
        var captcha_user = $("#captcha_user").val();
        $.ajax({
            type: 'POST',
            url:"../../shop/Ajax/Process/Site/contact_us/contact_us.php",
            data: {
                form_save: "saved",
                name: name,
                email: email,
                subject: subject,
                comment: comment,
                captcha_user: captcha_user
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                $('.result_t div').remove();
                for (i = 0; i < result.length; i++) {
                    if(result[i]=="123"){
                        $('.result_t').append("<div class='alert alert-success' role='alert'><i class='fa fa-warning'></i> پیام شما ثبت شد ، تشکر بابت پیام</div>");
                        break;
                    }else if(result[i]=="321"){
                        $('.result_t').append("<div class='alert alert-warning' role='alert'><i class='fa fa-warning'></i> متاسفانه پیام شما ثبت نشد , لطفا دوباره امتحان کنید</div>");
                    }else{
                        $('.result_t').append("<div class='alert alert-danger' role='alert'><i class='fa fa-warning'></i> " + result[i] + "</div>");
                    }
                }
            }
        })
    })
});