$(document).ready(function(e) {
    $(".last_td i").click(function () {
        $this=$(this);
        var action=$this.data('action');
        var id=$this.data('id');
        if(action=="delete"){
            var delete_factor="delete_factor";
            var x=confirm("از حذف محصول مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../shop/Ajax/Process/Site/factor/index.php",
                    type: "POST",
                    data: {id:id,delete_factor:delete_factor},
                    success: function (data) {
                        if (data == 1) {
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
        else if(action=="plus"){
            var increase_factor="increase_factor";
            var x=confirm("از اضافه کردن محصول مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../shop/Ajax/Process/Site/factor/index.php",
                    type: "POST",
                    data: {id:id,increase_factor:increase_factor},
                    success: function (data) {
                        if (data == 1) {
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
        else{
            var decrease_factor="decrease_factor";
            var x=confirm("از کاهش محصول مورد نظر مطمئنید ؟");
            if(x==true)
            {
                $.ajax({
                    url: "../shop/Ajax/Process/Site/factor/index.php",
                    type: "POST",
                    data: {id:id,decrease_factor:decrease_factor},
                    success: function (data) {
                        if (data == 1) {
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        } else {
                            function explode(){
                                location.reload();
                            }
                            setTimeout(explode, 2000);
                        }
                    }
                });
            }
            else
            {
                window.location.href="";
            }
        }
    })
    $("#final_click,#final_click1").click(function () {
        var user_register_check="user_register_check";
        $.ajax({
            url: "../shop/Ajax/Process/Site/factor/index.php",
            type: "POST",
            data: {user_register_check:user_register_check},
            success: function (data) {
                if (data == 1) {
                    $("#state1").css("display","block");
                    $("#state2").css("display","block");
                    $("html, body").animate({ scrollTop: 0 }, "slow");
                } else {
                    window.location.href="factor_accept.php";
                }
            }
        });
    })
    $("#final_click3,#final_click4").click(function () {
        var final_register_factor="final_register_factor";
        $.ajax({
            url: "../shop/Ajax/Process/Site/factor/index.php",
            type: "POST",
            data: {final_register_factor:final_register_factor},
            success: function (data) {
                if (data == 1) {
                    window.location.href="factor_final.php";
                } else {
                }
            }
        });

    })
    $("#change_f_s a").click(function () {
        $this=$(this);
        var state=$this.data('state');
        var code=$this.data('code');
            if(state==0){
                var alternative="1";
            }
            else if(state==1){
                var alternative="2";
            }else{
                var alternative="0";
            }
        $.ajax({
            url: "../../Ajax/Process/Site/factor/index.php",
            type: "POST",
            data: {alternative:alternative,code:code},
            success: function (data) {
                if (data == 1) {
                    function explode(){
                        location.reload();
                    }
                    setTimeout(explode, 2000);
                } else {
                    function explode(){
                        location.reload();
                    }
                    setTimeout(explode, 2000);

                }
            }
        });

    })
});