$(document).ready(function () {
    // check username
    $("#username").keyup(function () {
        var username=$("#username").val();
        $.ajax({
            url:"../shop/Ajax/Process/Site/user_register/user_register.php",
            type:"POST",
            data:{username:username,username_check:"check"},
            success: function(data){
                if(data==1){
                    $("#username_result").css("display","block");
                    $("#username_result").css("color","#f34a4b");
                    $("#username_result").html("متاسفانه نام کاربری زیر رزرو شده است ");
                }
                else{
                    $("#username_result").css("display","block");
                    $("#username_result").css("color","#1cc22e");
                    $("#username_result").html('<i class="fa fa-shopping-cart"></i>');
                }
            }
        });
    })
    //register username
    $("#register").click(function () {

        var check;
        check=$("#write_lege").is(":checked");
        if(check){
            var checked="legs";
        }else{
            var checked="not_legs";
        }


        var name = $("#name").val();
        var username = $("#username").val();
        var password = $("#password").val();
        var re_password = $("#re_password").val();


        $.ajax({
            type: 'POST',
            url:"../shop/Ajax/Process/Site/user_register/user_register.php",
            data: {
                form_save: "saved",
                name: name,
                username: username,
                password: password,
                re_password: re_password,
                checked:checked
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                $('.result_t div').remove();
                for (i = 0; i < result.length; i++) {
                    if(result[i]=="123"){
                        $('.result_t').append("<div class='alert alert-success' role='alert'><i class='fa fa-warning'></i> ثبت نام شما انجام شد جهت تکمیل اطلاعات وارد سایت شوید</div>");
                        break;
                    }else if(result[i]=="321"){
                        $('.result_t').append("<div class='alert alert-warning' role='alert'><i class='fa fa-warning'></i> متاسفانه ثبت نام انجام نشد</div>");
                    }else{
                        $('.result_t').append("<div class='alert alert-danger' role='alert'><i class='fa fa-warning'></i> " + result[i] + "</div>");
                    }
                }
            }
        })
    })
    // check email
    $("#email").keyup(function () {
        var email=$("#email").val();
        $.ajax({
            url:"../shop/Ajax/Process/Site/user_register/user_register.php",
            type:"POST",
            data:{email:email,email_check:"check"},
            success: function(data){
                if(data==1){
                    $("#email_result").css("display","block");
                    $("#email_result").css("color","#1cc22e");
                    $("#email_result").html('<i class="fa fa-check"></i>');
                }
                else{
                    $("#email_result").css("display","block");
                    $("#email_result").css("color","#ff4646");
                    $("#email_result").html(' ایمیل وارد شده معتبر نیست');
                }
            }
        });
    })
    // check mobile
    $("#mobile").keyup(function () {
        var mobile = $("#mobile").val();
        $.ajax({
            url: "../shop/Ajax/Process/Site/user_register/user_register.php",
            type: "POST",
            data: {mobile: mobile, mobile_check: "check"},
            success: function (data) {
                if (data == 1) {
                    $("#mobile_result").css("display", "block");
                    $("#mobile_result").css("color", "#1cc22e");
                    $("#mobile_result").html('<i class="fa fa-check"></i>');
                }
                else {
                    $("#mobile_result").css("display", "block");
                    $("#mobile_result").css("color", "#ff4646");
                    $("#mobile_result").html('  شماره موبایل معتبر نیست');
                }
            }
        });
    })
    // check codeposti
    $("#code_posti").keyup(function () {
        var code_posti=$("#code_posti").val();
        $.ajax({
            url:"../shop/Ajax/Process/Site/user_register/user_register.php",
            type:"POST",
            data:{code_posti:code_posti,code_posti_check:"check"},
            success: function(data){
                if (data != 1) {
                    $("#code_posti_result").css("display", "block");
                    $("#code_posti_result").css("color", "#ff4646");
                    $("#code_posti_result").html('  کد پستی معتبر نیست');
                } else {
                    $("#code_posti_result").css("display", "block");
                    $("#code_posti_result").css("color", "#1cc22e");
                    $("#code_posti_result").html('<i class="fa fa-check"></i>');
                }
            }
        });
    })
    //register username
    $("#edit").click(function () {
        var name = $("#name").val();
        var family = $("#family").val();
        var email = $("#email").val();
        var mobile = $("#mobile").val();
        var tell = $("#tell").val();
        var code_posti = $("#code_posti").val();
        var address = $("#address").val();
        $.ajax({
            type: 'POST',
            url:"../shop/Ajax/Process/Site/user_register/user_register.php",
            data: {
                form_edit_user_info: "edited",
                name: name,
                family: family,
                email: email,
                mobile: mobile,
                tell: tell,
                code_posti: code_posti,
                address:address
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                $('.result_t div').remove();
                for (i = 0; i < result.length; i++) {
                    if(result[i]=="123"){
                        $('.result_t').append("<div class='alert alert-success' role='alert'><i class='fa fa-warning'></i>  اطلاعات شما با موفقیت ویرایش شد <a href='user_panel.php'>برگشت به پنل کاربری</a></div>");
                        break;
                    }else if(result[i]=="321"){
                        $('.result_t').append("<div class='alert alert-warning' role='alert'><i class='fa fa-warning'></i> متاسفانه ثبت نام انجام نشد</div>");
                    }else{
                        $('.result_t').append("<div class='alert alert-danger' role='alert'><i class='fa fa-warning'></i> " + result[i] + "</div>");
                    }
                }
            }
        })
    })
    //change password
    $("#edit_pass").click(function () {
        var pass1 = $("#pass1").val();
        var pass2 = $("#pass2").val();
        var pass3 = $("#pass3").val();
        $.ajax({
            type: 'POST',
            url:"../shop/Ajax/Process/Site/user_register/user_register.php",
            data: {
                form_edit_user_pass: "edited",
                pass1: pass1,
                pass2: pass2,
                pass3: pass3,
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                $('.result_t div').remove();
                for (i = 0; i < result.length; i++) {
                    if(result[i]=="123"){
                        $('.result_t').append("<div class='alert alert-success' role='alert'><i class='fa fa-warning'></i> گذرواژه شما با موفقیت ویرایش شد</div>");
                        break;
                    }else if(result[i]=="321"){
                        $('.result_t').append("<div class='alert alert-warning' role='alert'><i class='fa fa-warning'></i> متاسفانه گذرواژه ویرایش نشد</div>");
                    }else if(result[i]=="213"){
                        $('.result_t').append("<div class='alert alert-warning' role='alert'><i class='fa fa-warning'></i> گذرواژه فعلی تان را اشتباه وارد کردید لطفا تصحیح فرمایید</div>");
                    }else{
                        $('.result_t').append("<div class='alert alert-danger' role='alert'><i class='fa fa-warning'></i> " + result[i] + "</div>");
                    }
                }
            }
        })
    })
    //recovery password
    $("#recovery").click(function () {
        var username = $("#username").val();
        var mobile = $("#mobile").val();
        $.ajax({
            type: 'POST',
            url:"../shop/Ajax/Process/Site/user_register/user_register.php",
            data: {
                form_recovery_user_pass: "edited",
                username: username,
                mobile: mobile,
            },
            dataType: 'json',
            cache: false,
            success: function (result) {
                for (i = 0; i < result.length; i++) {
                    if(result[i]=="123"){
                        $(".result").css("display","block");
                        $(".result p").html("<i class='fa fa-warning'></i> کاربری با مشخصات وارد شده وجود ندارد");
                        break;
                    }else{
                        $(".result").css("display","block");
                        $(".result p").html("<i class='fa fa-check'></i> </a>   " + result[i] + " ");
                    }
                }
            }
        })
    })

})
