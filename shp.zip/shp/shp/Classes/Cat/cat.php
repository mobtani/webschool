<?php
	class category extends Connection {
		function insert($table,$array){
                $query = "INSERT INTO $table (menu_name,menu_parent_id) VALUES ('" . $array['cat_name'] . "','" . $array['parent_id'] . "')";
                $STH = $this->DBH->prepare($query);
                $result1 = $STH->execute();
                return $result1;
        }
        function showData($table){
            $data=array();
            try {
                $query_select = "select * from $table";
                $result_query_select = $this->DBH->query($query_select) or die("failed!");

                while ($result_fectch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                    $data_select[] = $result_fectch_select;
                }
                return $data_select;

            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function showData_single($table,$id){
            try {
                $query_select = "select * from $table WHERE menu_id='".$id."'";
                $result_query_select = $this->DBH->query($query_select) or die("failed!");
                $fetch_category=$result_query_select->fetch();
                return $fetch_category['menu_name'];
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
	  function delete_cat($table,$id){
        try {
            $query_delete = "delete from $table WHERE menu_id='".$id."'";
            $STH = $this->DBH->prepare($query_delete);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
        function insert_user($table,$array){
            $query = "INSERT INTO $table (user_id,user_name,user_family,user_email,user_username,user_password,user_access,user_lastlogin) VALUES (NULL ,'" . $array['name'] . "','" . $array['family'] . "','" . $array['email'] . "','" . $array['username'] . "','" . $array['pass'] . "','" . $array['role'] . "','" . $array['last_login'] . "')";
            $STH = $this->DBH->prepare($query);
            $result1 = $STH->execute();
            return $result1;
        }
        function showData_user($table){
            $data=array();
            try {
                $query_select = "select * from $table";
                $result_query_select = $this->DBH->query($query_select) or die("failed!");

                while ($result_fectch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                    $data_select[] = $result_fectch_select;
                }
                return $data_select;

            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function delete_user($table,$id){
            try {
                $query_delete = "delete from $table WHERE user_id='".$id."'";
                $STH = $this->DBH->prepare($query_delete);
                $result1 = $STH->execute();
                return $result1;
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function showData_user_id($table,$id){
            $data=array();
            try {
                $query_select = "select * from $table where user_id='".$id."'";
                $result_query_select= $this->DBH->query($query_select);
                $fetch_post=$result_query_select->fetch();

                return $fetch_post;
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function update_user($table,$array,$id){
            try {
                $query_update = "UPDATE $table SET `user_name` = '".$array['name']."', 
`user_family` = '".$array['family']."', `user_email` = '".$array['email']."', `user_username` = '".$array['username']."', `user_password` = '".$array['pass']."', 
`user_access` = '".$array['role']."' WHERE user_id = '".$id."'; ";
                $STH = $this->DBH->prepare($query_update);
                $result1 = $STH->execute();
                return $result1;
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function showData_cat_id($table,$id){
            $data=array();
            try {
                $query_select = "select * from $table where menu_id='".$id."'";
                $result_query_select= $this->DBH->query($query_select);
                $fetch_post=$result_query_select->fetch();

                return $fetch_post;
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function update_cat($table,$array,$id){
            try {
                $query_update = "UPDATE $table SET `menu_name` = '".$array['name']."', 
`menu_parent_id` = '".$array['parent']."' WHERE menu_id = '".$id."'; ";
                $STH = $this->DBH->prepare($query_update);
                $result1 = $STH->execute();
                return $result1;
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function insert_anbar($table,$array){
            $query_select = "select * from $table where db_anbar_product_code='".$array['product_name']."'";
            $result_query_select= $this->DBH->query($query_select);
            $rows = $result_query_select->rowCount(); // assuming $result == true
            if($rows<=0)
            {
            $query = "INSERT INTO $table (db_anbar_id,db_anbar_product_code,db_anbar_product_count) VALUES (NULL ,'" . $array['product_name'] . "','" . $array['count'] . "')";
            $STH = $this->DBH->prepare($query);
            $result1 = $STH->execute();
            return $result1;
            }
            else{
                return -1;
            }
        }
        function showData_anbar($table){
            $data=array();
            try {
                $query_select = "select * from $table";
                $result_query_select = $this->DBH->query($query_select) or die("failed!");

                while ($result_fectch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                    $data_select[] = $result_fectch_select;
                }
                return $data_select;

            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function fetch_product_name_by_code($table,$code){
            try {
                $query_select= "select * from $table where db_post_code ='".$code."' limit 1";
                $result_select=$this->DBH->prepare($query_select);
                $result_select->execute();
                $music =  $result_select->fetch();
                return $music['db_post_name_fa'];
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function update_anbar_increase($table,$id){
            try {
                $query_update = "UPDATE $table SET `db_anbar_product_count` = `db_anbar_product_count`+1 WHERE db_anbar_id = '".$id."'; ";
                $STH = $this->DBH->prepare($query_update);
                $result1 = $STH->execute();
                return $result1;
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function update_anbar_decrease($table,$id){
            try {
                $query_update = "UPDATE $table SET `db_anbar_product_count` = `db_anbar_product_count`-1 WHERE db_anbar_id = '".$id."'; ";
                $STH = $this->DBH->prepare($query_update);
                $result1 = $STH->execute();
                return $result1;
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }
        function delete_product_anbar($table,$id){
            try {
                $query_delete = "delete from $table WHERE db_anbar_id='".$id."'";
                $STH = $this->DBH->prepare($query_delete);
                $result1 = $STH->execute();
                return $result1;
            } catch (PDOException $error) {
                echo 'Query failed--->'.$error->getMessage();
            }
        }



    }
?>