<?php
class factor extends Connection {
    function insert($table,$array){
        $query_select = "select * from $table WHERE db_temprory_factor_product_code='" . $array['pcode'] . "' && db_temprory_factor_code='".$array['fcode']."'";
        $STH = $this->DBH->prepare($query_select);
        $result1 = $STH->execute();
        $rows = $STH->rowCount(); // assuming $result == true
        if($rows<=0){
            $query = "INSERT INTO $table (db_temprory_factor_id,db_temprory_factor_product_code,db_temprory_factor_code,db_temprory_factor_product_count,db_temprory_factor_product_color,db_temprory_factor_product_garanti,db_temprory_factor_user_code) VALUES (NULL ,'" . $array['pcode'] . "','" . $array['fcode'] . "','" . $array['pcount'] . "','" . $array['pcolor'] . "','" . $array['pgaranti'] . "','" . $array['ucode'] . "')";
            $STH = $this->DBH->prepare($query);
            $result1 = $STH->execute();
            return $result1;
        }else{
            return "exist";
        }
    }
    function showData($table,$code,$user){
        $data=array();
        try {
            $query_select = "select * from $table WHERE db_temprory_factor_code='".$code."' && db_temprory_factor_user_code='".$user."'";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");

            while ($result_fectch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fectch_select;
            }
            return $data_select;

        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function product_count_factor($table,$code){
        try {
            $query_update = "SELECT * from $table WHERE `db_temprory_factor_code` ='".$code."'";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            $rows = $STH->rowCount(); // assuming $result == true
            return $rows;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function showData_post_in_factor($table,$code){
        $data=array();
        try {
            $query_select = "select * from $table where db_post_code='".$code."'";
            $result_query_select= $this->DBH->query($query_select);
            $fetch_post=$result_query_select->fetch();

            return $fetch_post;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }

    }
    function delete_factor($table,$id){
        try {
            $query_delete = "delete from $table WHERE db_temprory_factor_id='".$id."'";
            $STH = $this->DBH->prepare($query_delete);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function increase_factor($table,$id){
        try {
            $query_update = "UPDATE $table SET `db_temprory_factor_product_count` = db_temprory_factor_product_count+1 WHERE `db_temprory_factor_id` = '".$id."'";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function decrease_factor($table,$id){
        try {
            $query_update = "UPDATE $table SET `db_temprory_factor_product_count` = db_temprory_factor_product_count-1 WHERE `db_temprory_factor_id` = '".$id."'";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function insert_final($table,$array){
            $query = "INSERT INTO $table (db_final_factor_id,db_final_factor_code,db_final_factor_user_code,db_final_factor_date,db_final_factor_price) VALUES (NULL ,'" . $array['fcode'] . "','" . $array['ucode'] . "','" . $array['date'] . "','" . $array['price'] . "')";
            $STH = $this->DBH->prepare($query);
            $result1 = $STH->execute();
            return $result1;
    }
    function showData_post_in_factor_final($table,$user){
        $data=array();
        try {
            $query_select = "select * from $table WHERE db_final_factor_user_code='".$user."'";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");

            while ($result_fectch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fectch_select;
            }
            return $data_select;

        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function showData_factor_in_code($table,$code){
        $data=array();
        try {
            $query_select = "select * from $table where db_final_factor_code='".$code."'";
            $result_query_select= $this->DBH->query($query_select);
            $fetch_post=$result_query_select->fetch();

            return $fetch_post;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }

    }
    function showData_final_factors($table){
        $data=array();
        try {
            $query_select = "select * from $table";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");

            while ($result_fectch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fectch_select;
            }
            return $data_select;

        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function change_factor_state($table,$code,$number){
        try {
            $query_update = "UPDATE $table SET `db_final_factor_state` ='".$number."' WHERE `db_final_factor_code` = '".$code."'";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }

}
