<?php
class post extends Connection {

    function showData_image($table){
        $data=array();
        try {
            $query_select = "select * from $table";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");
            while ($result_fetch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fetch_select;
            }
            return $data_select;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function showData_image_id($table,$id){
        $data=array();
        try {
            $query_select = "select * from $table where uploaded_file_id='".$id."'";
            $result_query_select= $this->DBH->query($query_select);
            $fetch_image=$result_query_select->fetch();

            return $fetch_image;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function insert($table,$array){

        $rand = rand(999,999999);

//        $query = "INSERT INTO `db_post`( `db_post_name_fa`, `db_post_name_en`, `db_post_comment`, `db_post_vezheki`, `db_post_category`, `db_post_garanti`, `db_post_color`, `db_post_gheymat`, `db_post_takhfif`, `db_post_image`, `db_post_code`, `db_post_creator`, `db_post_date`, `db_post_view`) VALUES (1,2,3,4,5,6,7,8,9,0,$rand,2,3,4)";

        $query = "INSERT INTO $table (`db_post_id`, `db_post_name_fa`, `db_post_name_en`, `db_post_comment`, `db_post_vezheki`, `db_post_category`, `db_post_garanti`, `db_post_color`, `db_post_gheymat`, `db_post_takhfif`, `db_post_image`, `db_post_code`, `db_post_creator`, `db_post_date`) VALUES
                                                    (NULL,'".$array['name_fa']."','".$array['name_en']."','".$array['comment']."','".$array['vezheki']."','".$array['category']."','".$array['garanti']."','".$array['color']."','".$array['gheymat']."','".$array['takhfif']."','".$array['image']."','".$array['code']."','".$array['created_by']."','".$array['date']."');";
//        echo $query;
//        die();
        $STH = $this->DBH->prepare($query);
        $result1 = $STH->execute();
        return $result1;

    }
    function showData_post($table){
        $data=array();
        try {
            $query_select = "select * from $table";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");
            while ($result_fetch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fetch_select;
            }
            return @$data_select;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function delete_post($table,$id,$code){
        try {
            $query_delete = "delete from $table WHERE db_post_id='".$id."' && db_post_code='".$code."'";
            $STH = $this->DBH->prepare($query_delete);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function showData_post_id($table,$id,$code){
        $data=array();
        try {
            $query_select = "select * from $table where db_post_id='".$id."' && db_post_code='".$code."'";
            $result_query_select= $this->DBH->query($query_select);
            $fetch_post=$result_query_select->fetch();

            return $fetch_post;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function showData_img_slider_code($table,$code){
        $data=array();
        try {
            $query_select = "select * from $table WHERE db_post_slider_for_post='".$code."'";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");
            if($result_query_select){
                while ($result_fetch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                    $data_select[] = $result_fetch_select;
                }
                return @$data_select;
            }
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function delete_slider_image($table,$name,$code){
        try {
            $query_delete = "delete from $table WHERE db_post_slider_name='".$name."' && db_post_slider_for_post='".$code."'";
            $STH = $this->DBH->prepare($query_delete);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function update_post($table,$array,$code){
        try {
            $query_update = "UPDATE $table SET `db_post_name_fa` = '".$array['name_fa']."', 
`db_post_name_en` = '".$array['name_en']."', `db_post_comment` = '".$array['comment']."', `db_post_vezheki` = '".$array['vezheki']."', `db_post_category` = '".$array['category']."', 
`db_post_garanti` = '".$array['garanti']."', `db_post_color` = '".$array['color']."', `db_post_gheymat` = '".$array['gheymat']."', `db_post_takhfif` = '".$array['takhfif']."', 
`db_post_image` = '".$array['image']."' WHERE db_post_code = '".$code."'; ";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function insert_post_slider($table,$array,$array_1){
        foreach ($array as $array_tr){
            $query = "INSERT INTO $table (db_post_slider_name,db_post_slider_creater,db_post_slider_date,db_post_slider_for_post) VALUES ('" . $array_tr . "','" . $array_1['created_by'] . "','" . $array_1['date'] . "','" . $array_1['for_post'] . "')";
            $STH = $this->DBH->prepare($query);
            $result1 = $STH->execute();
        }
        return $result1;
    }
function showData_post_new($table){
        $data=array();
        try {
            $query_select = "select * from $table order by db_post_id DESC limit 5";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");
            while ($result_fetch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fetch_select;
            }
            return @$data_select;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function update_post_view($table,$code){
        try {
            $query_update = "UPDATE $table SET `db_post_view`=`db_post_view`+1 WHERE db_post_code = '".$code."'; ";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
function showData_post_favourite($table){
        $data=array();
        try {
            $query_select = "select * from $table order by db_post_view DESC limit 5";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");
            while ($result_fetch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fetch_select;
            }
            return @$data_select;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }




}
?>