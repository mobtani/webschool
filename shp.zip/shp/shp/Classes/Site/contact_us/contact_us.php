<?php
class contact_us extends Connection {

    function insert($table,$array){
    try{
        $query = "INSERT INTO $table (`db_contactus_id`, `db_contactus_name`, `db_contactus_email`, `db_contactus_subject`, `db_contactus_comment`, `db_contactus_date`, `db_contactus_state`) VALUES
                                                    (NULL,'".$array['name']."','".$array['email']."','".$array['subject']."','".$array['comment']."','".$array['date']."','".$array['state']."');";
        $STH = $this->DBH->prepare($query);
        $result1 = $STH->execute();
        return $result1;
    }catch (PDOException $error){
        echo 'Query failed--->'.$error->getMessage();
    }
    }
    function showData_contactus($table){
        $data=array();
        try {
            $query_select = "select * from $table ORDER BY db_contactus_state";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");
            while ($result_fetch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fetch_select;
            }
            return $data_select;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function delete($table,$id){
        try {
            $query_delete = "delete from $table WHERE db_contactus_id='".$id."'";
            $STH = $this->DBH->prepare($query_delete);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function change_state($table,$state,$id){
        try {
            $query_update = "UPDATE $table SET `db_contactus_state` ='".$state."' WHERE `db_contactus_id` = '".$id."'";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }

    function count_message_notread($table){
        try {
            $query_update = "SELECT * from $table WHERE `db_contactus_state` ='0'";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            $rows = $STH->rowCount(); // assuming $result == true
            return $rows;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }

    function read_message_not_readed($table){
        $data=array();
        try {
            $query_select = "select * from $table WHERE `db_contactus_state` ='0' limit 3";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");
            while ($result_fetch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fetch_select;
            }
            return @$data_select;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }

}
?>