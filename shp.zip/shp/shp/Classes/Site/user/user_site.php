<?php

class user_site extends Connection
{
    function insert($table,$array){
        try{
            $query = "INSERT INTO $table (`db_user_site_id`, `db_user_site_name`, `db_user_site_password`, `db_user_site_username`,`db_user_site_customer_code`, `register_state`) VALUES
                                                    (NULL,'".$array['name']."','".$array['password']."','".$array['username']."','".$array['user_code']."','".$array['register_state']."');";
            $STH = $this->DBH->prepare($query);
            $result1 = $STH->execute();
            return $result1;
        }catch (PDOException $error){
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function check_username($table,$username){
        try {
            $query_select = "select * from $table WHERE `db_user_site_username`='".$username."'";
            $result_query_select = $this->DBH->prepare($query_select);
            $result1 = $result_query_select->execute();
            $rows = $result_query_select->rowCount(); // assuming $result == true
            return $rows;
        } catch (PDOException $error) {
            echo 'Query failed--->' . $error->getMessage();
        }
    }
    function check_login($table,$array){
        try {
            $query_select = "select * from $table where db_user_site_password='".$array['password']."' && db_user_site_username='".$array['username']."'";
            $result_query_select= $this->DBH->query($query_select);
            $fetch_user=$result_query_select->fetch();
            $row=$result_query_select->rowCount();
            if($row > 0){

                $_SESSION['user_site_logged']=true;
                $_SESSION['user_site_name']=$fetch_user['db_user_site_name'];
                $_SESSION['user_site_family']=$fetch_user['db_user_site_family'];
                $_SESSION['user_site_address']=$fetch_user['db_user_site_address'];
                $_SESSION['user_site_codeposti']=$fetch_user['db_user_site_codeposti'];
                $_SESSION['user_site_tell']=$fetch_user['db_user_site_tell'];
                $_SESSION['user_site_mobile']=$fetch_user['db_user_site_mobile'];
                $_SESSION['user_site_email']=$fetch_user['db_user_site_email'];
                $_SESSION['user_site_customer_code']=$fetch_user['db_user_site_customer_code'];
                $_SESSION['user_site_register_state']=$fetch_user['register_state'];
                $_SESSION['user_site_lastlogin']=$fetch_user['db_user_site_lastlogin'];




                if($array['remember']=='remember'){
                    setcookie("rr","WW",time()+(3600*24*7));
                    setcookie("tt","SSS",time()+(3600*24*7));
                }


                return $row;
            }else{
                return $row;
            }
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function update_user_info($table,$array){
        try {
            $query_update = "UPDATE $table SET `db_user_site_name` = '".$array['name']."', 
`db_user_site_family` = '".$array['family']."', `db_user_site_address` = '".$array['address']."', `db_user_site_codeposti` = '".$array['codeposti']."', 
`db_user_site_tell` = '".$array['tell']."', `db_user_site_mobile` = '".$array['mobile']."', `db_user_site_email` = '".$array['email']."', `register_state` = '".$array['register_state']."'
WHERE db_user_site_customer_code = '".$array['customer_code']."'; ";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function update_user_pass($table,$array){
        try {
            $query_update = "UPDATE $table SET `db_user_site_password` = '".$array['pass2']."' WHERE db_user_site_customer_code = '".$array['customer_code']."'; ";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function check_user_password_for_edit($table,$array){
        try {
            $query_select = "select * from $table WHERE `db_user_site_customer_code`='".$array['customer_code']."' && db_user_site_password='".$array['pass1']."'";
            $result_query_select = $this->DBH->prepare($query_select);
            $result1 = $result_query_select->execute();
            $rows = $result_query_select->rowCount(); // assuming $result == true
            return $rows;
        } catch (PDOException $error) {
            echo 'Query failed--->' . $error->getMessage();
        }
    }
    function recover_user_password($table,$array){
        try {
            $query_select = "select * from $table where db_user_site_username='".$array['username']."' && db_user_site_mobile='".$array['mobile']."'";
            $result_query_select= $this->DBH->query($query_select);
            $fetch_user=$result_query_select->fetch();
            $row=$result_query_select->rowCount();
            if($row > 0){
                $_SESSION['user_pass_recovered']=$fetch_user['db_user_site_password'];
                return $row;
            }else{
                return $row;
            }
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function showData_user_for_factor($table,$user){
        $data=array();
        try {
            $query_select = "select * from $table where db_user_site_customer_code='".$user."'";
            $result_query_select= $this->DBH->query($query_select);
            $fetch_post=$result_query_select->fetch();

            return $fetch_post;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }

    }
    function showData_user($table){
        $data=array();
        try {
            $query_select = "select * from $table";
            $result_query_select = $this->DBH->query($query_select) or die("failed!");
            while ($result_fetch_select = $result_query_select->fetch(PDO::FETCH_ASSOC)) {
                $data_select[] = $result_fetch_select;
            }
            return @$data_select;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }

}
?>