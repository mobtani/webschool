<?php
session_start();
class user extends Connection{

    function check_login($table,$array){
        try {
            $query_select = "select * from $table where user_username='".$array['username']."' && user_password='".$array['password']."'";
            $result_query_select= $this->DBH->query($query_select);
            $fetch_user=$result_query_select->fetch();
            $row=$result_query_select->rowCount();
            if($row > 0){

                if($array['remember']=='remember'){
                    setcookie("rr",$fetch_user['user_username'],time()+(3600*24*7));
                    setcookie("tt",$fetch_user['user_password'],time()+(3600*24*7));
                }
                $_SESSION['user_logged']=true;
                $_SESSION['user_name']=$fetch_user['user_name'];
                $_SESSION['user_family']=$fetch_user['user_family'];
                $_SESSION['user_email']=$fetch_user['user_email'];
                $_SESSION['user_access']=$fetch_user['user_access'];
                $_SESSION['user_avatar']=$fetch_user['user_avatar'];
                $_SESSION['user_username']=$fetch_user['user_username'];
                $_SESSION['user_pass']=$fetch_user['user_password'];
                $_SESSION['user_id_1']=$fetch_user['user_id'];
                $_SESSION['user_lastlogin']=$fetch_user['user_lastlogin'];
                return $row;
            }else{
                return $row;
            }
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }

    function logout(){
        session_destroy();
        header("location:login_logout/login.php");
    }
}