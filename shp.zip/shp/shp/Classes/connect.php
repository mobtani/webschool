<?php
class Connection {
    protected $host = "localhost";
    protected $dbname = "shp";
	//اسم دیتابیسی که ساختیم رو وارد میکنیم
    protected $user = "root";
    protected $pass = "";
    public $DBH;
    function __construct() {
        try {
            $this->DBH = new PDO("mysql:host=$this->host;dbname=$this->dbname",$this->user,$this->pass);
            $this->DBH->query("set character set utf8");
        }
        catch (PDOException $error) {

            echo $error->getMessage();
        }
    }
    public function closeConnection() {

        $this->DBH = null;
    }
}
?>