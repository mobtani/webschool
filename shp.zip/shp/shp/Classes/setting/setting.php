<?php
class setting extends Connection {

    function fetch_count_image_site_slider($table){
        try {
            $query_select= "select * from $table where db_setting_admin_id =1 limit 1";
			$result_select=$this->DBH->prepare($query_select);
			$result_select->execute();
			$music =  $result_select->fetch();
			return $music['db_setting_admin_value'];
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }

    }
    function fetch_logo_name($table){
        try {
            $query_select= "select * from $table where db_setting_admin_id =2 limit 1";
            $result_select=$this->DBH->prepare($query_select);
            $result_select->execute();
            $music =  $result_select->fetch();
            return $music['db_setting_admin_value'];
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function fetch_fa_copyright($table){
        try {
            $query_select= "select * from $table where db_setting_admin_id =3 limit 1";
            $result_select=$this->DBH->prepare($query_select);
            $result_select->execute();
            $music =  $result_select->fetch();
            return $music['db_setting_admin_value'];
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function fetch_en_copyright($table){
        try {
            $query_select= "select * from $table where db_setting_admin_id =4 limit 1";
            $result_select=$this->DBH->prepare($query_select);
            $result_select->execute();
            $music =  $result_select->fetch();
            return $music['db_setting_admin_value'];
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function fetch_facebook($table){
        try {
            $query_select= "select * from $table where db_setting_admin_id =5 limit 1";
            $result_select=$this->DBH->prepare($query_select);
            $result_select->execute();
            $music =  $result_select->fetch();
            return $music['db_setting_admin_value'];
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function fetch_twitter($table){
        try {
            $query_select= "select * from $table where db_setting_admin_id =7 limit 1";
            $result_select=$this->DBH->prepare($query_select);
            $result_select->execute();
            $music =  $result_select->fetch();
            return $music['db_setting_admin_value'];
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function fetch_skype($table){
        try {
            $query_select= "select * from $table where db_setting_admin_id =8 limit 1";
            $result_select=$this->DBH->prepare($query_select);
            $result_select->execute();
            $music =  $result_select->fetch();
            return $music['db_setting_admin_value'];
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function fetch_takhfif($table){
        try {
            $query_select= "select * from $table where db_setting_admin_id =9 limit 1";
            $result_select=$this->DBH->prepare($query_select);
            $result_select->execute();
            $music =  $result_select->fetch();
            return $music['db_setting_admin_value'];
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }
    function general_edit($table,$array){
        try {
            $query_update = "
UPDATE $table SET `db_setting_admin_value` = '".$array['count']."' WHERE db_setting_admin_id =1;
UPDATE $table SET `db_setting_admin_value` = '".$array['fa']."' WHERE db_setting_admin_id =3;
UPDATE $table SET `db_setting_admin_value` = '".$array['en']."' WHERE db_setting_admin_id =4;
UPDATE $table SET `db_setting_admin_value` = '".$array['facebook']."' WHERE db_setting_admin_id =5;
UPDATE $table SET `db_setting_admin_value` = '".$array['twitter']."' WHERE db_setting_admin_id =7;
UPDATE $table SET `db_setting_admin_value` = '".$array['skype']."' WHERE db_setting_admin_id =8;
UPDATE $table SET `db_setting_admin_value` = '".$array['takhfif']."' WHERE db_setting_admin_id =9;
             ";
            $STH = $this->DBH->prepare($query_update);
            $result1 = $STH->execute();
            return $result1;
        } catch (PDOException $error) {
            echo 'Query failed--->'.$error->getMessage();
        }
    }


}
?>