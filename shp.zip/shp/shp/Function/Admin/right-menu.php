
<div class="col-lg-2 col-xs-12 t_right">
  <ul>
    <li>
      <a href="../../Admin/panel/index.php"> <p><i class="fa fa-dashboard icon_right"></i> پیشخوان <i class="fa fa-angle-right icon_left"></i></p></a>
    </li>
    <li>
      <p><i class="fa fa-dashboard icon_right"></i> نمایش <i class="fa fa-angle-right icon_left"></i></p>
            <ul>
        <a href="../../Admin/Post/show.php"> <li><i class="fa fa-dashboard icon_right"></i> محصولات <i class="fa fa-angle-right icon_left"></i></li></a>
        <a href="../../Admin/category"><li><i class="fa fa-dashboard icon_right"></i> دسته ها <i class="fa fa-angle-right icon_left"></i></li></a>
        <a href="../../Admin/upload_center/index.php"><li><i class="fa fa-dashboard icon_right"></i> رسانه <i class="fa fa-angle-right icon_left"></i></li></a>
        <a href="../../Admin/users/show.php"><li><i class="fa fa-dashboard icon_right"></i> کاربران <i class="fa fa-angle-right icon_left"></i></li></a>
        <a href="../../site/contact_us/show.php"><li><i class="fa fa-dashboard icon_right"></i> پیام ها <i class="fa fa-angle-right icon_left"></i></li></a>
      </ul>

    </li>
      <li>
          <p><i class="fa fa-dashboard icon_right"></i> نوشته ها <i class="fa fa-angle-right icon_left"></i></p>
          <ul>
              <a href="../../Admin/Post/index.php"> <li><i class="fa fa-dashboard icon_right"></i> افزودن محصول  <i class="fa fa-angle-right icon_left"></i></li></a>
              <a href="../../Admin/category"><li><i class="fa fa-dashboard icon_right"></i> افزودن دسته <i class="fa fa-angle-right icon_left"></i></li></a>
              <a href="../../Admin/upload_center/upload.php"><li><i class="fa fa-dashboard icon_right"></i> افزودن رسانه <i class="fa fa-angle-right icon_left"></i></li></a>
              <a href="../../Admin/users/index.php"><li><i class="fa fa-dashboard icon_right"></i> افزودن کاربر <i class="fa fa-angle-right icon_left"></i></li></a>
          </ul>

      </li>
    <li>
      <p><a href="../../Admin/users/show.php"><i class="fa fa-dashboard icon_right"></i> کاربران <i class="fa fa-angle-right icon_left"></i></p></a>
    </li>
    <li>
      <p><a href="../../Admin/upload_center/upload.php"><i class="fa fa-dashboard icon_right"></i> آپلود سنتر <i class="fa fa-angle-right icon_left"></i></p></a>
    </li>
    <li>
        <a href="../../site/contact_us/show.php"><p><i class="fa fa-dashboard icon_right"></i> تماس با ما <i class="fa fa-angle-right icon_left"></i></p></a>
    </li>
    <li>
      <p><i class="fa fa-dashboard icon_right"></i> تنظیمات <i class="fa fa-angle-right icon_left"></i></p>
        <ul>
            <a href="../../Admin/setting/index.php"> <li><i class="fa fa-dashboard icon_right"></i> لوگو  <i class="fa fa-angle-right icon_left"></i></li></a>
            <a href="../../Admin/setting/general.php"><li><i class="fa fa-dashboard icon_right"></i> تنظیمات عمومی <i class="fa fa-angle-right icon_left"></i></li></a>
        </ul>
    </li>
    <li>
        <a href="../../Admin/setting/current_user.php"><p><i class="fa fa-dashboard icon_right"></i> تنظیمات کاربر جاری <i class="fa fa-angle-right icon_left"></i></p></a>
    </li>
        <li>
            <a href="/"><p><i class="fa fa-dashboard icon_right"></i> نمایش سایت <i class="fa fa-angle-right icon_left"></i></p></a>
    </li>
  </ul>
</div>
