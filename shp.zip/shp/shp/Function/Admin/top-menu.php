			<div class="row">
            	<div class="col-lg-12 col-xs-12 t_top navbar-fixed-top hidden-xs">
                	<ul class="right_menu">
                    	<li> <p><i class="fa fa-chevron-circle-down"></i> <?php echo $_SESSION['user_name'].' '.$_SESSION['user_family'] ?> </p> 
                        	<ul>
                            	<a href="../../Admin/setting/current_user.php" ><li><i class="fa fa-user"></i> حساب کاربری </li></a>
                                <li id="logout" ><i class="fa fa-key"></i> خروج </li>
                            </ul>
                        </li>
                    <li>
                        <p><i class="fa fa-envelope-o">
                                <p1>
                                    <?php
                                    $array=$contact_us->count_message_notread(contact_us_table);
                                    echo $array;
                                    ?>
                                </p1>
                            </i></p>
                        <ul class="menu_box">
                            <li> شما <?php echo $array; ?> پیام خوانده نشده دارید !</li>
                            <?php
                                $array_read=$contact_us->read_message_not_readed(contact_us_table);
                            if($array_read) {
                                foreach ($array_read as $result) {
                                    echo '
                                        <li>
                                            <div class="avatar"><img src="../../../Image/nopic.png"></div>
                                            <div class="message">
                                                <h1> ' . $result['db_contactus_name'] . ' </h1>
                                                <p>' . substr($result['db_contactus_comment'], 0, 40) . '...</p>
                                            </div>
                                        </li>

                                    ';
                                }
                            }
                            ?>
                            <li><a href="../../site/contact_us/show.php" target="_blank">مشاهده تمام پیام ها</a></li>
                        </ul>
                    </li>
                    </ul>
                </div>
            </div>
