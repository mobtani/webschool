// JavaScript Document
$(document).ready(function(e) {
	////////////////////////////
    $(".t_body .t_right ul li").click(function(e) {
		$(this).css("background","rgba(243,243,243,1.00)");
        $('ul',this).slideToggle(1000);
    });
	///////////////////////////
	//clock show code ------------start
	setInterval(clock,1000);
	document.getElementById("clock1").innerHTML=" <i class='fa fa-clock-o'></i> " + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
	function clock()
	{
	document.getElementById("clock1").innerHTML=" <i class='fa fa-clock-o'></i> " + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
	}
	//clock show code ------------end
    //////////////////////////////
    $(function(){

        $('#testDiv').slimscroll({
        });
        $('#testDivNested').slimscroll({
            width: '100%',
        }).parent().css({
            'float': 'right',
            'margin': '0px 0px 0px 0px'
        });

    });
    ///////////////////////////////
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
    ///////////////////////////////
    $("#logout").click(function () {
        $.ajax({
            url:"../login_logout/logout.php",
            type: "POST",
            data: {a:"A"},
            success: function (data) {
                if(data=="1"){
                        location.reload();
                }
            }
        })
    })
})