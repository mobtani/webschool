$(document).ready(function(e) {
      $(function() {
    $( "#logo-range" ).slider({
      range: true,
      min: 0,
      max: 1000000,
      values: [119800, 770000 ],
      slide: function( event, ui ) {
        $( "#amount" ).val(ui.values[ 0 ] + " تومان ");
		$( "#amount1" ).val(ui.values[ 1 ] + " تومان ");
      }
    });
	$( "#amount" ).val($( "#logo-range" ).slider( "values", 0 ) + " تومان ");
	$( "#amount1" ).val($( "#logo-range" ).slider( "values", 1 ) + " تومان ");
		
  });
});