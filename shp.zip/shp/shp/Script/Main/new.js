// JavaScript Document
$(document).ready(function(e) {
    $("#show_topmenu,#show_topmenu").click(function(e) {
        $(".top_menu_right ul li").css("display","block");
    });
});
//clock show code ------------start
setInterval(clock,1000);
document.getElementById("clock1").innerHTML=" <i class='fa fa-clock-o'></i> " + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
function clock()
{
document.getElementById("clock1").innerHTML=" <i class='fa fa-clock-o'></i> " + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
}
//clock show code ------------end
