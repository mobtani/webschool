// JavaScript Document
$(document).ready(function(e) {
    $("#novbar_show,#novbar_show1").click(function(e) {
        $(".middle_right").slideToggle(1000);
    });
});
//clock show code ------------start
setInterval(clock,1000);
document.getElementById("clock1").innerHTML=" <i class='fa fa-clock-o'></i> " + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
function clock()
{
document.getElementById("clock1").innerHTML=" <i class='fa fa-clock-o'></i> " + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
}
//clock show code ------------end
