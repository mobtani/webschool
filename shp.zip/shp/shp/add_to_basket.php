<?php
session_start();
define('temprory_factor','db_temprory_factor');

include_once("Classes/connect.php");
include_once("Classes/Factor/factor.php");
$factor=new factor();
$connect=new Connection();

if(!isset($_SESSION['temprory_factor_code'])){
    $_SESSION['temprory_factor_code']=rand(10203404050,504060304201090);
}

setcookie("factor",$_SESSION['temprory_factor_code'],time()+(3600*24*7));
$array_args=array(
    'pcode'=> $_GET['code'],
    'fcode'=> $_SESSION['temprory_factor_code'],
    'pcount'=> 1,
    'pcolor'=> $_POST['color'],
    'pgaranti'=> $_POST['garanti'],
    'ucode'=> $_SESSION['user_site_customer_code']
);

$result=$factor->insert(temprory_factor,$array_args);

header("location:single.php?id=".$_GET['id'].'&code='.$_GET['code']);