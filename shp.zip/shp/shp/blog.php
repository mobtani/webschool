<?php
define('post_table','db_post');
define('setting','db_setting_admin');
define('site_slider','db_slider');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include('Classes/Factor/factor.php');

include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('INCLUDE/functions.php');


$connect=new Connection();
$upload=new upload();
$user=new user();
$category=new category();
$post=new post();
$setting=new setting();
$connect=new Connection();
$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

$factor=new factor();


$value=$setting->fetch_count_image_site_slider(setting);
define('temprory_factor','db_temprory_factor');

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }

    $factor_product_count=$factor->product_count_factor(temprory_factor,$code);
}

?>

<?php
try
{
	$connect=new PDO("mysql:host=localhost;dbname=shp","root","");
	$connect->query("Set character set utf8");
}
catch(PDOException $error)
{
	echo $error;
}
?>
<title>محصولات  </title>
<?php include ("header.php") ; ?>
    
    
    
    
    <!--CONTENT START-->
        <div class="row content"><!-- the content(middle) of page(blog,sidebar & ...) -->
        	<div class="content_blog">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 content_blog_content_left pull-left">
                	<div class="content_left_top">
                    <form action="blog.php" method="get">
      					<input type="text" name="search" class="form-control content_input" style="padding-right:10px;" placeholder="جستجو ... " aria-describedby="basic-addon1"></form>
                    </div>
                    <div class="content_left_content">
                    	<div class="row">
                              					<?php
					$k=3;
					if(isset($_GET['page']))
					{
						if(isset($_GET['catname']))
						{
							//بدست اوردن ای دی نام دسته جهت انتخاب محصولات
							$query_select_catid="select * from db_menu where menu_name='".$_GET['catname']."'";
							$result_select_catid=$connect->query($query_select_catid);
							$fetch_cat_name=$result_select_catid->fetch();

							$g=($_GET['page'])*$k;
							$query_select="select * from db_post where db_post_category='".$fetch_cat_name['menu_id']."' order by db_post_id limit $g,$k";
							$result_select=$connect->query($query_select);
							while($res=$result_select->fetch(PDO::FETCH_ASSOC))
							{
																		$gheymat_1=$res['db_post_gheymat'];
			$takhfif=round($res['db_post_gheymat'] * ($res['db_post_takhfif'] /100));
			$gheymat_2=$gheymat_1 - $takhfif;

							echo'
										<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
											<div class="thumbnail">
						<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><img src="Ajax/Save/images/'.$res['db_post_image'].'" class="img-circle" alt="..."></a>
											  <div class="caption">
												<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><h3> '.$res['db_post_name_fa'].' </h3></a>
												<div class="caption_bottom">
													<div class="caption_bottom_red">'.$gheymat_1.' </div>
													<div class="caption_bottom_green">
														<div class="right"> '.$gheymat_2.' </div>
														<div class="left"><i class="fa fa-ambulance"></i></div>
													</div>
												</div>
											  </div>
											</div>
										  </div>
					';
							}
						}
						elseif(isset($_GET['search']))
						{

							$g=($_GET['page'])*$k;
							$query_select="select * from db_post where db_post_name_fa like'%".($_GET['search'])."%' order by db_post_id limit $g,$k";
							$result_select=$connect->query($query_select);
							while($res=$result_select->fetch(PDO::FETCH_ASSOC))
							{
																		$gheymat_1=$res['db_post_gheymat'];
			$takhfif=round($res['db_post_gheymat'] * ($res['db_post_takhfif'] /100));
			$gheymat_2=$gheymat_1 - $takhfif;

							echo'
										<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
											<div class="thumbnail">
						<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><img src="Ajax/Save/images/'.$res['db_post_image'].'" class="img-circle" alt="..."></a>
											  <div class="caption">
												<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><h3> '.$res['db_post_name_fa'].' </h3></a>
												<div class="caption_bottom">
													<div class="caption_bottom_red">'.$gheymat_1.' </div>
													<div class="caption_bottom_green">
														<div class="right"> '.$gheymat_2.' </div>
														<div class="left"><i class="fa fa-ambulance"></i></div>
													</div>
												</div>
											  </div>
											</div>
										  </div>
					';
							}
						}
						else
						{
							$g=($_GET['page'])*$k;
							$query_select="select * from db_post order by db_post_id limit $g,$k";
							$result_select=$connect->query($query_select);
							while($res=$result_select->fetch(PDO::FETCH_ASSOC))
							{
																		$gheymat_1=$res['db_post_gheymat'];
			$takhfif=round($res['db_post_gheymat'] * ($res['db_post_takhfif'] /100));
			$gheymat_2=$gheymat_1 - $takhfif;

							echo'
										<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
											<div class="thumbnail">
						<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><img src="Ajax/Save/images/'.$res['db_post_image'].'" class="img-circle" alt="..."></a>
											  <div class="caption">
												<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><h3> '.$res['db_post_name_fa'].' </h3></a>
												<div class="caption_bottom">
													<div class="caption_bottom_red">'.$gheymat_1.' </div>
													<div class="caption_bottom_green">
														<div class="right"> '.$gheymat_2.' </div>
														<div class="left"><i class="fa fa-ambulance"></i></div>
													</div>
												</div>
											  </div>
											</div>
										  </div>
					';
							}
						}
					}
					elseif(isset($_GET['catname']))
					{
		
						//بدست اوردن ای دی نام دسته جهت انتخاب محصولات
						$query_select_catid="select * from db_menu where menu_name='".$_GET['catname']."'";
						$result_select_catid=$connect->query($query_select_catid);
						
						$fetch_cat_name=$result_select_catid->fetch();

						$query_select="select * from db_post where db_post_category='".$fetch_cat_name['menu_id']."' order by `db_post_id` asc limit 0,$k";
						$result_select=$connect->query($query_select);
						while($res=$result_select->fetch(PDO::FETCH_ASSOC))
						{
																	$gheymat_1=$res['db_post_gheymat'];
			$takhfif=round($res['db_post_gheymat'] * ($res['db_post_takhfif'] /100));
			$gheymat_2=$gheymat_1 - $takhfif;

							echo'
										<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
											<div class="thumbnail">
						<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><img src="Ajax/Save/images/'.$res['db_post_image'].'" class="img-circle" alt="..."></a>
											  <div class="caption">
												<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><h3> '.$res['db_post_name_fa'].' </h3></a>
												<div class="caption_bottom">
													<div class="caption_bottom_red">'.$gheymat_1.' </div>
													<div class="caption_bottom_green">
														<div class="right"> '.$gheymat_2.' </div>
														<div class="left"><i class="fa fa-ambulance"></i></div>
													</div>
												</div>
											  </div>
											</div>
										  </div>
					';
						}
					}
					elseif(isset($_GET['search']))
					{
						$query_select="select * from db_post where db_post_name_fa like'%".($_GET['search'])."%' order by `db_post_id` asc limit 0,$k";
						$result_select=$connect->query($query_select);
						while($res=$result_select->fetch(PDO::FETCH_ASSOC))
						{
																	$gheymat_1=$res['db_post_gheymat'];
			$takhfif=round($res['db_post_gheymat'] * ($res['db_post_takhfif'] /100));
			$gheymat_2=$gheymat_1 - $takhfif;

							echo'
										<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
											<div class="thumbnail">
						<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><img src="Ajax/Save/images/'.$res['db_post_image'].'" class="img-circle" alt="..."></a>
											  <div class="caption">
												<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><h3> '.$res['db_post_name_fa'].' </h3></a>
												<div class="caption_bottom">
													<div class="caption_bottom_red">'.$gheymat_1.' </div>
													<div class="caption_bottom_green">
														<div class="right"> '.$gheymat_2.' </div>
														<div class="left"><i class="fa fa-ambulance"></i></div>
													</div>
												</div>
											  </div>
											</div>
										  </div>
					';
						}
					}
					else
					{
						$query_select="select * from db_post order by `db_post_id` asc limit 0,$k";
						$result_select=$connect->query($query_select);
						while($res=$result_select->fetch(PDO::FETCH_ASSOC))
						{
										$gheymat_1=$res['db_post_gheymat'];
			$takhfif=round($res['db_post_gheymat'] * ($res['db_post_takhfif'] /100));
			$gheymat_2=$gheymat_1 - $takhfif;

							echo'
										<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
											<div class="thumbnail">
						<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><img src="Ajax/Save/images/'.$res['db_post_image'].'" class="img-circle" alt="..."></a>
											  <div class="caption">
												<a href="single.php?id='.$res['db_post_id'].'&code='.$res['db_post_code'].'"><h3> '.$res['db_post_name_fa'].' </h3></a>
												<div class="caption_bottom">
													<div class="caption_bottom_red">'.$gheymat_1.' </div>
													<div class="caption_bottom_green">
														<div class="right"> '.$gheymat_2.' </div>
														<div class="left"><i class="fa fa-ambulance"></i></div>
													</div>
												</div>
											  </div>
											</div>
										  </div>
					';
						}
					}
					?>

						</div>
                        
                    </div>
                    <nav>
                      <ul class="pagination">
								<?php
								if(isset($_GET['catname']))
								{
							$query_count="select * from db_post where db_post_category='".$fetch_cat_name['menu_id']."'";
									$result_count=$connect->query($query_count);
									$n=$result_count->rowCount();
								}
								elseif(isset($_GET['search']))
								{
							$query_count="select * from db_post where db_post_name_fa like'%".($_GET['search'])."%'";
									$result_count=$connect->query($query_count);
									$n=$result_count->rowCount();
								}
								else
								{
									$query_count="select * from db_post";
									$result_count=$connect->query($query_count);
									$n=$result_count->rowCount();
								}
								if(isset($_GET['catname']))
								{
									if(isset($_GET['page']))
									{
										echo'<li><div class="page" style="width:80px;">صفحه '.$_GET['page'].' از '.ceil($n/$k).'</div></li>';
									}
									else
									{
										echo'<li><div class="page" style="width:80px;">صفحه 1 از '.ceil($n/$k).'</div></li>';
									}
									$number=ceil($n/$k)+1;
									if($number>6)
									{
										for($i=1;$i<6;$i++)
										{
											echo '<li><a href="blog.php?catname=' .$_GET['catname'].'&page='.$i.'"><div class="page">'.$i.'</div></a></li>';
										}
										if(!isset($_GET['page']))
										{
											echo '<li><div class="page">..</div></li>';
										}
										elseif($_GET['page']>=5)
										{
											for($y=6;$y<=$_GET['page'];$y++)
											{
												echo '<li><a href="blog.php?catname=' .$_GET['catname'].'&page='.$y.'"><div class="page">'.$y.'</div></a></li>';
											}
											for($z=$_GET['page']+1;$z<$number&&$z<$_GET['page']+2;$z++)
											{
												echo '<li><a href="blog.php?catname=' .$_GET['catname'].'&page='.$z.'"><div class="page">'.$z.'</div></a></li>';
											}
											if($z<$number)
											{
												echo '<li><div class="page">..</div></li>';
											}
										}
										elseif($_GET['page']<=4)
										{
											echo '<li><div class="page">..</div></li>';
										}
									}
									else
									{
										for($f=1;$f<$number-1;$f++)
										{

											echo '<li><a href="blog.php?catname=' .$_GET['catname'].'&page='.$f.'"><div class="page">'.$f.'</div></a></li>';
										}
									}
								}




								else if(isset($_GET['search']))
								{
									if(isset($_GET['page']))
									{
										echo'<li><div class="page" style="width:80px;">صفحه '.$_GET['page'].' از '.ceil($n/$k).'</div></li>';
									}
									else
									{
										echo'<li><div class="page" style="width:80px;">صفحه 1 از '.ceil($n/$k).'</div></li>';
									}
									$number=ceil($n/$k)+1;
									if($number>6)
									{
										for($i=1;$i<6;$i++)
										{
											echo '<li><a href="blog.php?search=' .$_GET['search'].'&page='.$i.'"><div class="page">'.$i.'</div></a></li>';
										}
										if(!isset($_GET['page']))
										{
											echo '<li><div class="page">..</div></li>';
										}
										elseif($_GET['page']>=5)
										{
											for($y=6;$y<=$_GET['page'];$y++)
											{
												echo '<li><a href="blog.php?search=' .$_GET['search'].'&page='.$y.'"><div class="page">'.$y.'</div></a></li>';
											}
											for($z=$_GET['page']+1;$z<$number&&$z<$_GET['page']+2;$z++)
											{
												echo '<li><a href="blog.php?search=' .$_GET['search'].'&page='.$z.'"><div class="page">'.$z.'</div></a></li>';
											}
											if($z<$number)
											{
												echo '<li><div class="page">..</div></li>';
											}
										}
										elseif($_GET['page']<=4)
										{
											echo '<li><div class="page">..</div></li>';
										}
									}
									else
									{
										for($f=1;$f<$number-1;$f++)
										{

											echo '<li><a href="blog.php?search=' .$_GET['search'].'&page='.$f.'"><div class="page">'.$f.'</div></a></li>';
										}
									}
								}


								else
								{
									if(isset($_GET['page']))
									{
										echo'<li><div class="page" style="width:80px;">صفحه '.$_GET['page'].' از '.ceil($n/$k).'</div></li>';
									}
									else
									{
										echo'<li><div class="page" style="width:80px;">صفحه 1 از '.ceil($n/$k).'</div></li>';
									}
									$number=ceil($n/$k)+1;
									if($number>6)
									{
										for($i=1;$i<6;$i++)
										{
											echo '<li><a href="blog.php?page=' .$i.'"><div class="page">'.$i.'</div></a></li>';
										}
										if(!isset($_GET['page']))
										{
											echo '<li><div class="page">..</div></li>';
										}
										elseif($_GET['page']>=5)
										{
											for($y=6;$y<=$_GET['page'];$y++)
											{
												echo '<li><a href="blog.php?page=' .$y.'"><div class="page">'.$y.'</div></a></li>';
											}
											for($z=$_GET['page']+1;$z<$number&&$z<$_GET['page']+2;$z++)
											{
												echo '<li><a href="blog.php?page=' .$z.'"><div class="page">'.$z.'</div></a></li>';
											}
											if($z<$number)
											{
												echo '<li><div class="page">..</div></li>';
											}
										}
										elseif($_GET['page']<=4)
										{
											echo '<li><div class="page">..</div></li>';
										}
									}
									else
									{
										for($f=1;$f<$number;$f++)
										{
											$r=$f-1;
											echo '<li><a href="blog.php?page=' .$r.'"><div class="page">'.$f.'</div></a></li>';
										}
									}

								}
								?>
                      </ul>
                   </nav>
                </div>
            </div>
        </div>
    <!--CONTENT END-->




<?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>


<!--jquery ui js-->
<script src="Script/jquery-ui-1.11.4/jquery-ui.js"></script>
<script src="Script/Main/jquery_function.js"></script>


</body>
</html>