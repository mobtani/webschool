<?php
define('post_table','db_post');
define('setting','db_setting_admin');
define('site_slider','db_slider');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('Classes/Factor/factor.php');
include('INCLUDE/functions.php');


$upload=new upload();
$user=new user();
$category=new category();
$post=new post();
$setting=new setting();
$connect=new Connection();
$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

$factor=new factor();

define('temprory_factor','db_temprory_factor');

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }

    $factor_product_count=$factor->product_count_factor(temprory_factor,$code);
}

?>
<title> تماس با ما </title>
<?php include ("header.php") ; ?>




<!--CONTENT START-->
        <div class="row content"><!-- the content(middle) of page(blog,sidebar & ...) -->
			<div class="content_register">
                <div class="content_register_content">
                	<div class="content_register_content_top">
                    	<i class="fa fa-phone-square"></i>
                        <p> جهت تماس با ما فرم زیر را پر کنید </p>
                    </div>
                    <div class="content_register_content_content">
                    	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 content_register_content_content_right pull-right">
                            <div class="result_t" style="display: block; width: 100%;">

                            </div>
                        	<label> نام شما :</label>
      <input type="text" class="form-control content_input" placeholder="NAME" aria-describedby="basic-addon1" id="name">
      						<label> ایمیل شما :</label>
      <input type="text" class="form-control content_input" placeholder="EMAIL" aria-describedby="basic-addon1" id="email">
      						<label> موضوع :</label>
                                <select class="content_input" id="subject">
                                    <option> انتخاب کنید :</option>
                                    <option> پیشنهاد </option>
                                    <option> انتقاد یا شکایت </option>
                                </select>

                            <label> متن پیام :</label>
                            <textarea class="form-control content_textarea" aria-describedby="basic-addon1" id="comment"></textarea>

                            <div class="captcha">
                                <label>لطفا کد امنیتی زیر را وارد کنید !</label>
                                <input type="text" class="content_input" id="captcha_user">
                                <div class=""><img src="captcha.php" alt="کد امنیتی" id="captcha" style="float: right;"/><img src="Image/interact.ico" alt="کد امنیتی جدید " title="کد امنیتی جدید " style="float: right" width="15px" height="15px" onclick="change_captcha();"/>
                                </div>
                            </div>
                            <button type="button" id="save_contact_us" class="btn btn-default content_button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    ثبت اطلاعات
  </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!--CONTENT END-->




<?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>
<script src="Ajax/Send/Site/contact_us/contact_us.js"></script>
<script type="text/javascript">
    function change_captcha()
    {
        document.getElementById('captcha').src="captcha.php?rand="+ Math.random();
    }
</script>

</body>
</html>