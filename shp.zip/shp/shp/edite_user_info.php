<?php
define('post_table','db_post');
define('setting','db_setting_admin');
define('site_slider','db_slider');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('Classes/Factor/factor.php');
include('INCLUDE/functions.php');


$upload=new upload();
$user=new user();
$category=new category();
$post=new post();
$setting=new setting();
$connect=new Connection();
$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

$factor=new factor();

define('temprory_factor','db_temprory_factor');

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }

    $factor_product_count=$factor->product_count_factor(temprory_factor,$code);
}

?>
<title> ویرایش اطلاعات کاربری </title>
<?php include ("header.php") ; ?>




<!--CONTENT START-->
        <div class="row content"><!-- the content(middle) of page(blog,sidebar & ...) -->
			<div class="content_register">
                <div class="content_register_content">
                	<div class="content_register_content_top">
                    	<i class="fa fa-user-plus"></i>
                        <p> ویرایش اطلاعات کاربری </p>
                    </div>
                    <div class="content_register_content_content">
                    	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 content_register_content_content_right pull-right">
                            <div class="result_t" style="display: block; width:100%;">
                            </div>
                            <label> نام  :</label>
      <input type="text" class="form-control content_input" value="<?php echo @$_SESSION['user_site_name'] ?>" placeholder="NAME" aria-describedby="basic-addon1" id="name">
      						<label> نام خانوادگی :</label>
      <input type="text" class="form-control content_input" value="<?php echo @$_SESSION['user_site_family'] ?>" placeholder="FAMILY" aria-describedby="basic-addon1" id="family">
                            <label> آدرس الکترونیکی :</label>
                            <input type="text" class="form-control content_input" value="<?php echo @$_SESSION['user_site_email'] ?>" placeholder="EMAIL" aria-describedby="basic-addon1" id="email">
                            <p1 id="email_result" style="display: none">متاسفانه نام کاربری زیر رزرو شده است</p1>
                            <label> شماره تلفن همراه :</label>
                            <input type="text" class="form-control content_input" value="<?php echo @$_SESSION['user_site_mobile'] ?>" placeholder="MOBILE" aria-describedby="basic-addon1" id="mobile">
                            <p1 id="mobile_result" style="display: none">متاسفانه نام کاربری زیر رزرو شده است</p1>
                            <label> شماره تلفن ثابت :</label>
                            <input type="text" value="<?php echo @$_SESSION['user_site_tell'] ?>" class="form-control content_input" placeholder="tell" aria-describedby="basic-addon1" id="tell">
                            <label> کد پستی :</label>
                            <input type="text" value="<?php echo @$_SESSION['user_site_codeposti'] ?>" class="form-control content_input" placeholder="codepost" aria-describedby="basic-addon1" id="code_posti">
                            <p1 id="code_posti_result" style="display: none">متاسفانه نام کاربری زیر رزرو شده است</p1>
                            <label> آدرس :</label>
                            <?php
                            ?>
                            <textarea class="content_textarea" id="address"><?php echo @$_SESSION['user_site_address'] ?></textarea>




  <button type="button" id="edit" class="btn btn-default content_button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    ویرایش اطلاعات
  </button>
                        </div>
                        <div class="col-lg-6 col-md-6 content_register_content_content_left pull-left hidden-xs hidden-sm">
                        	<ul>
                                <li><i class="fa fa-check"></i> هنگام واردن نام ، صفحه کلید در حالت fa باشد </li>
                                <li><i class="fa fa-check"></i> هنگام واردن نام خانوادگی ، صفحه کلید در حالت fa باشد </li>
                                <li><i class="fa fa-check"></i> کد ملی باید شامل 10 عدد باشد </li>
                                <li><i class="fa fa-check"></i> آدرس و کد پستی خود را دقیق وارد کنید </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!--CONTENT END-->




<?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>
<script src="Ajax/Send/Site/user_register/user_register.js"></script>

</body>
</html>