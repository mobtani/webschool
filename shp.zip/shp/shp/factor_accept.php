<?php

define('temprory_factor','db_temprory_factor');
define('post_table','db_post');
define('setting','db_setting_admin');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('Classes/Factor/factor.php');
include('INCLUDE/functions.php');
$upload=new upload();
$factor=new factor();

$user=new user();
$category=new category();
$post=new post();
$setting=new setting();

$connect=new Connection();


if(!(isset($_SESSION['temprory_factor_code'])))
header("location:blog.php");
if(!(isset($_SESSION['user_site_logged'])))
    header("location:login.php");

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }

}
$factor_result=$factor->showData(temprory_factor,$code,$_SESSION['user_site_customer_code']);
@$takhfif_admin=$setting->fetch_takhfif(setting);


if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }

    $factor_product_count=$factor->product_count_factor(temprory_factor,$code);
}


$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=0">
<title> فاکتور خرید </title>
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap-rtl.css">
<link rel="stylesheet" type="text/css" href="Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="Style/Main/index.css">
<link rel="stylesheet" type="text/css" href="Style/list_product/styles.css">
<!--jquery ui css-->
<link rel="stylesheet" type="text/css" href="Script/jquery-ui-1.11.4/jquery-ui.css">
    <style>
        .td_count{
            text-align: center;
        }
    </style>
    <style>
        .alert_user_register_state{
            float: right;
            width: 97%;
            height:auto;
            padding:8px 10px;
            margin: 10px 30px 0px 0px;
            background-color: #e1ff6d;
            border-radius: 4px;
            box-shadow: 0px 0px 3px #b8ff7b;
            text-align: right;
            font: 13px khat;
            clear: both;
        }
        .alert_user_register_state i{
            float: right;
            margin: 2px 0px 0px 4px;

        }
        #info tbody tr td{
            text-align: center;
            background-color: #e1ff6d
        }
        #info_tayed{
            font-size: 13px;
            margin: 0px 0px 10px 0px;
            text-shadow: 0px 0px 3px  #b8ff7b;
        }
    </style>

</head>
<body>
<?php include ("header.php") ; ?>




        <!--CONTENT START-->
        <div class="row"><!-- the content(middle) of page(blog,sidebar & ...) -->
        	<div class="content_factor">
				<div class="content_factor_top">
                	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 right">
                    <i class="fa fa-caret-left"></i>
					<p> سبد خرید شما در دیجی‌کالا </p>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 left">
                    	  <button type="button" class="btn btn-default" id="final_click4"> خرید خود را نهایی کنید </button>
                    </div>
                </div>
                <div class="content_factor_table">
                    <p id="info_tayed"> لطفا اطلاعات خود را بررسی فرمایید و بعد خرید خود را نهایی کنید </p>
                    <table class="table table-bordered" id="info">
                        <thead>
                        <tr>
                            <td> نام و نام خانوادگی </td>
                            <td> کد پستی  </td>
                            <td> آدرس </td>
                            <td> شماره موبایل  </td>
                        </tr>
                        </thead>
                        <tbody>
                             <tr>
                            	<td class="td_description">
                                    <?php echo @$_SESSION['user_site_name'].$_SESSION['user_site_family']; ?>
                                </td>
                                <td class="td_count">
                                    <?php echo @$_SESSION['user_site_codeposti'] ?>
                                 </td>
                                <td class="td_price"> <?php echo @$_SESSION['user_site_address'] ?> </td>
                                <td class="td_allprice"><?php echo @$_SESSION['user_site_mobile'] ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <table class="table table-bordered">
                    	<thead>
                        	<tr>
                            	<td> شرح محصولات </td>
                                <td> تعداد </td>
                                <td> قیمت واحد </td>
                                <td class="last_td1"> قیمت کل  </td>
                                <td class="last_td2"> </td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $gheymat_kol=0;
                        foreach ($factor_result as $fac) {

                            $product_result=$factor->showData_post_in_factor(post_table,$fac['db_temprory_factor_product_code']);

                            //gheymat vahed
                            $gheymat_1=$product_result['db_post_gheymat'];
                            $takhfif=round($product_result['db_post_gheymat'] * ($product_result['db_post_takhfif'] /100));
                            $gheymat_2=$gheymat_1 - $takhfif;

                            //gheymat kole mahsol teda*gheymat
                                $gheymat_3=$gheymat_2*$fac['db_temprory_factor_product_count'];

                            //gheymat kole factor
                            $gheymat_kol= $gheymat_kol + $gheymat_3 ;
                            echo '
                             <tr>
                            	<td class="td_description"> 
                                <div class="img_height">
                                <img src="Ajax/Save/images/'.$product_result['db_post_image'].'" class="img-thumbnail"> 
                                </div>
                                <p_title_persian> '.$product_result['db_post_name_fa'].'  </p_title_persian>
                                <p_title_english> '.$product_result['db_post_name_en'].' </p_title_english>
                                <p_title_garanti> گارانتی :'.$fac['db_temprory_factor_product_garanti'].'  </p_title_garanti>
                                <p_title_garanti>  رنگ :'.$fac['db_temprory_factor_product_color'].' </p_title_garanti>
                                </td>
                                <td class="td_count"> 
                                    '.$fac['db_temprory_factor_product_count'].'
                                 </td>
                                <td class="td_price"> <p_title_price1> '.number_format($gheymat_2).' ریال </p_title_price1> </td>
                                <td class="td_allprice"> <p_title_price1> '.number_format($gheymat_3).' ریال </p_title_price1></td>
                                <td class="last_td"> 
                                </td>
                            </tr>

                        ';
                        }

                        $gheymat_kol1= round($gheymat_kol * ($takhfif_admin / 100));
                        $gheymat_kol_final=$gheymat_kol - $gheymat_kol1;
                        $_SESSION['$gheymat_kol_final']=$gheymat_kol_final;
                        ?>
                        </tbody>
                    </table> 
                </div>
                <div class="content_factor_pricebox">
                	<div class="col-lg-6 col-md-6 col-xs-12  price_all pull-left">
                    	<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 right pull-right"><p>جمع کل خرید شما :</p></div>
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 left pull-left"> <p> <?php echo number_format($gheymat_kol)." ریال" ?>   </p> </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-xs-12 price_takhfif pull-left">
                    	<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 right pull-right"> <p>جمع کل خرید شما با تخفیف:</p> </div>
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 left pull-left"> <p>  <?php echo number_format($gheymat_kol_final)." ریال" ?>  </p>  </div>
                    </div>
                </div>
                <div class="content_factor_bottom">
                	<button type="button" class="btn btn-default pull-left" id="final_click3"> خرید خود را نهایی کنید </button>
                    <button type="button" class="btn btn-default pull-right" id="final_click3"> خرید خود را نهایی کنید </button>
                </div>
            </div>
        </div>
    <!--CONTENT END-->




        <?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>


<!--jquery ui js-->
<script src="Script/jquery-ui-1.11.4/jquery-ui.js"></script>
<script src="Script/Main/jquery_function.js"></script>
<script src="Ajax/Send/Site/factor/factor.js"></script>

</body>
</html>