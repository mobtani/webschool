<?php

define('temprory_factor','db_temprory_factor');
define('post_table','db_post');
define('setting','db_setting_admin');
define('final_factor','db_final_factor');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('Classes/Factor/factor.php');
include('INCLUDE/functions.php');
$upload=new upload();
$factor=new factor();

$user=new user();
$category=new category();
$post=new post();
$setting=new setting();

$connect=new Connection();

$upload=new upload();
$user=new user();
$category=new category();
$post=new post();
$setting=new setting();
$connect=new Connection();
$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code1=$_SESSION['temprory_factor_code'];
    }else{
        $code1=$_COOKIE['factor'];
    }

    $factor_product_count=$factor->product_count_factor(temprory_factor,$code1);
}


/*if(!(isset($_SESSION['final_factor_code'])))
header("location:blog.php");
if(!(isset($_SESSION['user_site_logged'])))
    header("location:login.php");
*/
        $code=@$_GET['code'];

$factor_result=$factor->showData(temprory_factor,$_GET['code'],$_GET['user']);
@$takhfif_admin=$setting->fetch_takhfif(setting);

$factor_result_user=$factor->showData_factor_in_code(final_factor,$code);

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=0">
<title> فاکتور خرید </title>
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap-rtl.css">
<link rel="stylesheet" type="text/css" href="Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="Style/Main/index.css">
<link rel="stylesheet" type="text/css" href="Style/list_product/styles.css">
<!--jquery ui css-->
<link rel="stylesheet" type="text/css" href="Script/jquery-ui-1.11.4/jquery-ui.css">
    <style>
        .td_count{
            text-align: center;
        }
    </style>
    <style>
        .alert_user_register_state{
            float: right;
            width: 97%;
            height:auto;
            padding:8px 10px;
            margin: 10px 30px 0px 0px;
            background-color: #e1ff6d;
            border-radius: 4px;
            box-shadow: 0px 0px 3px #b8ff7b;
            text-align: right;
            font: 13px khat;
            clear: both;
        }
        .alert_user_register_state i{
            float: right;
            margin: 2px 0px 0px 4px;

        }
        #info tbody tr td{
            text-align: center;
            background-color: #e1ff6d
        }
        #info_tayed{
            font-size: 13px;
            margin: 0px 0px 10px 0px;
            text-shadow: 0px 0px 3px  #b8ff7b;
        }
    </style>

</head>
<body>
<div class="container">
    <div class="row"><!-- the main row for all page-->
        <!--HEADER START-->
        <div class="row "><!-- the top(header) of page(menu,logo,search & ...) -->
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 top_left pull-left">
                <img src="Image/digikala-logo-slogan.png">
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 top_right pull-right">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_top">
                    <ul class="novbar_icon">
                        <li id="novbar_show"><i class="fa fa-bars"></i></li>
                    </ul>
                    <ul class="menu_hidden">
                        <?php
                        if(!(isset($_SESSION['user_site_logged']))) {
                            echo '
                        <a href="login.php" target="_blank"><li><i class="fa fa-key"></i><p> فروشگاه کامپیوتری وارد شوید</p></li></a>
                        <a href="register.php" target="_blank"><li><i class="fa fa-user-plus"></i><p> ثبت نام کنید </p></li></a>
                        ';
                        }
                        else{
                            echo '
                        <li><i class="fa fa-key"></i><p> سلام '.$_SESSION['user_site_name'].' خوش آمدی</p></li>
                        <a href="user_panel.php" target="_blank"><li><p> پنل کاربری </p></li></a>
                        <a href="logout.php"><li><p> خروج </p></li></a>
                        ';
                        }
                        ?>
                        <li class="hidden-lg hidden-md hidden-sm" style="height:50px;">
                            <div class="input-group">
                                <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                                <input type="text" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1">
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_bottom">
                    <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12 top_right_bottom_basket">
                        <a href="factor.php">
                            <div class="top_right_bottom_basket_box">
                                <div class="top_right_bottom_basket_box_right">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                                <div class="top_right_bottom_basket_box_content">
                                    <p> سبد خرید </p>
                                </div>
                                <div class="top_right_bottom_basket_box_left">
                                    <p><?php     echo @$factor_product_count;
                                        ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12 top_right_bottom_search hidden-xs">
                        <div class="input-group" style="margin-top:10px; height:42px;">
                            <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                            <form action="blog.php" method="get">
                                <input type="text" name="search" style=" height:42px;" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1"></form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_bottom pull-right ">
                <ul class="novbar_icon_bottommenu hidden-lg hidden-md">
                    <li id="novbar_bottommenu_show"><i class="fa fa-bars"></i></li>
                </ul>
                <ul class="level1">
                    <?php
                    $rows = $category->showData("db_menu");
                    $items = $rows;
                    $id = '';
                    $i=1;
                    foreach($items as $item){
                        if($item['menu_parent_id'] == 0){
                            echo "<a href='blog.php?catname=".$item['menu_name']."'><li><i class='fa fa-arrow-circle-o-down'></i>".$item['menu_name']."" ?>

                            <?php
                            $id = $item['menu_id'];
                            sub1($items, $id,($i+1));

                            echo '
							</li></a>';
                        }
                    }
                    ?>
                    <?php
                    function sub1($items, $id,$j){
                        echo'<ul class="level'.$j.'">';
                        foreach($items as $item){
                            if($item['menu_parent_id'] == $id){
                                echo"<a href='blog.php?catname=".$item['menu_name']."'><li><i class='fa fa-angle-left'></i>".$item['menu_name']."" ?>
                                <?php
                                sub1($items, $item['menu_id'],$j+1);
                                echo '
								</li></a>';
                            }
                        }
                        echo '</ul>';
                    }
                    ?>

                </ul>
            </div>
        </div>
        <!--HEADER END-->


        

        <!--CONTENT START-->
        <div class="row"><!-- the content(middle) of page(blog,sidebar & ...) -->
        	<div class="content_factor">
				<div class="content_factor_top">
                	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 right">
                    <i class="fa fa-caret-left"></i>
					<p> فاکتور خرید شما با شماره فاکتور <?php echo @$_GET['code']; ?> در سایت </p>
                    </div>
                </div>
                <div class="content_factor_table">
                    <p id="info_tayed"> محصولات به ادرس پستی ثبت شده ارسال خواهد شد </p>
                    <table class="table table-bordered" id="info">
                        <thead>
                        <tr>
                            <td> مبلغ پرداختی  </td>
                            <td> شماره فاکتور  </td>
                            <td> وضعیت ارسال  </td>
                        </tr>
                        </thead>
                        <tbody>
                             <tr>
                            	<td class="td_description">
                                    <?php echo number_format($factor_result_user['db_final_factor_price']); ?> ریال
                                </td>
                                <td class="td_count">
                                    <?php echo $factor_result_user['db_final_factor_code'] ?>
                                 </td>
                                <td class="td_price"> <?php
                                    if($factor_result_user["db_final_factor_state"]==0){
                                        echo 'در حال بررسی';
                                    }else if($factor_result_user["db_final_factor_state"]==1){
                                        echo 'ارسال شده';
                                    }else{
                                        echo 'معلق';
                                    }
                                    ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <table class="table table-bordered">
                    	<thead>
                        	<tr>
                            	<td> شرح محصولات </td>
                                <td> تعداد </td>
                                <td> قیمت واحد </td>
                                <td class="last_td1"> قیمت کل  </td>
                                <td class="last_td2"> </td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $gheymat_kol=0;
                        foreach ($factor_result as $fac) {

                            $product_result=$factor->showData_post_in_factor(post_table,$fac['db_temprory_factor_product_code']);

                            //gheymat vahed
                            $gheymat_1=$product_result['db_post_gheymat'];
                            $takhfif=round($product_result['db_post_gheymat'] * ($product_result['db_post_takhfif'] /100));
                            $gheymat_2=$gheymat_1 - $takhfif;

                            //gheymat kole mahsol teda*gheymat
                                $gheymat_3=$gheymat_2*$fac['db_temprory_factor_product_count'];

                            //gheymat kole factor
                            $gheymat_kol= $gheymat_kol + $gheymat_3 ;
                            echo '
                             <tr>
                            	<td class="td_description"> 
                                <div class="img_height">
                                <img src="Ajax/Save/images/'.$product_result['db_post_image'].'" class="img-thumbnail"> 
                                </div>
                                <p_title_persian> '.$product_result['db_post_name_fa'].'  </p_title_persian>
                                <p_title_english> '.$product_result['db_post_name_en'].' </p_title_english>
                                <p_title_garanti> گارانتی :'.$fac['db_temprory_factor_product_garanti'].'  </p_title_garanti>
                                <p_title_garanti>  رنگ :'.$fac['db_temprory_factor_product_color'].' </p_title_garanti>
                                </td>
                                <td class="td_count"> 
                                    '.$fac['db_temprory_factor_product_count'].'
                                 </td>
                                <td class="td_price"> <p_title_price1> '.number_format($gheymat_2).' ریال </p_title_price1> </td>
                                <td class="td_allprice"> <p_title_price1> '.number_format($gheymat_3).' ریال </p_title_price1></td>
                                <td class="last_td"> 
                                </td>
                            </tr>

                        ';
                        }

                        $gheymat_kol1= round($gheymat_kol * ($takhfif_admin / 100));
                        $gheymat_kol_final=$gheymat_kol - $gheymat_kol1;
                        ?>
                        </tbody>
                    </table> 
                </div>
                <div class="content_factor_pricebox">
                	<div class="col-lg-6 col-md-6 col-xs-12  price_all pull-left">
                    	<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 right pull-right"><p>جمع کل خرید شما :</p></div>
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 left pull-left"> <p> <?php echo number_format($gheymat_kol)." ریال" ?>   </p> </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-xs-12 price_takhfif pull-left">
                    	<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 right pull-right"> <p>جمع کل خرید شما با تخفیف:</p> </div>
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 left pull-left"> <p>  <?php echo number_format($gheymat_kol_final)." ریال" ?>  </p>  </div>
                    </div>
                </div>
            </div>
        </div>
    <!--CONTENT END-->




        <?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>


<!--jquery ui js-->
<script src="Script/jquery-ui-1.11.4/jquery-ui.js"></script>
<script src="Script/Main/jquery_function.js"></script>
<script src="Ajax/Send/Site/factor/factor.js"></script>

</body>
</html>