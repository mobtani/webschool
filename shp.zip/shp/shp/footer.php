<!--FOOTER START-->
<div class="row"><!-- the bottom(footer) of page(copyright,menue & ...) -->
    <div class="footer_colors" style="
    width: 100%;
    position: relative;
    background: #2b2b2b;
    color: #fff;
    height: 50px;
    line-height: 50px;
    box-shadow: 0 0 5px #d7d7d7;
    float: right;">
    <div class="container floating-container">
        <p style="    width: 30%;
    float: right;" >
            روزتو مثبت تیک
            <span>✓</span>
            بزن
        </p>
        <a class="tel" style="    float: left;
    font-weight: normal;
    direction: ltr;
    margin-right: 30px;
    color: white;">
            <img src="Image/icons/tel32.png">
            09211349353
        </a>
        <a style="    float: left;
    font-weight: normal;
    direction: ltr;
    margin-right: 30px;
    color: white;" href="mailto:h.r.samani.1379@gmail.com" class="email">
            <img src="Image/icons/mail32.png">
            h.r.samani.1379@gmail.com
        </a>
    </div>
    </div>
		<div style="    background: #0C0C0C url(Image/footer.jpg) no-repeat center center;
    background-size: 100% auto;
    color: #d7d7d7;
    padding: 0px 0 6px 0;
    height: 7vw;
    width: 100%;
    margin-top: 3.5%;
    position: relative;
    max-height: 426px;">
    <div class="footer_top" style="background:#64687100">
        <div class="col-lg-8 col-md-8 footer_top_right pull-right hidden-xs hidden-sm">
            <ul>
                <a href="/" ><li> صفحه اصلی </li></a>
                <a href="login.php" ><li> ورود به حساب کاربری </li></>
                <a href="contactus.php" ><li> تماس با ما  </li></a>
            </ul>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 footer_top_left pull-left">
            <ul>
                <li><a href="<?php echo $facebook; ?>"> <img src="Image/facebook.png"> </a></li>
                <li><a href="<?php echo $twitter; ?>"><img src="Image/twitter.png"> </a></li>
                <li><a href="<?php echo $skype; ?>"><img src="Image/skype.png"> </a></li>
            </ul>
        </div>
    </div>
    <div class="footer_bottom" style="background:#64687100">
        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 footer_bottom_right pull-right">
            <p><?php echo $copyright_fa; ?></p>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 footer_bottom_left pull-left">
            <p><?php echo $copyright_en; ?></p>
        </div>
    </div>

	</div>
	</div>
<!--FOOTER END-->
</div>
</div>
