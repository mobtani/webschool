<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=0">
    <link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap-rtl.css">
    <link rel="stylesheet" type="text/css" href="Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="Style/Main/index.css">
    <link rel="stylesheet" type="text/css" href="Style/list_product/styles.css">
    <!--jquery ui css-->
    <link rel="stylesheet" type="text/css" href="Script/jquery-ui-1.11.4/jquery-ui.css">
</head>
<body>
<div class="container">
    <div class="row"><!-- the main row for all page-->
        <!--HEADER START-->
        <div class="row "><!-- the top(header) of page(menu,logo,search & ...) -->
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 top_left pull-left">
                <a href="/"><img src="Ajax/Save/logo/<?php echo $logo; ?>"></a>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 top_right pull-right">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_top">
                    <ul class="novbar_icon">
                        <li id="novbar_show"><i class="fa fa-bars"></i></li>
                    </ul>
                    <ul class="menu_hidden">
                        <?php
                        if(!(isset($_SESSION['user_site_logged']))) {
                            echo '
                        <a href="login.php" target="_blank"><li><i class="fa fa-key"></i><p> فروشگاه کامپیوتر وارد شوید</p></li></a>
                        <a href="register.php" target="_blank"><li><i class="fa fa-user-plus"></i><p> ثبت نام کنید </p></li></a>
                        ';
                        }
                        else{
                            echo '
                        <li><i class="fa fa-key"></i><p> سلام '.$_SESSION['user_site_name'].' خوش آمدی</p></li>
                        <a href="user_panel.php" target="_blank"><li><p> پنل کاربری </p></li></a>
                        <a href="logout.php"><li><p> خروج </p></li></a>
                        ';
                        }
                        ?>
                        <li class="hidden-lg hidden-md hidden-sm" style="height:50px;">
                            <div class="input-group">
                                <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
 <input type="text" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1">
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_bottom">
                    <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12 top_right_bottom_basket">
                        <a href="factor.php">
                        <div class="top_right_bottom_basket_box">
                            <div class="top_right_bottom_basket_box_right">
                                <i class="fa fa-shopping-cart"></i>
                            </div>
                            <div class="top_right_bottom_basket_box_content">
                                <p> سبد خرید </p>
                            </div>
                            <div class="top_right_bottom_basket_box_left">
                                <p><?php     echo @$factor_product_count;
                                    ?></p>
                            </div>
                        </div>
                        </a>
                    </div>
                    <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12 top_right_bottom_search hidden-xs">
                        <div class="input-group" style="margin-top:10px; height:42px;">
                            <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                            <form action="blog.php" method="get">
                                <input type="text" name="search" style=" height:42px;" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1"></form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_bottom pull-right ">
                <ul class="novbar_icon_bottommenu hidden-lg hidden-md">
                    <li id="novbar_bottommenu_show"><i class="fa fa-bars"></i></li>
                </ul>
                <ul class="level1">
                    <?php
                    $rows = $category->showData("db_menu");
                    $items = $rows;
                    $id = '';
                    $i=1;
                    foreach($items as $item){
                        if($item['menu_parent_id'] == 0){
                            echo "<a href='blog.php?catname=".$item['menu_name']."'><li><i class='fa fa-arrow-circle-o-down'></i>".$item['menu_name']."" ?>

                            <?php
                            $id = $item['menu_id'];
                            sub1($items, $id,($i+1));

                            echo '
							</li></a>';
                        }
                    }
                    ?>
                    <?php
                    function sub1($items, $id,$j){
                        echo'<ul class="level'.$j.'">';
                        foreach($items as $item){
                            if($item['menu_parent_id'] == $id){
                                echo"<a href='blog.php?catname=".$item['menu_name']."'><li><i class='fa fa-angle-left'></i>".$item['menu_name']."" ?>
                                <?php
                                sub1($items, $item['menu_id'],$j+1);
                                echo '
								</li></a>';
                            }
                        }
                        echo '</ul>';
                    }
                    ?>

                </ul>
            </div>
        </div>
        <!--HEADER END-->
