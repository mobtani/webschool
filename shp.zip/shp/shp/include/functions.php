<?php
	include ("jdf.php");
	function get_date($title,$separate)
	{
		$day_number = jdate('j');
		$month_number = jdate('F');
		$year_number = jdate('Y');
		$day_name = jdate('l');
		$date=$title.' : '.$day_number.$separate.$month_number.$separate.$year_number;
		return $date;
	}
?>