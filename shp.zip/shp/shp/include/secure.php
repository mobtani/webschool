<?php
function check_input($s)
{
	$s=stripslashes($s);

	$s=escapeshellcmd($s);

	$s=htmlspecialchars($s);

	$s=addslashes($s);

	$s=htmlspecialchars($s); 

	$s=strip_tags($s);

	$s=str_replace("'","''",$s);

	$s = str_replace(array("\n", "'", "‘", "’", "'", "“", "”", "„", "?", '"'), array("", "\’", "\’", "\’", "\’", "\"", "\"", "\"", "\"", "\""), $s);
return $s;
}
?>