<?php
define('post_table','db_post');
define('setting','db_setting_admin');
define('site_slider','db_slider');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('INCLUDE/functions.php');

$upload=new upload();

$user=new user();
$category=new category();
$post=new post();
$setting=new setting();

$connect=new Connection();


$value=$setting->fetch_count_image_site_slider(setting);
if($value)
{
	echo $value;
}

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no"><title>صفحه اصلی</title>
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap-rtl.css">
<link rel="stylesheet" type="text/css" href="Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="Style/Main/index.css">
<link rel="stylesheet" type="text/css" href="Style/list_product/styles.css">
</head>
<body>
<div class="container">
	<div class="row"><!-- the main row for all page-->
    
    <!--HEADER START-->
    	<div class="row "><!-- the top(header) of page(menu,logo,search & ...) -->
        	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 top_left pull-left">
            	<img src="Image/digikala-logo-slogan.png">
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 top_right pull-right">
            	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_top">
                	<ul class="novbar_icon">
                    	<li id="novbar_show"><i class="fa fa-bars"></i></li>
                    </ul>
                	<ul class="menu_hidden">
                    	<li><i class="fa fa-key"></i><p> فروشگاه دیجی کالا ، وارد شوید</p></li>
                        <li><i class="fa fa-user-plus"></i><p> ثبت نام کنید </p></li>
                        <li class="hidden-lg hidden-md hidden-sm" style="height:50px;">
                        	<div class="input-group">
                            <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                            <input type="text" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1">
                            </div>
						</li>
                    </ul>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_bottom">
                	<div class="col-lg-4 col-md-5 col-sm-5 col-xs-12 top_right_bottom_basket">
                    	<div class="top_right_bottom_basket_box">
                        	<div class="top_right_bottom_basket_box_right">
                            	<i class="fa fa-shopping-cart"></i>
                            </div>
                            <div class="top_right_bottom_basket_box_content">
                            	<p> سبد خرید </p>
                            </div>
                            <div class="top_right_bottom_basket_box_left">
                            	<p>10</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12 top_right_bottom_search hidden-xs">
                    	<div class="input-group" style="margin-top:10px; height:42px;">
                            <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                            <input type="text" style=" height:42px;" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1">
                            </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_bottom pull-right ">
            	<ul class="novbar_icon_bottommenu hidden-lg hidden-md">
                	<li id="novbar_bottommenu_show"><i class="fa fa-bars"></i></li>
                </ul>
            	<ul class="level1">
                    <?php
                    $rows = $category->showData("db_menu");
                    $items = $rows;
                    $id = '';
                    $i=1;
                    foreach($items as $item){
                        if($item['menu_parent_id'] == 0){
                            echo "<li><i class='fa fa-arrow-circle-o-down'></i>".$item['menu_name']."" ?>

							<?php
						    $id = $item['menu_id'];
                            sub1($items, $id,($i+1));

							echo '
							</li>';
                        }
                    }
                    ?>
                    <?php
                    function sub1($items, $id,$j){
                        echo'<ul class="level'.$j.'">';
                        foreach($items as $item){
                            if($item['menu_parent_id'] == $id){
                                echo"<li><i class='fa fa-angle-left'></i>".$item['menu_name']."" ?>
                                <?php
							sub1($items, $item['menu_id'],$j+1);
							echo '
								</li>';
                            }
                        }
                        echo '</ul>';
                    }
                    ?>

                </ul>
            </div>
        </div>
    <!--HEADER END--> 
    
    
    
    
    <!--CONTENT START-->
        <div class="row"><!-- the content(middle) of page(blog,sidebar & ...) -->
        	<div class="col-lg-8 col-md-7 col-sm-12 col-xs-12 content_left pull-left">
            	<div class="content_left_slider"><!-- START content_left_slider-->
                   <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                      <!-- Indicators -->
                      <ol class="carousel-indicators">
                      <?php
					  for($c=0;$c<=$value;$c++)
					  {
						  
						  if($c==0)
						  {
							  echo'
				<li data-target="#carousel-example-generic" data-slide-to="'.$c.'" class="active" ></li>
							  ';
						  }
					  echo'
                        <li data-target="#carousel-example-generic" data-slide-to="'.$c.'"></li>
						';
					  }
						?>
                      </ol>
                      <!-- Wrapper for slides -->
                      <div class="carousel-inner" role="listbox">
                     <?php
					 $array=$upload->showData_slider_limited(site_slider,$value);
					 $i=0;
						 foreach ($array as $result) {
							if($i==0)
							{
								echo'
							<div class="item active">
							  <img src="Ajax/Save/logo/'.$result['db_slider_image'].'" alt="...">
							</div>
								';
							}
							else{
							echo'
							<div class="item">
							  <img src="Ajax/Save/logo/'.$result['db_slider_image'].'" alt="...">
							</div>
							';
							}
						$i++;
						 }
						 if($i<$value)
						 {
						echo'
							<div class="item">
							  <img src="Image/HD (97).jpg" alt="...">
							</div>
							';
 
						 }
						?>
                      </div>
                      <!-- Controls -->
                      <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                        <span class="fa fa-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                      </a>
                      <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                        <span class="fa fa-chevron-right"></span>
                        <span class="sr-only">Next</span>
                      </a>
                    </div>
                </div><!-- END content_left_slider-->
                <div class="content_left_shortcut_info">
                	<ul>
                    	<li><img src="Image/ico-usp-1.png"><p> 7 روز ضمانت برگشت </p></li>
                        <li><img src="Image/ico-usp-2.png"><p> پرداخت در محل  </p></li>
                        <li><img src="Image/ico-usp-3.png"><p> ضمانت اصل بودن </p></li>
                        <li><img src="Image/ico-usp-4.png"><p> تحویل اکسپرس  </p></li>
                        <li><img src="Image/ico-usp-5.png"><p> تضمین بهترین قیمت </p></li>
                    </ul>
                </div>
                <div class="content_left_listproduct">
                	<div class="content_left_listproduct_top">
                    	<h4> + لیست کامل  </h4>
                        <h3> محبوب ترین کالاها  </h3>
                    </div>
           <div class="wrap">
            <div class="chain-box" id="chain-box-2">
              <ul class="chain">
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="Image/HD (96).jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">Golden Monkey1</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-3-col.php"><img src="image/Mobile-Samsung-Galaxy-Star-Plus-S7262-Dual-SIM3eccab.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-3-col.php" class="title">Freelance Switch2</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-1-col.php"><img src="image/Computer-HDD-Silicon-Armor-A80-1TB030b68.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-1-col.php" class="title">App Storm3</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Computer-HDD-WD-Elements-Portable-1TBa1558e.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">Freelance Switch4</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-3-col.php"><img src="image/Computer-Net-D-Link-DSL-2750U-New9210c5.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-3-col.php" class="title">Golden Monkey5</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Computer-Net-D-Link-DSL-2740U-ADSL2-Plus-Modem-with-Wireless.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">App Storm6</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-1-col.php"><img src="image/Computer-External-HDD-Western-Digital-My-Passport-Ultra-Prem.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-1-col.php" class="title">Golden Monkey7</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Mobile-Samsung-Galaxy-Star-Plus-S7262-Dual-SIM3eccab.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">Golden Monkey8</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-3-col.php"><img src="image/Mobile-Samsung-Galaxy-S3-I9300I-Dual-SIM0102e8.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-3-col.php" class="title">Freelance Switch9</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-1-col.php"><img src="image/Mobile-LG-L70-Dual-D325d3ffd2.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-1-col.php" class="title">Golden Monkey10</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Notebook-Lenovo-E5080-A04c9ac.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">App Storm11</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Music-Instrument-Accessories-Keyboard-Bench-Roway-BH-404-bk1.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">Golden Monkey12</a> 
                  <!--title--></li>
              </ul>
              <a href="#" class="arrow3-left"></a><!--arrow3-left--> 
              <a href="#" class="arrow3-right"></a><!--arrow3-right--> 
            </div>
            <!--chain-box--> 
          </div>
       </div>
                       <div class="content_left_listproduct">
                	<div class="content_left_listproduct_top">
                    	<h4> + لیست کامل  </h4>
                        <h3> پرفروش  ترین کالاها  </h3>
                    </div>
          <div class="wrap1">
            <div class="chain-box1s" id="chain-box-21s">
              <ul class="chain1s">
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Phone-Panasonic-KX-TG3611BXf66ccc.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">Golden Monkey1</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-3-col.php"><img src="image/Mobile-Samsung-Galaxy-Star-Plus-S7262-Dual-SIM3eccab.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-3-col.php" class="title">Freelance Switch2</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-1-col.php"><img src="image/Computer-HDD-Silicon-Armor-A80-1TB030b68.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-1-col.php" class="title">App Storm3</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Computer-HDD-WD-Elements-Portable-1TBa1558e.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">Freelance Switch4</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-3-col.php"><img src="image/Computer-Net-D-Link-DSL-2750U-New9210c5.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-3-col.php" class="title">Golden Monkey5</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Computer-Net-D-Link-DSL-2740U-ADSL2-Plus-Modem-with-Wireless.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">App Storm6</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-1-col.php"><img src="image/Computer-External-HDD-Western-Digital-My-Passport-Ultra-Prem.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-1-col.php" class="title">Golden Monkey7</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Mobile-Samsung-Galaxy-Star-Plus-S7262-Dual-SIM3eccab.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">Golden Monkey8</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-3-col.php"><img src="image/Mobile-Samsung-Galaxy-S3-I9300I-Dual-SIM0102e8.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-3-col.php" class="title">Freelance Switch9</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-1-col.php"><img src="image/Mobile-LG-L70-Dual-D325d3ffd2.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-1-col.php" class="title">Golden Monkey10</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Notebook-Lenovo-E5080-A04c9ac.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">App Storm11</a> 
                  <!--title--></li>
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="image/Music-Instrument-Accessories-Keyboard-Bench-Roway-BH-404-bk1.jpg" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">Golden Monkey12</a> 
                  <!--title--></li>
              </ul>
              <a href="#" class="arrow3-left1s"></a><!--arrow3-left--> 
              <a href="#" class="arrow3-right1s"></a><!--arrow3-right--> 
            </div>
            <!--chain-box--> 
          </div>
        </div>
		                       <div class="content_left_listproduct">
                	<div class="content_left_listproduct_top">
                    	<h4> + لیست کامل  </h4>
                        <h3> جدید ترین کالاها  </h3>
                    </div>
          <div class="wrap2">
            <div class="chain-box2s" id="chain-box-22s">
              <ul class="chain2s">
              <?php
                                        $array=$post->showData_post_new(post_table);
                                    $i=0;
                                    if($array) {
                                        foreach ($array as $result1) {
                                            $i++;
                                            echo '
                <li>
                  <div class="image"><a href="portfolio-2-col.php"><img src="Ajax/Save/images/'.$result1['db_post_image'].'" alt="" /></a></div>
                  <!--image--> 
                  <a href="portfolio-2-col.php" class="title">'.substr($result1['db_post_name_fa'],0,35).'</a> 
                  <!--title--></li>';
							}
								}
										?>
              </ul>
              <a href="#" class="arrow3-left2s"></a><!--arrow3-left--> 
              <a href="#" class="arrow3-right2s"></a><!--arrow3-right--> 
            </div>
            <!--chain-box--> 
          </div>
        </div>

            </div>
            <div class="col-lg-3 col-md-4 col-sm-10 col-xs-12 col-sm-offset-1 content_right pull-right">
            	<div class=" col-lg-12 content_right_sidebar">
                	<div class="content_right_sidebar_top">
                    	<h3> جدید ترین محصولات </h3>
                    </div>
                    <div class="content_right_sidebar_content">
                    	<ul>
                        <?php
                                        $array=$post->showData_post_new(post_table);
                                    $i=0;
                                    if($array) {
                                        foreach ($array as $result1) {
                                            $i++;
                                            echo '
                        	<li>
                            	<div class="right">
                                	<img src="Ajax/Save/images/'.$result1['db_post_image'].'">
                                </div>
                                <div class="left">
									<p>'.substr($result1['db_post_name_fa'],0,75).'  ...</p>
                                    <p1>‌ '.$result1['db_post_date'].'</p1>
                                </div>
                            </li>
							';
										}
									}
							?>
                        </ul>
                    </div>
                    <div class="content_right_sidebar_bottom">
                    	<a>+ مشاهده محصولات بیشتر  </a>
                    </div>
                </div>
                <div class="content_right_shortcut_link">
                	<img src="Image/869b569b-310d-4268-9cc0-a9052b961a0a.jpg">
                </div>
                <div class="content_right_shortcut_link">
                	<img src="Image/bb693031-a89b-4190-8d2e-980ae16a2860.jpg">
                </div>
                <div class=" col-lg-12 content_right_sidebar">
                	<div class="content_right_sidebar_top">
                    	<h3> جدید ترین محصولات </h3>
                    </div>
                    <div class="content_right_sidebar_content">
                    	<ul>
                        	<li>
                            	<div class="right">
                                	<img src="Image/HD (96).jpg">
                                </div>
                                <div class="left">
									<p>قصه‌ی مردی که هیچ‌وقت فراموش نمی‌کند</p>
                                    <p1>‌ چهارشنبه 14 بهمن 1394</p1>
                                </div>
                            </li>
                            <li>
                            	<div class="right">
                                	<img src="Image/HD (97).jpg">
                                </div>
                                <div class="left">
									<p>قصه‌ی مردی که هیچ‌وقت فراموش نمی‌کند</p>
                                    <p1>‌ چهارشنبه 14 بهمن 1394</p1>
                                </div>
                            </li>
                            <li>
                            	<div class="right">
                                	<img src="Image/HD (90).jpg">
                                </div>
                                <div class="left">
									<p>قصه‌ی مردی که هیچ‌وقت فراموش نمی‌کند</p>
                                    <p1>‌ چهارشنبه 14 بهمن 1394</p1>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="content_right_sidebar_bottom">
                    	<a>+ مشاهده محصولات بیشتر  </a>
                    </div>
                </div>
				<div class="content_right_shortcut_bank_logo">
                	<img src="Image/namad2.png">
                </div>
            </div>
        </div>
    <!--CONTENT END-->   
    
    
    
    
    <!--FOOTER START--> 
        <div class="row"><!-- the bottom(footer) of page(copyright,menue & ...) -->
        	<div class="footer_colors">
            	<div class="color1"></div>
                <div class="color2"></div>
                <div class="color3"></div>
                <div class="color4"></div>
                <div class="color5"></div>
                
            </div>
        	<div class="footer_top">
            	<div class="col-lg-8 col-md-8 footer_top_right pull-right hidden-xs hidden-sm">
                	<ul>
                    	<li> صفحه اصلی </li>
                        <li> ورود به حساب کاربری </li>
                        <li> تماس با ما  </li>
                        <li> درباره ما  </li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 footer_top_left pull-left">
                	<ul>
                    	<li> <img src="Image/facebook.png"> </li>
                        <li> <img src="Image/linkedin.png"> </li>
                        <li> <img src="Image/twitter.png"> </li>
                        <li> <img src="Image/skype.png"> </li>
                        <li> <img src="Image/rss.png"> </li>
                    </ul>
                </div>
            </div>
            <div class="footer_bottom">
            	<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 footer_bottom_right pull-right">
                	<p>استفاده از مطالب سايت دیجی‌کالا فقط برای مقاصد غیر تجاری و با ذکر منبع بلامانع است. کليه حقوق اين سايت متعلق به شرکت نوآوران فن آوازه (فروشگاه آنلاین دیجی‌کالا) می‌باشد.</p>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 footer_bottom_left pull-left">
                	<p>Copyright © 2006 - 2016 Digikala.com</p>
                </div>
            </div>
        </div>
    <!--FOOTER END-->    
    </div>
</div>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>
</body>
</html>