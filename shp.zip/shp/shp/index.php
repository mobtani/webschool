<?php
define('post_table','db_post');
define('setting','db_setting_admin');
define('site_slider','db_slider');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('Classes/Factor/factor.php');
include('INCLUDE/functions.php');


$upload=new upload();
$user=new user();
$category=new category();
$post=new post();
$setting=new setting();
$connect=new Connection();
$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

$factor=new factor();

define('temprory_factor','db_temprory_factor');

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }

    $factor_product_count=$factor->product_count_factor(temprory_factor,$code);
}

?>
<title> صفحه اصلی </title>
<?php include ("header.php") ; ?>
    <!--CONTENT START-->
        <div class="row"><!-- the content(middle) of page(blog,sidebar & ...) -->
        	<div class="col-lg-8 col-md-7 col-sm-12 col-xs-12 content_left pull-left">
            	<div class="content_left_slider"><!-- START content_left_slider-->
                   <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                      <!-- Indicators -->
                      <ol class="carousel-indicators">
                      <?php
					  for($c=0;$c<$value;$c++)
					  {
						  
						  if($c==0)
						  {
							  echo'
				<li data-target="#carousel-example-generic" data-slide-to="'.$c.'" class="active" ></li>
							  ';
						  }
						  else{
					  echo'
                        <li data-target="#carousel-example-generic" data-slide-to="'.$c.'"></li>
						';
						  }
					  }
						?>
                      </ol>
                      <!-- Wrapper for slides -->
                      <div class="carousel-inner" role="listbox">
                     <?php
					 $array=$upload->showData_slider_limited(site_slider,$value);
					 $i=0;
						 foreach ($array as $result) {
							if($i==0)
							{
								echo'
							<div class="item active">
							  <img src="Ajax/Save/slider/'.$result['db_slider_image'].'" alt="...">
							</div>
								';
							}
							else{
							echo'
							<div class="item">
							  <img src="Ajax/Save/slider/'.$result['db_slider_image'].'" alt="...">
							</div>
							';
							}
						$i++;
						 }
						 if($i<$value)
						 {
						echo'
							<div class="item">
							  <img src="Image/HD (97).jpg" alt="...">
							</div>
							';
 
						 }
						?>
                      </div>
                      <!-- Controls -->
                      <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                        <span class="fa fa-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                      </a>
                      <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                        <span class="fa fa-chevron-right"></span>
                        <span class="sr-only">Next</span>
                      </a>
                    </div>
                </div><!-- END content_left_slider-->
                <div class="content_left_shortcut_info">
                	<ul>
                    	<li><img src="Image/ico-usp-1.png"><p> 7 روز ضمانت برگشت </p></li>
                        <li><img src="Image/ico-usp-2.png"><p> پرداخت در محل  </p></li>
                        <li><img src="Image/ico-usp-3.png"><p> ضمانت اصل بودن </p></li>
                        <li><img src="Image/ico-usp-4.png"><p> تحویل اکسپرس  </p></li>
                        <li><img src="Image/ico-usp-5.png"><p> تضمین بهترین قیمت </p></li>
						 <li><img src="Image/ico-usp-1.png"><p> ضمانت اصل بودن کالا </p></li>
                    </ul>
                </div>
                <div class="content_left_listproduct">
                	<div class="content_left_listproduct_top">
                    	<h4> + لیست کامل  </h4>
                        <h3> محبوب ترین کالاها  </h3>
                    </div>
           <div class="wrap">
            <div class="chain-box" id="chain-box-2">
              <ul class="chain">
                            <?php
                                        $array=$post->showData_post_favourite(post_table);
                                    $i=0;
                                    if($array) {
                                        foreach ($array as $result1) {
                                            $i++;
                                            echo '
				                <li>
                  <div class="image"><a href="single.php?id='.$result1['db_post_id'].'&code='.$result1['db_post_code'].'"><img src="Ajax/Save/images/'.$result1['db_post_image'].'" alt="" /></a></div>
                  <!--image--> 
                  <a href="single.php?id='.$result1['db_post_id'].'&code='.$result1['db_post_code'].'" class="title">'.substr($result1['db_post_name_fa'],0,35).'</a> 
</li>';
							}
								}
										?>

              
              </ul>
              <a href="#" class="arrow3-left"></a><!--arrow3-left--> 
              <a href="#" class="arrow3-right"></a><!--arrow3-right--> 
            </div>
            <!--chain-box--> 
          </div>
       </div>
	   		                       <div class="content_left_listproduct">
                	<div class="content_left_listproduct_top">
                    	<h4> + لیست کامل  </h4>
                        <h3> جدید ترین کالاها  </h3>
                    </div>
          <div class="wrap2">
            <div class="chain-box2s" id="chain-box-22s">
              <ul class="chain2s">
              <?php
                                    $array=$post->showData_post_new(post_table);
                                    $i=0;
                                    if($array) {
                                        foreach ($array as $result1) {
                                            $i++;
                                            echo '
                <li>
                  <div class="image"><a href="single.php?id='.$result1['db_post_id'].'&code='.$result1['db_post_code'].'"><img src="Ajax/Save/images/'.$result1['db_post_image'].'" alt="" /></a></div>
                  <!--image--> 
                  <a href="single.php?id='.$result1['db_post_id'].'&code='.$result1['db_post_code'].'" class="title">'.substr($result1['db_post_name_fa'],0,35).'</a> 
                  <!--title--></li>';
							}
								}
										?>
              </ul>
              <a href="#" class="arrow3-left2s"></a><!--arrow3-left--> 
              <a href="#" class="arrow3-right2s"></a><!--arrow3-right--> 
            </div>
            <!--chain-box--> 
          </div>
        </div>
	    <div class="content_left_listproduct" style="padding-bottom: 32%;">
                	
         				 <!--client section start-->
   <section id="team" class="team-member-section ptb-100 gray-light-bg">
        <div class="container">
            <div class="row justify-content-center" style="text-align: center;">
               
                   
                        <h1 Style="font-size: xx-large;">برند های ما</h1>
                        <p class="lead">
                          شرکت های همکار با ما بهترین برند های دنیا هستند
                        </p>
                
            
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="single-team-member position-relative">
                        <div class="team-image">
                            <a href="" ><img src="./css/team-4.jpg" style="width: 100% !important;" alt="Team Members" class="img-fluid rounded-circle">
                        </a>
						</div>
                       
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-team-member position-relative">
                         <div class="team-image">
                            <a href="" ><img src="./css/4.png" style="width: 100% !important;" alt="Team Members" class="img-fluid rounded-circle">
                        </a>
						</div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-team-member position-relative">
                        <div class="team-image">
                            <a href="" ><img src="./css/3.png" style="width: 100% !important;" alt="Team Members" class="img-fluid rounded-circle">
                        </a>
						</div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-team-member position-relative">
                          <div class="team-image">
                            <a href="" ><img src="./css/2.png" style="width: 100% !important;" alt="Team Members" class="img-fluid rounded-circle">
                        </a>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--client section start-->
 
       </div>
		     

	

            </div>
			              
            <div class="col-lg-3 col-md-4 col-sm-10 col-xs-12 col-sm-offset-1 content_right pull-right">
            	<div class=" col-lg-12 content_right_sidebar">
                	<div class="content_right_sidebar_top">
                    	<h3> جدید ترین محصولات </h3>
                    </div>
                    <div class="content_right_sidebar_content">
                    	<ul>
                        <?php
                                        $array=$post->showData_post_new(post_table);
                                    $i=0;
                                    if($array) {
                                        foreach ($array as $result1) {
                                            $i++;
                                            echo '
                        	<li>
                            	<div class="right">
                                	<a target="_blank" href="single.php?id='.$result1['db_post_id'].'&code='.$result1['db_post_code'].'"><img style="border-radius: 5%;border: 1px solid #eee8ef"src="Ajax/Save/images/'.$result1['db_post_image'].'"></a>
                                </div>
                                <div class="left">
									<a target="_blank" href="single.php?id='.$result1['db_post_id'].'&code='.$result1['db_post_code'].'"><p>'.substr($result1['db_post_name_fa'],0,75).'  ...</p></a>
                                    <p1>‌ '.$result1['db_post_date'].'</p1>
                                </div>
                            </li>
							';
										}
									}
							?>
                        </ul>
                    </div>
                    <div class="content_right_sidebar_bottom">
                    	<a href="blog.php">+ مشاهده محصولات بیشتر  </a>
                    </div>
                </div>
                <div class="content_right_shortcut_link">
                	<img src="Image/869b569b-310d-4268-9cc0-a9052b961a0a.jpg">
                </div>
                <div class="content_right_shortcut_link">
                	<img src="Image/bb693031-a89b-4190-8d2e-980ae16a2860.jpg">
                </div>
                <div class=" col-lg-12 content_right_sidebar">
                	<div class="content_right_sidebar_top">
                    	<h3> محبوب ترین محصولات </h3>
                    </div>
                    <div class="content_right_sidebar_content">
                    	<ul>
                        <?php
                                        $array=$post->showData_post_favourite(post_table);
                                    $i=0;
                                    if($array) {
                                        foreach ($array as $result1) {
                                            $i++;
                                            echo '
                        	<li>
                            	<div class="right">
                                	<a target="_blank" href="single.php?id='.$result1['db_post_id'].'&code='.$result1['db_post_code'].'"><img src="Ajax/Save/images/'.$result1['db_post_image'].'"></a>
                                </div>
                                <div class="left">
									<a target="_blank" href="single.php?id='.$result1['db_post_id'].'&code='.$result1['db_post_code'].'"><p>'.substr($result1['db_post_name_fa'],0,75).'  ...</p></a>
                                    <p1>‌ '.$result1['db_post_date'].'</p1>
                                </div>
                            </li>
							';
										}
									}
							?>
                        </ul>
                    </div>
                    <div class="content_right_sidebar_bottom">
                    	<a href="blog.php">+ مشاهده محصولات بیشتر  </a>
                    </div>
                </div>


				<div class="content_right_shortcut_bank_logo">
                	<img src="Image/namad2.png">
                </div>
            </div>
        </div>
    <!--CONTENT END-->



<?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>

</body>
</html>