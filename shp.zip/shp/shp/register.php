<?php
define('post_table','db_post');
define('setting','db_setting_admin');
define('site_slider','db_slider');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('Classes/Factor/factor.php');
include('INCLUDE/functions.php');


$upload=new upload();
$user=new user();
$category=new category();
$post=new post();
$setting=new setting();
$connect=new Connection();
$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

$factor=new factor();

define('temprory_factor','db_temprory_factor');

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }

    $factor_product_count=$factor->product_count_factor(temprory_factor,$code);
}

?>
<title> ثبت نام </title>
<?php include ("header.php") ; ?>




<!--CONTENT START-->
        <div class="row content"><!-- the content(middle) of page(blog,sidebar & ...) -->
			<div class="content_register">
            	<div class="content_register_top">
                	<p> قبلاٌ در سایت ثبت نام کرده اید؟</p><h3> ورود به سایت</h3>
                </div>
                <div class="content_register_content">
                	<div class="content_register_content_top">
                    	<i class="fa fa-user-plus"></i>
                        <p> به فروشگاه کامپیوتری بپیوندید </p>
                    </div>
                    <div class="content_register_content_content">
                    	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 content_register_content_content_right pull-right">
                            <div class="result_t" style="display: block; width:100%;">

                            </div>

                            <label> نام شما :</label>
      <input type="text" class="form-control content_input" placeholder="NAME" aria-describedby="basic-addon1" id="name">
      						<label> نام کاربری :</label>
      <input type="text" class="form-control content_input" placeholder="USERNAME" aria-describedby="basic-addon1" id="username">
                            <p1 id="username_result" style="display: none">متاسفانه نام کاربری زیر رزرو شده است</p1>
      						<label> گذرواژه  :</label>
      <input type="text" class="form-control content_input" placeholder="PASSWORD" aria-describedby="basic-addon1" id="password">
                            <label> تکرار گذرواژه :</label>
      <input type="text" class="form-control content_input" placeholder="REPASSWORD" aria-describedby="basic-addon1" id="re_password">

                            <input type="checkbox" id="write_lege" name="write_lege">
                            <p>حریم خصوصی و شرایط و قوانین استفاده از سرویس های سایت را مطالعه نموده و با کلیه موارد آن موافقم.</p>

  <button type="button" id="register" class="btn btn-default content_button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    ثبت نام در سایت
  </button>
                        </div>
                        <div class="col-lg-6 col-md-6 content_register_content_content_left pull-left hidden-xs hidden-sm">
                        	<ul>
                            	<li><i class="fa fa-shopping-cart"></i><p>سریع تر و ساده تر خرید کنید</p></li>
                                <li><i class="fa fa-list-ul"></i><p>به سادگی سوابق خرید و فعالیت های خود را مدیریت کنید</p></li>
                                <li><i class="fa fa-heart"></i><p>لیست علاقمندی های خود را بسازید و تغییرات آنها را دنبال کنید</p></li>
                                <li><i class="fa fa-comments"></i><p>نقد، بررسی و نظرات خود را با دیگران به اشتراک گذارید</p></li>
                                <li><i class="fa fa-bookmark"></i><p>در جریان فروش های ویژه و قیمت روز محصولات قرار بگیرید</p></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!--CONTENT END-->




        <?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>
<script src="Ajax/Send/Site/user_register/user_register.js"></script>

</body>
</html>