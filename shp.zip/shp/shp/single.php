<?php
define('post_table','db_post');
define('setting','db_setting_admin');
define('site_slider','db_slider');
define('slider_table','db_post_slider');
define('temprory_factor','db_temprory_factor');



include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('Classes/Factor/factor.php');
include('INCLUDE/functions.php');

$upload=new upload();
$factor=new factor();

$user=new user();
$category=new category();
$post=new post();
$setting=new setting();

$connect=new Connection();

@$post->update_post_view(post_table,$_GET['code']);


@$single=$post->showData_post_id(post_table,$_GET['id'],$_GET['code']);
if(!$single){
    header("location:blog.php");
}

@$slider=$post->showData_img_slider_code(slider_table, $_GET['code']);

			$color=array();
			$color=explode(',',$single['db_post_color']);
			$garanti=array();
			$garanti=explode(',',$single['db_post_garanti']);
			$vezheki=array();
			$vezheki=explode('!',$single['db_post_vezheki']);
			$gheymat_1=$single['db_post_gheymat'];
			$takhfif=round($single['db_post_gheymat'] * ($single['db_post_takhfif'] /100));
			$gheymat_2=$gheymat_1 - $takhfif;
            $content=$single['db_post_comment'];

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }
    
    $factor_product_count=$factor->product_count_factor(temprory_factor,$code);
}
$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=0">
<title> <?php echo $single['db_post_name_fa']; ?> </title>
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap-rtl.css">
<link rel="stylesheet" type="text/css" href="Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="Style/Main/index.css">
<link rel="stylesheet" type="text/css" href="Style/list_product/styles.css">
    <link rel="stylesheet" type="text/css" href="Product_slider/css/style.css" />
    <link rel="stylesheet" type="text/css" href="Product_slider/css/elastislide.css" />
    <script id="img-wrapper-tmpl" type="text/x-jquery-tmpl">
			<div class="rg-image-wrapper">
				{{if itemsCount > 1}}
					<div class="rg-image-nav">
						<a href="#" class="rg-image-nav-prev">Previous Image</a>
						<a href="#" class="rg-image-nav-next">Next Image</a>
					</div>
				{{/if}}
				<div class="rg-image"></div>
				<div class="rg-loading"></div>
				<div class="rg-caption-wrapper">
					<div class="rg-caption" style="display:none;">
						<p></p>
					</div>
				</div>
			</div>
		</script>

</head>
<body>
<div class="container">
    <div class="row"><!-- the main row for all page-->
        <!--HEADER START-->
        <div class="row "><!-- the top(header) of page(menu,logo,search & ...) -->
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 top_left pull-left">
                <img src="Ajax/Save/logo/<?php echo $logo; ?>">
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 top_right pull-right">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_top">
                    <ul class="novbar_icon">
                        <li id="novbar_show"><i class="fa fa-bars"></i></li>
                    </ul>
                    <ul class="menu_hidden">
                        <li><i class="fa fa-key"></i><p> فروشگاه دیجی کالا ، وارد شوید</p></li>
                        <li><i class="fa fa-user-plus"></i><p> ثبت نام کنید </p></li>
                        <li class="hidden-lg hidden-md hidden-sm" style="height:50px;">
                            <div class="input-group">
                                <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                                <input type="text" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1">
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_bottom">
                    <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12 top_right_bottom_basket">
                        <a href="factor.php">
                            <div class="top_right_bottom_basket_box">
                                <div class="top_right_bottom_basket_box_right">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                                <div class="top_right_bottom_basket_box_content">
                                    <p> سبد خرید </p>
                                </div>
                                <div class="top_right_bottom_basket_box_left">
                                    <p><?php     echo @$factor_product_count;
                                        ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12 top_right_bottom_search hidden-xs">
                        <div class="input-group" style="margin-top:10px; height:42px;">
                            <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                            <form action="blog.php" method="get">
                                <input type="text" name="search" style=" height:42px;" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1"></form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_bottom pull-right ">
                <ul class="novbar_icon_bottommenu hidden-lg hidden-md">
                    <li id="novbar_bottommenu_show"><i class="fa fa-bars"></i></li>
                </ul>
                <ul class="level1">
                    <?php
                    $rows = $category->showData("db_menu");
                    $items = $rows;
                    $id = '';
                    $i=1;
                    foreach($items as $item){
                        if($item['menu_parent_id'] == 0){
                            echo "<a href='blog.php?catname=".$item['menu_name']."'><li><i class='fa fa-arrow-circle-o-down'></i>".$item['menu_name']."" ?>

                            <?php
                            $id = $item['menu_id'];
                            sub1($items, $id,($i+1));

                            echo '
							</li></a>';
                        }
                    }
                    ?>
                    <?php
                    function sub1($items, $id,$j){
                        echo'<ul class="level'.$j.'">';
                        foreach($items as $item){
                            if($item['menu_parent_id'] == $id){
                                echo"<a href='blog.php?catname=".$item['menu_name']."'><li><i class='fa fa-angle-left'></i>".$item['menu_name']."" ?>
                                <?php
                                sub1($items, $item['menu_id'],$j+1);
                                echo '
								</li></a>';
                            }
                        }
                        echo '</ul>';
                    }
                    ?>

                </ul>
            </div>
        </div>
        <!--HEADER END-->
    
    
    
    <form action="add_to_basket.php?id=<?php echo $_GET['id'].'&code='.$_GET['code']?>" method="post">
    <!--CONTENT START-->
        <div class="row"><!-- the content(middle) of page(blog,sidebar & ...) -->
  <div class="content">
		<div class="main_content_single_post">
            <div class="info_detail">
            	<div class="right">
                    <div class="container">

                        <div class="content">
                            <div id="rg-gallery" class="rg-gallery">
                                <div class="rg-thumbs">
                                    <!-- Elastislide Carousel Thumbnail Viewer -->
                                    <div class="es-carousel-wrapper">
                                        <div class="es-nav">
                                            <span class="es-nav-prev">Previous</span>
                                            <span class="es-nav-next">Next</span>
                                        </div>
                                        <div class="es-carousel">
                                            <ul>
                                           
											 <?php
                                                foreach($slider as $slider_s) {
                                                    echo '
                                                <li><a href="#"><img src="Ajax/Save/images/'.$slider_s['db_post_slider_name'].'" data-large="Ajax/Save/images/'.$slider_s['db_post_slider_name'].'" alt="Ajax/Save/images/'.$slider_s['db_post_slider_name'].'" /></a></li>
                                                ';
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- End Elastislide Carousel Thumbnail Viewer -->
                                </div><!-- rg-thumbs -->
                            </div><!-- rg-gallery -->
                        </div><!-- content -->
                    </div><!-- container -->

    <!--start-->
    <div>
        <div id="ninja-slider" style="float:right;">
            <div class="slider-inner">
                <ul>
               <?php
				foreach($slider as $slider_s){
				echo '
				<li><a class="ns-img" href="Ajax/Save/images/'.$slider_s['db_post_slider_name'].'"></a></li>
				';
				}
				
				?>
                </ul>
                <div class="fs-icon" title="بزرگنمایی/بستن"></div>
            </div>
        </div>
        <div id="thumbnail-slider" style="float:left;">
            <div class="inner">
                <ul>
                          <?php
				foreach($slider as $slider_s){
				echo '
				<li><a class="ns-img" href="Ajax/Save/images/'.$slider_s['db_post_slider_name'].'"></a></li>
				';
				}
				
				?>

                </ul>
            </div>
        </div>
    </div>
    <!--end-->











                </div><!--right-->
                <div class="left">
                	<div class="title">
                    	<en><?php echo $single['db_post_name_en']; ?></en>
                        <fa> <?php echo $single['db_post_name_fa']; ?></fa>
                    </div><!--title-->
                    <div class="color">
                    	<div class="color_title">انتخاب رنگ</div>
                        <?php
                        $color_counter=0;
							foreach($color as $color_s)
								{
                                    if($color_counter==0) {
                                        echo '
										<div class="color_box">
											<label>' . $color_s . '</label>
											<input type="radio" value="'.$color_s.'"  name="color" checked>
										</div>
									';
                                    }
                                    else{
                                        echo '
										<div class="color_box">
											<label>' . $color_s . '</label>
											<input type="radio" value="'.$color_s.'" name="color">
										</div>
									';

                                    }
                                    $color_counter++;
								}
						?>
                    </div><!--color-->
                    <div class="granti">
                    	<div class="granti_title">انتخاب گارانتی</div>
                            <div class="granti_box">
                            	<select name="garanti">
                        <?php
							foreach($garanti as $garanti_s)
								{
									echo'
                                    <option>'.$garanti_s.'</option>
									';
								}
						?>
                                </select>
                            </div><!--granti_box-->
                    </div><!--granti-->
                    <div class="price">
                    	<div class="price_right">
                        <p>قیمت </p><p style="text-decoration:line-through"><?php echo $gheymat_1; ?> </p><p>ریال </p>
                        </div><!--price_right-->
                        <div class="price_left">
                        	<p> تخفیف <?php echo $takhfif; ?> ریال </p>
                        </div><!--price_left-->
                    </div><!--price-->
                    <?php
                    if(!(isset($_SESSION['user_site_logged'])))
                        echo'
                    <div class="add_box">
          				<div class="add_box_icon"> <i class="fa fa-cart-arrow-down"></i> </div>
          				<!--add_box_icon-->

          				<div class="add_box_name">
                            <p>جهت افزودن با حساب کاربری خود وارد شوید </p>
          				</div>
         				 <!--add_box_name-->
        			</div>

                        ';
                    else{
                        echo '
                    <input type="submit" value="افزودن به فاکتور" class="add_box">
                        ';
                    }
                    ?>
                    <div class="final_price">
                    	<p>قیمت برای شما :</p><p1><?php echo $gheymat_2; ?></p1><p2>ریال</p2>
                    </div><!--final_price-->
                    <div class="left_left">
                    	<ul>
                                                <?php
							foreach($vezheki as $vezheki_s)
								{
									echo'
                                    <li>'.$vezheki_s.'</li>
									';
								}
						?>

                        </ul>
                    </div><!--left_left-->
                </div><!--left-->
            </div><!--info_detail-->
            <div class="description">
            	<div class="description_title">
                	<p> معرفی اجمالی محصول </p>
                </div><!--description_title-->
                <div class="description_content">
                	<p>
<?php echo $content; ?> </p>
                </div><!--description_content-->
            </div><!--description-->
<div style="width: 98%;
    margin: auto;
    border-radius: 10px;
    padding: 20px 30px;
    background: #fff;
    box-shadow: 0 29px 60px 10px rgb(54 57 73 / 9%);
    margin-right: 1%;
    margin-bottom: 1%;" class="description">
<div class="panel-heading">دیدگاه ها
</div>
  <div class="panel-body">
  

  	<form action="cmnt.php" method="post">
  	  <div style="    margin-bottom: 10%;">
	  <div  style="width: 45%; margin: 1%;float:right" class="form-group">
	    <label for="exampleInputEmail1">نام</label>
	    <input type="text" name="name"  class="form-control" id="exampleInputEmail1" placeholder="حمیدرضا">
		
		</div>
	  <div style="
    width: 45%;
    margin: 1%;
    float: left;"class="form-group">
	   <label for="exampleInputEmail1">ایمیل</label>
	    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Example@gmail.com">
	  	  </div>

	  </div>
	  <div class="form-group">
	    <label for="exampleInputPassword1">دیدگاه</label>
	    <textarea name="subject" class="form-control" rows="3"></textarea>
	  </div>
	  <button type="submit" class="btn btn-primary">ثبت</button>
	</form>
  </div>
</div>

        </div><!--main_content_single_post-->
  </div>
  <!--main_content-->
        </div>
    <!--CONTENT END-->   
    
    </form>


        <?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>


<!--jquery ui js-->
<script src="Script/jquery-ui-1.11.4/jquery-ui.js"></script>
<script src="Script/Main/jquery_function.js"></script>
<script type="text/javascript" src="Product_slider/js/jquery.tmpl.min.js"></script>
<script type="text/javascript" src="Product_slider/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="Product_slider/js/jquery.elastislide.js"></script>
<script type="text/javascript" src="Product_slider/js/gallery.js"></script>


</body>
</html>