<?php
session_start();
if(isset($_POST['email_check'])) {
    if (preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/", $_POST['email'])) {
        $_SESSION['email_check_contact_us']="success";
        echo "1";
    }
    else{
        $_SESSION['email_check_contact_us']="failed";
        echo "2";
    }
}
