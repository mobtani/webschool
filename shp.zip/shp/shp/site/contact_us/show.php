<?php
session_start();
define('contact_us_table','db_contactus');

include('../../INCLUDE/functions.php');
include_once("../../Classes/connect.php");
include('../../Classes/Site/contact_us/contact_us.php');

$contact_us=new contact_us();
$connect=new Connection();

if(!(isset($_SESSION['user_logged'])))
    header("location:../../Admin/login_logout/login.php");
if($_SESSION['user_access']=="3")
    header("location:../../admin/error/not_acces.php");
if($_SESSION['user_access']=="2")
    header("location:../../admin/error/not_acces.php");
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <title> نمایش تماس با ما ها</title>
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/bootstrap/css/bootstrap-rtl.css">
    <link rel="stylesheet" type="text/css"
          href="../../Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/index.css">
    <link rel="stylesheet" type="text/css" href="../../Style/Admin/jquery.dataTables.css">
</head>
<body>

<div class="container">
    <div class="row">
        <?php
        include('../../Function/Admin/top-menu.php');
        ?>
        <div class="row">
            <div class="col-lg-12 col-xs-12 t_body">
                <?php
                include('../../Function/Admin/right-menu.php');
                ?>
                <div class="col-lg-10 t_left">
                    <div class="col-lg-12 top_n1">
                        <ul>
                            <li><i class="fa fa-home"></i> داشبورد / نمایش تماس با ما ها</li>
                            <li class="end" id="clock1"> داشبورد</li>
                            <li class="end"> <?php echo get_date('امروز', ' '); ?> </li>
                        </ul>
                    </div>
                    <div class="col-lg-12 content">
                        <div class="alert alert-success alert-dismissible" role="alert" style="display: none">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <p></p>
                        </div>
                        <div class="alert alert-warning alert-dismissible" role="alert" style="display: none">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <p></p>
                        </div>
                        <div class="col-lg-12 box" style="margin-top: 20px;">
                            <div class="box_content">
                                <table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>نام </th>
                                            <th>ایمیل </th>
                                            <th>موضوع </th>
                                            <th> پیغام </th>
                                            <th> تاریخ </th>
                                            <th> وضعیت </th>
                                            <th> عملیات </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $array=$contact_us->showData_contactus(contact_us_table);
                                            $i=0;
                                        foreach ($array as $result) {
                                            $i++;
                                            echo '
                                          <tr class="odd gradeX">
                                              <td>'.$i.'</td>
                                              <td>'.$result['db_contactus_name'].'</td>
                                              <td>'.$result['db_contactus_email'].'</td>
                                              <td>'.$result['db_contactus_subject'].'</td>
                                              <td>'.$result['db_contactus_comment'].'</td>
                                              <td>'.$result['db_contactus_date'].'</td>
                                              ';
                                            if($result['db_contactus_state']=="0"){
                                                echo '<td id="change_state"><a href="#" data-id="'.$result['db_contactus_id'].'"  data-state="1"> خوانده نشده </a></td>';
                                            }
                                            else{
                                                echo '<td id="change_state"><a href="#" data-id="'.$result['db_contactus_id'].'"  data-state="0"> خوانده شده </a></td>';
                                            }
                                            echo'
                                              <td id="action_post">
                                                <a href="#" data-action="delete" data-id="'.$result['db_contactus_id'].'"><i class="fa fa-trash-o"></i></a>
                                              </td>
                                          </tr>
                                        ';
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../Script/Main/jquery-1.11.1.min.js"></script>
<script src="../../Style/bootstrap/js/bootstrap.min.js"></script>
<script src="../../Script/Admin/jquery.slimscroll.js"></script>
<script src="../../Script/Admin/admin.js"></script>
<script src="../../Script/Admin/jquery.dataTables.js"></script>

<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        $('#example').dataTable();
    } );
</script>
<script src="../../Ajax/Send/Site/contact_us/contact_us.js"></script>

</body>
</html>