<?php
define('post_table','db_post');
define('setting','db_setting_admin');
define('site_slider','db_slider');


include_once("Classes/connect.php");
include_once("Classes/Cat/cat.php");
include('Classes/setting/setting.php');
include('Classes/Upload/upload.php');
include_once("Classes/Post/post.php");
include('Classes/User/user.php');
include('Classes/Factor/factor.php');
include('INCLUDE/functions.php');


$upload=new upload();
$user=new user();
$category=new category();
$post=new post();
$setting=new setting();
$connect=new Connection();
$value=$setting->fetch_count_image_site_slider(setting);
$logo=$setting->fetch_logo_name(setting);
$copyright_fa=$setting->fetch_fa_copyright(setting);
$copyright_en=$setting->fetch_en_copyright(setting);
$facebook=$setting->fetch_facebook(setting);
$twitter=$setting->fetch_twitter(setting);
$skype=$setting->fetch_skype(setting);

$factor=new factor();
define('final_factor','db_final_factor');

define('temprory_factor','db_temprory_factor');

if(isset($_COOKIE['factor']) || isset($_SESSION['temprory_factor_code'])) {

    if(isset($_SESSION['temprory_factor_code'])){
        $code=$_SESSION['temprory_factor_code'];
    }else{
        $code=$_COOKIE['factor'];
    }

    $factor_product_count=$factor->product_count_factor(temprory_factor,$code);
}


@$user_factors=$factor->showData_post_in_factor_final(final_factor,$_SESSION['user_site_customer_code']);


if(!(isset($_SESSION['user_site_logged'])))
    header("location:login.php");
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=0">
<title> پنل کاربری </title>
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="Style/bootstrap/css/bootstrap-rtl.css">
<link rel="stylesheet" type="text/css" href="Font/font-awesome-4.3.0/font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="Style/Main/index.css">
<link rel="stylesheet" type="text/css" href="Style/list_product/styles.css">
    <link rel="stylesheet" type="text/css" href="Style/Admin/jquery.dataTables.css">
    <style>
        .alert_user_register_state{
            float: right;
            width: 97%;
            height:auto;
            padding:8px 10px;
            margin: 10px 30px 0px 0px;
            background-color: #e1ff6d;
            border-radius: 4px;
            box-shadow: 0px 0px 3px #b8ff7b;
            text-align: right;
            font: 13px khat;
        }
        .alert_user_register_state i{
            float: right;
            margin: 2px 0px 0px 4px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row"><!-- the main row for all page-->
        <!--HEADER START-->
        <div class="row "><!-- the top(header) of page(menu,logo,search & ...) -->
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 top_left pull-left">
                <img src="Image/digikala-logo-slogan.png">
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 top_right pull-right">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_top">
                    <ul class="novbar_icon">
                        <li id="novbar_show"><i class="fa fa-bars"></i></li>
                    </ul>
                    <ul class="menu_hidden">
                        <?php
                        if(!(isset($_SESSION['user_site_logged']))) {
                            echo '
                        <a href="login.php" target="_blank"><li><i class="fa fa-key"></i><p> فروشگاه دیجی کالا ، وارد شوید</p></li></a>
                        <a href="register.php" target="_blank"><li><i class="fa fa-user-plus"></i><p> ثبت نام کنید </p></li></a>
                        ';
                        }
                        else{
                            echo '
                        <li><i class="fa fa-key"></i><p> سلام '.$_SESSION['user_site_name'].' خوش آمدی</p></li>
                        <a href="user_panel.php" target="_blank"><li><p> پنل کاربری </p></li></a>
                        <a href="logout.php"><li><p> خروج </p></li></a>
                        ';
                        }
                        ?>
                        <li class="hidden-lg hidden-md hidden-sm" style="height:50px;">
                            <div class="input-group">
                                <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                                <input type="text" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1">
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_right_bottom">
                    <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12 top_right_bottom_basket">
                        <a href="factor.php">
                            <div class="top_right_bottom_basket_box">
                                <div class="top_right_bottom_basket_box_right">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                                <div class="top_right_bottom_basket_box_content">
                                    <p> سبد خرید </p>
                                </div>
                                <div class="top_right_bottom_basket_box_left">
                                    <p><?php echo @$factor_product_count; ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12 top_right_bottom_search hidden-xs">
                        <div class="input-group" style="margin-top:10px; height:42px;">
                            <span class="input-group-addon" id="basic-addon1"><i class="fa fa-search" style="font-size:23px; margin-top:-4px;"></i></span>
                            <form action="blog.php" method="get">
                                <input type="text" name="search" style=" height:42px;" class="form-control" placeholder="عبارت مورد جستجو ..." aria-describedby="basic-addon1"></form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 top_bottom pull-right ">
                <ul class="novbar_icon_bottommenu hidden-lg hidden-md">
                    <li id="novbar_bottommenu_show"><i class="fa fa-bars"></i></li>
                </ul>
                <ul class="level1">
                    <?php
                    $rows = $category->showData("db_menu");
                    $items = $rows;
                    $id = '';
                    $i=1;
                    foreach($items as $item){
                        if($item['menu_parent_id'] == 0){
                            echo "<a href='blog.php?catname=".$item['menu_name']."'><li><i class='fa fa-arrow-circle-o-down'></i>".$item['menu_name']."" ?>

                            <?php
                            $id = $item['menu_id'];
                            sub1($items, $id,($i+1));

                            echo '
							</li></a>';
                        }
                    }
                    ?>
                    <?php
                    function sub1($items, $id,$j){
                        echo'<ul class="level'.$j.'">';
                        foreach($items as $item){
                            if($item['menu_parent_id'] == $id){
                                echo"<a href='blog.php?catname=".$item['menu_name']."'><li><i class='fa fa-angle-left'></i>".$item['menu_name']."" ?>
                                <?php
                                sub1($items, $item['menu_id'],$j+1);
                                echo '
								</li></a>';
                            }
                        }
                        echo '</ul>';
                    }
                    ?>

                </ul>
            </div>
        </div>
        <!--HEADER END-->
    
    
    
    <a href="edite_user_info.php"></a>
    <!--CONTENT START-->
            <?php
            if($_SESSION['user_site_register_state']==0){
                echo '
                <div class="row alert_user_register_state">
                ';
                echo " ثبت نام شما تکمیل نشده است جهت تکمیل بر روی <a href=\"edite_user_info.php\">ویرایش اطلاعات</a> کنید<i class='fa fa-warning'></i>";
                echo '</div>';
            }
            ?>
            <?php
            if($_SESSION['user_site_register_state']==0){
                echo '
                <div class="row alert_user_register_state">
                ';

                echo " جهت استفاده خدمات سایت اطلاعات خود را تکمیل کنید <i class='fa fa-warning'></i>";
                echo '</div>';

            }
            ?>

        <div class="row content"><!-- the content(middle) of page(blog,sidebar & ...) -->
            <div class="main_content_user_panel">
                <div class="user_panel_info">
                    <div class="user_panel_info_top">
                        <div class="top_icon">
                            <i class="fa fa-user"></i>
                        </div><!--top_icon-->
                        <div class="top_title">
                            <p>اطلاعات کاربر</p>
                        </div><!--top_title-->
                    </div><!--user_panel_info_top-->
                    <div class="user_panel_info_content">
                        <div class="top">
                            <p>اطلاعات مشتری حقیقی</p>
                            <div class="clear under_prtflio_head"></div>
                        </div><!--top-->
                        <div class="col-lg-12 content">
                            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 box"><p>نام و نام خانوادگی :</p><p1> <?php echo @$_SESSION['user_site_name'].$_SESSION['user_site_family']; ?></p1></div>
                            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 box"><p>آدرس الکترونیکی :</p><p1> <?php echo @$_SESSION['user_site_email'] ?></p1></div>
                            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 box"><p>شماره تلفن همراه :</p><p1> <?php echo @$_SESSION['user_site_mobile'] ?></p1></div>
                            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 box"><p>شماره تلفن ثابت :</p><p1> <?php echo @$_SESSION['user_site_tell'] ?></p1></div>
                            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 box"><p>کد پستی:</p><p1> <?php echo @$_SESSION['user_site_codeposti'] ?></p1></div>
                            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 box"><p>کد مشتری :</p><p1> <?php echo @$_SESSION['user_site_customer_code'] ?></p1></div>
                            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 box"><p>آدرس  :</p><p1> <?php echo @$_SESSION['user_site_address'] ?></p1></div>
                            <div class="user_panel_info_btn">
                                <a href="edite_user_paasword.php" style="color: #0f0f0f" target="_blank"><div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 btn_box1">
                                    <i class="fa fa-key"></i>
                                    <p> تغییر کلمه عبور</p>
                                </div></a>
                                <a href="edite_user_info.php" style="color: #0f0f0f" target="_blank"><div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 btn_box2">
                                    <i class="fa fa-pencil-square-o"></i>
                                    <p> ویرایش اطلاعات</p>
                                </div><!--btn_box2--></a>
                            </div><!--user_panel_info_btn-->
                        </div><!--content-->
                    </div><!--user_panel_info_content-->
                </div><!--user_panel_info-->
                <!--شروع فرم سفارشات-->
                <div class="user_panel_info">
                    <div class="user_panel_info_top">
                        <div class="top_icon">
                            <i class="fa fa-truck"></i>
                        </div><!--top_icon-->
                        <div class="top_title">
                            <p>سفارشات شما</p>
                        </div><!--top_title-->
                    </div><!--user_panel_info_top-->
                    <div class="user_panel_info_content">
                        <div class="content">
                            <br>
                            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example" width="100%">
                                <thead>
                                <tr>
                                    <th>ردیف</th>
                                    <th>شماره فاکتور</th>
                                    <th>تاریخ</th>
                                    <th>قیمت کل</th>
                                    <th>وضعیت ارسال</th>
                                    <th> مشاهده </th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $i=0;
                                if($user_factors) {

                                    foreach ($user_factors as $factors) {
                                        $i++;
                                        echo '
                                        <tr class="odd gradeX">
                                            <td>' . $i . '</td>
                                            <td>' . $factors["db_final_factor_code"] . '</td>
                                            <td>' . $factors["db_final_factor_date"] . '</td>
                                            <td>' . $factors["db_final_factor_price"] . '</td>
                                            ';
                                        if ($factors["db_final_factor_state"] == 0) {
                                            echo '<td>در حال بررسی</td>';
                                        } else if ($factors["db_final_factor_state"] == 1) {
                                            echo '<td>ارسال شده</td>';
                                        } else {
                                            echo '<td>معلق</td>';
                                        }
                                        echo '
                                            <td>
                                            <a href="factor_show.php?code=' . $factors['db_final_factor_code'] . '" data-action="delete" data-code="' . $factors['db_final_factor_code'] . '" data-id="' . $factors['db_final_factor_id'] . '">مشاهده</a>
                                            <td>
                                        </tr>
                                    ';
                                    }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div><!--content-->
                    </div><!--user_panel_info_content-->
                </div><!--user_panel_info-->
            </div><!--main_content_user_panel-->

        </div>
    <!--CONTENT END-->




        <?php include ("footer.php") ; ?>
<script src="Script/Main/jquery-1.11.1.min.js"></script>
<script src="Script/Main/site.js"></script>
<script src="Style/bootstrap/js/bootstrap.min.js"></script>
<script src="Script/list_product/main.js"></script>
<script src="Script/Admin/jquery.dataTables.js"></script>

<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        $('#example').dataTable();
    } );
</script>

<script src="Ajax/Send/Site/user_register/user_register.js"></script>

</body>
</html>